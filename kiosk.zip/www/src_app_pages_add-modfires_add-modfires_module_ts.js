"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_add-modfires_add-modfires_module_ts"],{

/***/ 7535:
/*!*******************************************************************!*\
  !*** ./src/app/pages/add-modfires/add-modfires-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddModfiresPageRoutingModule": () => (/* binding */ AddModfiresPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _add_modfires_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-modfires.page */ 7824);




const routes = [
    {
        path: '',
        component: _add_modfires_page__WEBPACK_IMPORTED_MODULE_0__.AddModfiresPage
    }
];
let AddModfiresPageRoutingModule = class AddModfiresPageRoutingModule {
};
AddModfiresPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddModfiresPageRoutingModule);



/***/ }),

/***/ 9812:
/*!***********************************************************!*\
  !*** ./src/app/pages/add-modfires/add-modfires.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddModfiresPageModule": () => (/* binding */ AddModfiresPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _add_modfires_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-modfires-routing.module */ 7535);
/* harmony import */ var _add_modfires_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-modfires.page */ 7824);







let AddModfiresPageModule = class AddModfiresPageModule {
};
AddModfiresPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _add_modfires_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddModfiresPageRoutingModule
        ],
        declarations: [_add_modfires_page__WEBPACK_IMPORTED_MODULE_1__.AddModfiresPage]
    })
], AddModfiresPageModule);



/***/ }),

/***/ 7824:
/*!*********************************************************!*\
  !*** ./src/app/pages/add-modfires/add-modfires.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddModfiresPage": () => (/* binding */ AddModfiresPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _add_modfires_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-modfires.page.html?ngResource */ 1284);
/* harmony import */ var _add_modfires_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-modfires.page.scss?ngResource */ 785);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6362);







let AddModfiresPage = class AddModfiresPage {
    constructor(rest, location, route) {
        this.rest = rest;
        this.location = location;
        this.route = route;
        this.arrOfSouces = [];
    }
    ngOnInit() {
        this.langId = localStorage.getItem("lang");
        if (this.langId == '1') {
            this.dir = 'rtl';
            this.Back = "رجوع";
            this.Cancel = "إلغاء";
            this.addChange = "اضف المكونات";
            this.ingrdtiont = "الإضافات";
            this.LE = "جنيه";
        }
        else {
            this.dir = 'ltr';
            this.Back = "Back";
            this.Cancel = "Cancel";
            this.addChange = "Apply Changes";
            this.ingrdtiont = "Modifiers";
            this.LE = "LE";
        }
        this.getData();
    }
    getData() {
        this.item = JSON.parse(sessionStorage.getItem('modfiresArr'));
        this.prdouct = JSON.parse(sessionStorage.getItem('ProductOfChose'));
        this.prdouctName = this.prdouct.Name;
        this.productPrice = this.prdouct.Price;
        this.productImage = this.prdouct.Image;
        for (let i = 0; i < this.item.length; i++) {
            this.item[i].count = 0;
        }
        this.arrOfSouces = this.item;
    }
    goCheckOut() {
        let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
        let modfire = [];
        let finalPrdouct = {};
        for (let i = 0; i < this.arrOfSouces.length; i++) {
            if (this.arrOfSouces[i].count != 0) {
                modfire.push(this.arrOfSouces[i]);
            }
        }
        finalPrdouct.modfire = modfire;
        finalPrdouct.Prdoucts = [products];
        this.rest.GetItemsbyProductId(this.langId, this.prdouct.Id).subscribe((res) => {
            if (res.length != 0) {
                console.log(res);
                sessionStorage.setItem('IngrdDub', JSON.stringify(res));
                sessionStorage.setItem('ModfireOfChose', JSON.stringify(finalPrdouct));
                this.route.navigateByUrl('/add-souce');
            }
            else {
                finalPrdouct.ingridtArr = [];
                sessionStorage.setItem('ModfireOfChose', JSON.stringify(finalPrdouct));
                this.route.navigateByUrl('/quantity');
            }
        });
        // sessionStorage.setItem('ModfireOfChose', JSON.stringify(finalPrdouct))
        // this.route.navigateByUrl('/add-souce')
    }
    goBack() {
        this.location.back();
    }
    minus(item) {
        if (item.count > 0) {
            item.count = item.count - 1;
        }
    }
    plus(item) {
        item.count = item.count + 1;
    }
};
AddModfiresPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__.Location },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
AddModfiresPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-add-modfires',
        template: _add_modfires_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_add_modfires_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AddModfiresPage);



/***/ }),

/***/ 785:
/*!**********************************************************************!*\
  !*** ./src/app/pages/add-modfires/add-modfires.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcb400;\n}\n\nion-content {\n  --background: #fff;\n  --color: #000 ;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: #000;\n  text-transform: none;\n}\n\n.cover {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  left: 0%;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #fff;\n  top: 0;\n}\n\n.cover h1 {\n  font-weight: bold;\n  margin-top: 12%;\n  font-size: 5vw;\n  color: black;\n}\n\n.imgProduct {\n  width: auto;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.back, .backIfRight {\n  text-align: right;\n  text-transform: none;\n  margin-top: 5px;\n}\n\n.back ion-button, .backIfRight ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 5%;\n  font-size: 5vw;\n  height: 100px;\n  margin-bottom: 3%;\n}\n\n.order {\n  display: flex;\n  justify-content: space-between;\n}\n\n.orderName {\n  display: flex;\n}\n\n.orderName p {\n  margin-left: 5px;\n  font-size: 5vw;\n}\n\n.orderName img {\n  max-width: 250px;\n}\n\n.order .parg {\n  font-size: 5vw;\n}\n\n.addSouce {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 10px;\n}\n\n.addSouce ion-button {\n  --background: rgb(252, 180, 0);\n  color: #000;\n  height: 135px;\n  font-size: 5vw;\n}\n\n.count {\n  background: gainsboro;\n  height: 135px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-radius: 6px;\n  margin-top: 3px;\n  font-size: 5vw;\n}\n\n.count p {\n  margin: 0;\n}\n\n.extra {\n  margin-top: 6px;\n  font-size: 5vw;\n}\n\n.extra span {\n  font-size: 4vw;\n  color: gray;\n}\n\n.fotter {\n  position: absolute;\n  bottom: 1%;\n  width: 100%;\n}\n\n.fotter div {\n  display: flex;\n  justify-content: space-around;\n}\n\n.fotter ion-button {\n  width: 39%;\n  height: 138px;\n  font-size: 4vw;\n}\n\nh5 {\n  margin-top: 18px;\n  margin-bottom: 18px;\n  font-size: 7vw;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n\n@media only screen and (max-width: 768px) {\n  .orderName img {\n    width: 26%;\n  }\n\n  .imgProduct {\n    width: 82px;\n  }\n\n  .products img {\n    height: 74px;\n  }\n\n  .menuItem img {\n    height: 74px;\n  }\n\n  .fotter ion-button {\n    height: 44px;\n  }\n\n  .back ion-button {\n    margin-bottom: 0;\n    height: 36px;\n    margin-top: 0;\n  }\n\n  .addSouce ion-button {\n    height: 43px;\n    font-size: 4vw;\n  }\n\n  .count {\n    height: 43px;\n  }\n\n  .back ion-button, .backIfRight ion-button {\n    height: 41px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZC1tb2RmaXJlcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0FBQ0o7O0FBRUU7RUFDSSxrQkFBQTtFQUNBLGNBQUE7QUFDTjs7QUFDRTtFQUNFLHFCQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0FBRUo7O0FBQUU7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsUUFBQTtFQUNBLHFDQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsTUFBQTtBQUdKOztBQURFO0VBQ0UsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFJSjs7QUFGSTtFQUNFLFdBQUE7QUFLTjs7QUFGSTtFQUNFLGlCQUFBO0FBS047O0FBSEk7RUFDRSxnQkFBQTtBQU1OOztBQUhJO0VBQ0UsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLGVBQUE7QUFNTjs7QUFKSTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUVBLGlCQUFBO0FBTU47O0FBSkk7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7QUFPUjs7QUFMSTtFQUNJLGFBQUE7QUFRUjs7QUFOSTtFQUNJLGdCQUFBO0VBQ0EsY0FBQTtBQVNSOztBQVBJO0VBQ0UsZ0JBQUE7QUFVTjs7QUFSSTtFQUNFLGNBQUE7QUFXTjs7QUFUSTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBWVI7O0FBVEk7RUFDSSw4QkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtBQVlSOztBQVZJO0VBQ0UscUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FBYU47O0FBWEk7RUFDSSxTQUFBO0FBY1I7O0FBWkk7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQWVOOztBQWJJO0VBQ0UsY0FBQTtFQUNBLFdBQUE7QUFnQk47O0FBZEk7RUFDSSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FBaUJSOztBQWZJO0VBQ0UsYUFBQTtFQUNBLDZCQUFBO0FBa0JOOztBQWhCSTtFQUNFLFVBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtBQW1CTjs7QUFqQkk7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNGLGlCQUFBO0VBQ0Esa0JBQUE7QUFvQko7O0FBaEJJO0VBQ0U7SUFDRSxVQUFBO0VBbUJOOztFQWpCSTtJQUNFLFdBQUE7RUFvQk47O0VBbEJJO0lBQ0UsWUFBQTtFQXFCTjs7RUFuQkk7SUFDRSxZQUFBO0VBc0JOOztFQXBCSTtJQUNFLFlBQUE7RUF1Qk47O0VBckJJO0lBQ0UsZ0JBQUE7SUFDQSxZQUFBO0lBQ0EsYUFBQTtFQXdCTjs7RUF0Qkk7SUFDRSxZQUFBO0lBQ0EsY0FBQTtFQXlCTjs7RUF2Qkk7SUFDRSxZQUFBO0VBMEJOOztFQXhCSTtJQUNFLFlBQUE7RUEyQk47QUFDRiIsImZpbGUiOiJhZGQtbW9kZmlyZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlcntcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgYmFja2dyb3VuZDogcmdiKDI1MiwgMTgwLCAwKVxuICB9XG4gIFxuICBpb24tY29udGVudHtcbiAgICAgIC0tYmFja2dyb3VuZDogI2ZmZjtcbiAgICAgIC0tY29sb3I6ICMwMDBcbiAgfVxuICBpb24tYnV0dG9uIHtcbiAgICAtLWJhY2tncm91bmQ6ICNFMUUxRTE7XG4gICAgLS1jb2xvcjogIzAwMDsgXG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gIH1cbiAgLmNvdmVyIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIGxlZnQ6IDAlO1xuICAgIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC43OSk7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIHRvcDogMFxuICB9XG4gIC5jb3ZlciBoMSB7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgbWFyZ2luLXRvcDogMTIlO1xuICAgIGZvbnQtc2l6ZTogNXZ3O1xuICAgIGNvbG9yOiBibGFja1xuICB9XG4gICAgLmltZ1Byb2R1Y3R7XG4gICAgICB3aWR0aDphdXRvO1xuICAgIH1cbiAgXG4gICAgLmJhY2sge1xuICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gICAgfVxuICAgIC5iYWNrSWZSaWdodHtcbiAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgfVxuICAgIFxuICAgIC5iYWNrICwgLmJhY2tJZlJpZ2h0e1xuICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gICAgICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICB9XG4gICAgLmJhY2sgaW9uLWJ1dHRvbiAsIC5iYWNrSWZSaWdodCBpb24tYnV0dG9ue1xuICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAyZW07XG4gICAgICAtLXBhZGRpbmctZW5kOiAyZW07XG4gICAgICAtLWJvcmRlci1yYWRpdXM6NXB4O1xuICAgICAgbWFyZ2luLXRvcDogNSU7XG4gICAgICBmb250LXNpemU6IDV2dztcbiAgICAgIGhlaWdodDogMTAwcHg7XG4gIFxuICAgICAgbWFyZ2luLWJvdHRvbTozJVxuICAgIH1cbiAgICAub3JkZXJ7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICB9XG4gICAgLm9yZGVyTmFtZXtcbiAgICAgICAgZGlzcGxheTogZmxleFxuICAgIH1cbiAgICAub3JkZXJOYW1lIHAge1xuICAgICAgICBtYXJnaW4tbGVmdDogNXB4O1xuICAgICAgICBmb250LXNpemU6IDV2d1xuICAgIH1cbiAgICAub3JkZXJOYW1lIGltZyB7XG4gICAgICBtYXgtd2lkdGg6MjUwcHhcbiAgICB9XG4gICAgLm9yZGVyIC5wYXJne1xuICAgICAgZm9udC1zaXplOiA1dndcbiAgICB9XG4gICAgLmFkZFNvdWNlIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4XG4gICAgfVxuICBcbiAgICAuYWRkU291Y2UgaW9uLWJ1dHRvbiB7XG4gICAgICAgIC0tYmFja2dyb3VuZDogcmdiKDI1MiwgMTgwLCAwKTtcbiAgICAgICAgY29sb3I6ICMwMDA7XG4gICAgICAgIGhlaWdodDogMTM1cHg7XG4gICAgICAgIGZvbnQtc2l6ZTogNXZ3XG4gICAgfVxuICAgIC5jb3VudCB7XG4gICAgICBiYWNrZ3JvdW5kOiBnYWluc2Jvcm87XG4gICAgICBoZWlnaHQ6IDEzNXB4O1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgICAgIG1hcmdpbi10b3A6IDNweDtcbiAgICAgIGZvbnQtc2l6ZTogNXZ3O1xuICAgIH1cbiAgICAuY291bnQgcCB7XG4gICAgICAgIG1hcmdpbjogMDtcbiAgICB9XG4gICAgLmV4dHJhe1xuICAgICAgbWFyZ2luLXRvcDogNnB4O1xuICAgICAgZm9udC1zaXplOjV2dztcbiAgICB9XG4gICAgLmV4dHJhIHNwYW4ge1xuICAgICAgZm9udC1zaXplOiA0dnc7XG4gICAgICBjb2xvcjogZ3JheTtcbiAgICB9XG4gICAgLmZvdHRlciB7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgYm90dG9tOiAxJTtcbiAgICAgICAgd2lkdGg6IDEwMCVcbiAgICB9XG4gICAgLmZvdHRlciBkaXYge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kXG4gICAgfVxuICAgIC5mb3R0ZXIgaW9uLWJ1dHRvbntcbiAgICAgIHdpZHRoOiAzOSU7XG4gICAgICBoZWlnaHQ6IDEzOHB4O1xuICAgICAgZm9udC1zaXplOiA0dnc7XG4gICAgfVxuICAgIGg1IHtcbiAgICAgIG1hcmdpbi10b3A6IDE4cHg7XG4gICAgICBtYXJnaW4tYm90dG9tOiAxOHB4O1xuICAgICAgZm9udC1zaXplOiA3dnc7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuXG4gIFxuICAgIH1cbiAgICBAbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6NzY4cHgpe1xuICAgICAgLm9yZGVyTmFtZSBpbWcge1xuICAgICAgICB3aWR0aDogMjYlO1xuICAgICAgfVxuICAgICAgLmltZ1Byb2R1Y3R7XG4gICAgICAgIHdpZHRoOiA4MnB4O1xuICAgICAgfVxuICAgICAgLnByb2R1Y3RzIGltZ3tcbiAgICAgICAgaGVpZ2h0OiA3NHB4O1xuICAgICAgfVxuICAgICAgLm1lbnVJdGVtIGltZ3tcbiAgICAgICAgaGVpZ2h0OiA3NHB4O1xuICAgICAgfVxuICAgICAgLmZvdHRlciBpb24tYnV0dG9ue1xuICAgICAgICBoZWlnaHQ6IDQ0cHg7XG4gICAgICB9XG4gICAgICAuYmFjayBpb24tYnV0dG9ue1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAwO1xuICAgICAgICBoZWlnaHQ6IDM2cHg7XG4gICAgICAgIG1hcmdpbi10b3A6IDA7XG4gICAgICB9XG4gICAgICAuYWRkU291Y2UgaW9uLWJ1dHRvbntcbiAgICAgICAgaGVpZ2h0OiA0M3B4O1xuICAgICAgICBmb250LXNpemU6IDR2dztcbiAgICAgIH1cbiAgICAgIC5jb3VudHtcbiAgICAgICAgaGVpZ2h0OjQzcHg7XG4gICAgICB9XG4gICAgICAuYmFjayBpb24tYnV0dG9uICwgLmJhY2tJZlJpZ2h0IGlvbi1idXR0b257XG4gICAgICAgIGhlaWdodDogNDFweDtcbiAgICAgIH1cbiAgICB9Il19 */";

/***/ }),

/***/ 1284:
/*!**********************************************************************!*\
  !*** ./src/app/pages/add-modfires/add-modfires.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <div>\n    <img class=\"imgProduct\" src=\"assets/images/panner.jpeg\">\n  </div>\n  <div class=\"cover\">\n    <h1>{{prdouctName}}</h1>\n  </div>\n</ion-header> -->\n<div class=\"header\">\n  <img class=\"imgProduct \" src=\"assets/images/kiosk.png\">\n</div>\n\n\n<ion-content [dir]=\"dir\">\n  <div [ngClass]=\"{'back':dir == 'ltr','backIfRight':dir == 'rtl'}\">\n    <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n  </div>\n  <section class=\"ion-padding-start ion-padding-end\">\n    <div class=\"order\">\n      <div class=\"orderName\">\n        <img src=\"{{productImage}}\">\n        <p>{{prdouctName}}</p>\n      </div>\n      <p class=\"parg\" *ngIf=\"langId != 1\">{{LE}} {{productPrice}}</p>\n      <p class=\"parg\" *ngIf=\"langId == 1\">{{productPrice}} {{LE}}</p>\n    </div>\n\n    <h5> {{ingrdtiont}}</h5>\n\n    <ion-grid style=\"    height: 50vh;\n    overflow: scroll;\">\n      <ion-row class=\"addSouce\" *ngFor=\"let item of arrOfSouces\">\n        <ion-col size=\"2\">\n          <ion-button (click)=\"plus(item)\">+</ion-button>\n        </ion-col>\n\n        <ion-col size=\"2\">\n          <ion-button (click)=\"minus(item)\">-</ion-button>\n        </ion-col>\n\n        <ion-col size=\"2\">\n          <div class=\"count\">\n            <p>{{item.count}}</p>\n          </div>\n        </ion-col>\n        <ion-col size=\"4\">\n          <p class=\"extra\">{{item.Name}}<br>\n            <span *ngIf=\"langId != 1\">{{LE}} {{item.Price}}</span>\n            <span *ngIf=\"langId == 1\">{{item.Price}} {{LE}}</span>\n          </p>\n        </ion-col>\n        <ion-col size=\"2\">\n          <img src=\"{{item.Image}}\">\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </section>\n  <div class=\"fotter\" dir=\"ltr\">\n    <div>\n      <ion-button (click)=\"goBack()\">{{Cancel}}</ion-button>\n      <ion-button (click)=\"goCheckOut()\">{{addChange}}</ion-button>\n    </div>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_add-modfires_add-modfires_module_ts.js.map