"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_main-menu_main-menu_module_ts"],{

/***/ 3126:
/*!*************************************************************!*\
  !*** ./src/app/pages/main-menu/main-menu-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainMenuPageRoutingModule": () => (/* binding */ MainMenuPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _main_menu_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main-menu.page */ 9806);




const routes = [
    {
        path: '',
        component: _main_menu_page__WEBPACK_IMPORTED_MODULE_0__.MainMenuPage
    }
];
let MainMenuPageRoutingModule = class MainMenuPageRoutingModule {
};
MainMenuPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MainMenuPageRoutingModule);



/***/ }),

/***/ 8768:
/*!*****************************************************!*\
  !*** ./src/app/pages/main-menu/main-menu.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainMenuPageModule": () => (/* binding */ MainMenuPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _main_menu_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main-menu-routing.module */ 3126);
/* harmony import */ var _main_menu_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./main-menu.page */ 9806);







let MainMenuPageModule = class MainMenuPageModule {
};
MainMenuPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _main_menu_routing_module__WEBPACK_IMPORTED_MODULE_0__.MainMenuPageRoutingModule
        ],
        declarations: [_main_menu_page__WEBPACK_IMPORTED_MODULE_1__.MainMenuPage]
    })
], MainMenuPageModule);



/***/ }),

/***/ 9806:
/*!***************************************************!*\
  !*** ./src/app/pages/main-menu/main-menu.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainMenuPage": () => (/* binding */ MainMenuPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _main_menu_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main-menu.page.html?ngResource */ 3691);
/* harmony import */ var _main_menu_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./main-menu.page.scss?ngResource */ 3590);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);







let MainMenuPage = class MainMenuPage {
    constructor(rest, route, navCtr) {
        this.rest = rest;
        this.route = route;
        this.navCtr = navCtr;
        this.categoris = [];
        this.showCover = false;
        this.disalbedButton = true;
    }
    ngOnInit() {
        this.langId = localStorage.getItem('lang');
        if (this.langId == '1') {
            this.dir = "rtl";
            this.Menu = "قائمة الطلبات";
            this.Back = "رجوع";
            this.Cancel = "إلغاء الطلب";
            this.OrderDone = "دفع";
            this.MyOrder = "طلباتي - في المتجر";
            this.bestSelling = "افضل المنتجات";
            this.discount = "الخصومات";
            this.promotions = "العروض";
            this.Compo = "كومبو";
        }
        else {
            this.dir = "ltr";
            this.Menu = "Main Menu";
            this.Back = "Back";
            this.Cancel = "Cancel Order";
            this.OrderDone = "Done";
            this.MyOrder = "My Order - In Shop";
            this.bestSelling = "Best Selling";
            this.discount = "Discount";
            this.promotions = "Promotion";
            this.Compo = "Combo";
        }
        this.getCategoris();
        this.ifArrOfModfier();
        this.subscription = this.rest.getObsData().subscribe(res => {
            if (res == 'true') {
                console.log("true");
                this.getCategoris();
                this.ifArrOfModfier();
            }
            else {
                console.log("false");
                this.getCategoris();
                this.ifArrOfModfier();
            }
        });
    }
    getCategoris() {
        this.rest.getCategoriWithProduct(this.langId).subscribe((res) => {
            console.log(res);
            if (res.StatusId == 3) {
                this.categoris = res.categoriesProducts;
                for (let i = 0; i < this.categoris.length; i++) {
                    if (i == 1 || i == 4 || i == 7 || i == 10) {
                        this.categoris[i].status = true;
                    }
                    else {
                        this.categoris[i].status = false;
                    }
                }
            }
            else if (res.StatusId == 5) {
                this.route.navigateByUrl('/get-breanch');
                this.rest.sendStatusOfBranch("5");
            }
            else if (res.StatusId == 4) {
                this.route.navigateByUrl('/get-breanch');
                this.rest.sendStatusOfBranch("4");
            }
        });
    }
    gotToSugg() {
        this.route.navigateByUrl('/suggestions');
    }
    ifArrOfModfier() {
        let arrOfMod = JSON.parse(sessionStorage.getItem('arrOfModfire'));
        if (arrOfMod) {
            this.disalbedButton = false;
            if (this.langId == '1') {
                this.arrOfModLength = "إجمالي المنتجات" + " " + `(${arrOfMod.length})`;
            }
            else {
                this.arrOfModLength = "Total Items" + " " + `(${arrOfMod.length})`;
            }
        }
        else {
            this.disalbedButton = true;
            if (this.langId == '1') {
                this.arrOfModLength = "لا يوجد طلبات";
            }
            else {
                this.arrOfModLength = "You Order is Empty";
            }
        }
    }
    gotToDetails(item) {
        if (item == 'Discount') {
            this.rest.gitDiscount(this.langId).subscribe((res) => {
                console.log(res);
                let obj = {
                    Name: 'Discount',
                    Products: res
                };
                sessionStorage.setItem('obj', JSON.stringify(obj));
                this.route.navigateByUrl('/discount');
            });
        }
        else {
            sessionStorage.setItem('obj', JSON.stringify(item));
            this.route.navigateByUrl('/categoris');
        }
    }
    goBack() {
        this.route.navigateByUrl('/home');
    }
    cancelOrder() {
        this.rest.sendObsData('true');
        sessionStorage.clear();
        this.route.navigateByUrl('/home');
    }
    Done() {
        this.route.navigateByUrl('/review');
    }
};
MainMenuPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController }
];
MainMenuPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-main-menu',
        template: _main_menu_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_main_menu_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MainMenuPage);



/***/ }),

/***/ 3590:
/*!****************************************************************!*\
  !*** ./src/app/pages/main-menu/main-menu.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcef50;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: #000;\n  text-transform: none;\n}\n\nion-content {\n  --background:#fff ;\n  --color:black ;\n}\n\n.cover {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  top: 0;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #000;\n}\n\n.cover h1 {\n  font-weight: bold;\n  margin-top: 10%;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.back p, .backIfRight p {\n  font-weight: bold;\n  font-size: 5vw;\n}\n\n.back ion-button, .backIfRight ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 2%;\n  font-size: 5vw;\n  height: auto;\n  margin-bottom: 5%;\n  height: 100px;\n}\n\n.products {\n  text-align: center;\n  height: 52vh;\n  overflow-y: scroll;\n}\n\n.products img {\n  height: 150px;\n}\n\n.products .price {\n  text-align: left;\n  font-size: 11px;\n}\n\n.products .name {\n  font-size: 0.8rem;\n  margin-bottom: 5px;\n  margin-top: 0;\n  font-weight: bold;\n  font-size: 3vw;\n}\n\n.products .rowOne {\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.colOne {\n  border-right: 1px solid #c2c2c2;\n}\n\n.menuItem {\n  padding: 30px 0;\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.menuItem p {\n  margin: 0;\n  font-size: 0.5rem;\n  text-align: center;\n  font-weight: bold;\n  font-size: 3vw;\n}\n\n.menuItem img {\n  height: 150px;\n}\n\n.price_name {\n  display: flex;\n  justify-content: space-between;\n  font-size: 10px;\n}\n\n.myOrder {\n  background: #E1E1E1;\n  padding: 5px 10px;\n}\n\n.myOrder h4 {\n  margin: 0;\n  font-size: 5vw;\n  color: #000;\n  padding: 20px 10px;\n}\n\n.confirmOrCancel {\n  display: flex;\n  justify-content: space-around;\n}\n\n.confirmOrCancel ion-button {\n  width: 33%;\n}\n\n.foter p {\n  text-align: center;\n  font-size: 5vw;\n}\n\n.footer {\n  position: absolute;\n  width: 100%;\n  bottom: 1%;\n}\n\n.Content {\n  padding: 5px;\n}\n\n.Content .navgation div {\n  border-bottom: 1px solid gray;\n}\n\n.Content .navgation {\n  overflow-y: scroll;\n  border-radius: 5px;\n  margin-top: -17%;\n  background: #f0f0f0;\n  height: 69vh;\n  text-align: center;\n}\n\n.confirmOrCancel ion-button {\n  font-size: 4vw;\n  height: 112px;\n}\n\n.Content .mainMenu {\n  font-size: 3rem;\n  font-weight: bold;\n  margin-top: 50%;\n}\n\n@media only screen and (max-width: 768px) {\n  .imgProduct {\n    width: 81px;\n  }\n\n  .back ion-button {\n    height: 36px;\n  }\n\n  .backIfRight ion-button {\n    height: 36px;\n  }\n\n  .Content .mainMenu {\n    font-size: 13px;\n  }\n\n  .Content {\n    padding: 0;\n  }\n\n  .navgation {\n    margin-top: -19%;\n  }\n\n  .products img {\n    height: 55px;\n  }\n\n  .menuItem img {\n    height: 50px;\n  }\n\n  .menuItem {\n    padding: 15px 0;\n  }\n\n  .myOrder h4 {\n    padding: 2px 10px;\n  }\n\n  .confirmOrCancel ion-button {\n    height: 44px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4tbWVudS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0FBQUo7O0FBRUE7RUFDSSxxQkFBQTtFQUNBLGFBQUE7RUFDQSxvQkFBQTtBQUNKOztBQUNFO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0FBRUo7O0FBQUU7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsTUFBQTtFQUNBLHFDQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FBR0o7O0FBREU7RUFDSSxpQkFBQTtFQUNBLGVBQUE7QUFJTjs7QUFERTtFQUNFLGlCQUFBO0FBSUo7O0FBRkU7RUFDRSxnQkFBQTtBQUtKOztBQUhFO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0FBTU47O0FBSkU7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7QUFPSjs7QUFMRTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBUUo7O0FBTkE7RUFDSSxhQUFBO0FBU0o7O0FBUEE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7QUFVSjs7QUFSQTtFQUNJLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBV0o7O0FBVEE7RUFDSSxnQ0FBQTtBQVlKOztBQVZBO0VBQ0ksK0JBQUE7QUFhSjs7QUFYQTtFQUNJLGVBQUE7RUFDQSxnQ0FBQTtBQWNKOztBQVpBO0VBQ0ksU0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFlSjs7QUFiQTtFQUVJLGFBQUE7QUFlSjs7QUFiQTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGVBQUE7QUFnQko7O0FBZEE7RUFDSSxtQkFBQTtFQUNBLGlCQUFBO0FBaUJKOztBQWZBO0VBQ0ksU0FBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUFrQko7O0FBZkE7RUFDSSxhQUFBO0VBQ0EsNkJBQUE7QUFrQko7O0FBaEJBO0VBQ0ksVUFBQTtBQW1CSjs7QUFqQkE7RUFDSSxrQkFBQTtFQUNBLGNBQUE7QUFvQko7O0FBaEJBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtBQW1CSjs7QUFoQkE7RUFDSSxZQUFBO0FBbUJKOztBQWpCQTtFQUNJLDZCQUFBO0FBb0JKOztBQWpCQTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBb0JKOztBQWxCQTtFQUNJLGNBQUE7RUFDQSxhQUFBO0FBcUJKOztBQW5CQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUFzQko7O0FBbkJBO0VBQ0U7SUFDRSxXQUFBO0VBc0JGOztFQW5CRjtJQUNJLFlBQUE7RUFzQkY7O0VBcEJGO0lBQ0ksWUFBQTtFQXVCRjs7RUFyQkY7SUFDSSxlQUFBO0VBd0JGOztFQXRCRjtJQUNJLFVBQUE7RUF5QkY7O0VBdkJGO0lBQ0ksZ0JBQUE7RUEwQkY7O0VBeEJEO0lBQ0csWUFBQTtFQTJCRjs7RUF6QkE7SUFDRSxZQUFBO0VBNEJGOztFQTFCQTtJQUNFLGVBQUE7RUE2QkY7O0VBM0JBO0lBQ0UsaUJBQUE7RUE4QkY7O0VBNUJBO0lBQ0UsWUFBQTtFQStCRjtBQUNGIiwiZmlsZSI6Im1haW4tbWVudS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi5oZWFkZXJ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGJhY2tncm91bmQ6ICNmY2VmNTBcbn1cbmlvbi1idXR0b24ge1xuICAgIC0tYmFja2dyb3VuZDogI0UxRTFFMTtcbiAgICAtLWNvbG9yOiAjMDAwOyBcbiAgICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgfVxuICBpb24tY29udGVudHtcbiAgICAtLWJhY2tncm91bmQ6I2ZmZiA7XG4gICAgLS1jb2xvcjpibGFja1xufVxuICAuY292ZXIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgdG9wOiAwO1xuICAgIGJhY2tncm91bmQ6IHJnYigyNTUgMjU1IDI1NSAvIDc5JSk7O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMFxuICB9XG4gIC5jb3ZlciBoMSB7XG4gICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgIG1hcmdpbi10b3A6IDEwJVxuICB9XG5cbiAgLmJhY2sge1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICB9XG4gIC5iYWNrSWZSaWdodHtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICB9XG4gIC5iYWNrIHAgLCAuYmFja0lmUmlnaHQgcHtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgZm9udC1zaXplOiA1dnc7XG4gIH1cbiAgLmJhY2sgaW9uLWJ1dHRvbiAsIC5iYWNrSWZSaWdodCBpb24tYnV0dG9ue1xuICAgIC0tcGFkZGluZy1zdGFydDogMmVtO1xuICAgIC0tcGFkZGluZy1lbmQ6IDJlbTtcbiAgICAtLWJvcmRlci1yYWRpdXM6NXB4O1xuICAgIG1hcmdpbi10b3A6IDIlO1xuICAgIGZvbnQtc2l6ZTogNXZ3O1xuICAgIGhlaWdodDogYXV0bztcbiAgICBtYXJnaW4tYm90dG9tOiA1JTtcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICB9XG4gIC5wcm9kdWN0c3tcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgaGVpZ2h0OiA1MnZoO1xuICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcbn1cbi5wcm9kdWN0cyBpbWcge1xuICAgIGhlaWdodDogMTUwcHg7XG59XG4ucHJvZHVjdHMgLnByaWNle1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1zaXplOiAxMXB4XG59XG4ucHJvZHVjdHMgLm5hbWV7XG4gICAgZm9udC1zaXplOiAuOHJlbTtcbiAgICBtYXJnaW4tYm90dG9tOjVweDtcbiAgICBtYXJnaW4tdG9wOiAwO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc2l6ZTogM3Z3O1xufVxuLnByb2R1Y3RzIC5yb3dPbmV7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjMmMyYzI7XG59XG4uY29sT25le1xuICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNjMmMyYzI7XG59XG4ubWVudUl0ZW17XG4gICAgcGFkZGluZzogMzBweCAwO1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjYzJjMmMyXG59XG4ubWVudUl0ZW0gcHtcbiAgICBtYXJnaW46IDA7XG4gICAgZm9udC1zaXplOiAuNXJlbTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zaXplOiAzdnc7XG59XG4ubWVudUl0ZW0gaW1nIHtcbiAgIFxuICAgIGhlaWdodDoxNTBweDtcbn1cbi5wcmljZV9uYW1le1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIGZvbnQtc2l6ZTogMTBweDtcbn1cbi5teU9yZGVye1xuICAgIGJhY2tncm91bmQ6ICNFMUUxRTE7XG4gICAgcGFkZGluZyA6NXB4IDEwcHhcbn1cbi5teU9yZGVyIGg0IHtcbiAgICBtYXJnaW46IDA7XG4gICAgZm9udC1zaXplOiA1dnc7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgcGFkZGluZzogMjBweCAxMHB4O1xufVxuXG4uY29uZmlybU9yQ2FuY2Vse1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG59XG4uY29uZmlybU9yQ2FuY2VsIGlvbi1idXR0b257XG4gICAgd2lkdGg6IDMzJTtcbn1cbi5mb3RlciBwIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiA1dnc7XG5cbn1cblxuLmZvb3RlciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJvdHRvbTogMSVcbn1cblxuLkNvbnRlbnQge1xuICAgIHBhZGRpbmc6IDVweDtcbn1cbi5Db250ZW50IC5uYXZnYXRpb24gZGl2IHtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgZ3JheTtcbn1cblxuLkNvbnRlbnQgLm5hdmdhdGlvbntcbiAgICBvdmVyZmxvdy15OiBzY3JvbGw7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIG1hcmdpbi10b3A6IC0xNyU7XG4gICAgYmFja2dyb3VuZDogI2YwZjBmMDtcbiAgICBoZWlnaHQ6Njl2aDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uY29uZmlybU9yQ2FuY2VsIGlvbi1idXR0b257XG4gICAgZm9udC1zaXplOiA0dnc7XG4gICAgaGVpZ2h0OiAxMTJweDtcbn1cbi5Db250ZW50IC5tYWluTWVudXtcbiAgICBmb250LXNpemU6IDNyZW07XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgbWFyZ2luLXRvcDogNTAlO1xufVxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6NzY4cHgpe1xuICAuaW1nUHJvZHVjdHtcbiAgICB3aWR0aDogODFweDtcbn1cblxuLmJhY2sgaW9uLWJ1dHRvbntcbiAgICBoZWlnaHQ6IDM2cHg7XG59XG4uYmFja0lmUmlnaHQgaW9uLWJ1dHRvbntcbiAgICBoZWlnaHQ6IDM2cHg7XG59XG4uQ29udGVudCAubWFpbk1lbnV7XG4gICAgZm9udC1zaXplOiAxM3B4O1xufVxuLkNvbnRlbnR7XG4gICAgcGFkZGluZzogMFxufVxuLm5hdmdhdGlvbntcbiAgICBtYXJnaW4tdG9wOiAtMTklO1xufVxuIC5wcm9kdWN0cyBpbWd7XG4gICAgaGVpZ2h0OiA1NXB4O1xuICB9XG4gIC5tZW51SXRlbSBpbWd7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICB9XG4gIC5tZW51SXRlbXtcbiAgICBwYWRkaW5nOiAxNXB4IDA7XG4gIH1cbiAgLm15T3JkZXIgaDR7XG4gICAgcGFkZGluZzogMnB4IDEwcHg7XG4gIH1cbiAgLmNvbmZpcm1PckNhbmNlbCBpb24tYnV0dG9ue1xuICAgIGhlaWdodDogNDRweDtcbiAgfVxufSJdfQ== */";

/***/ }),

/***/ 3691:
/*!****************************************************************!*\
  !*** ./src/app/pages/main-menu/main-menu.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"header\">\n  <img class=\"imgProduct \" src=\"assets/images/bingo.png\">\n</div>\n\n<ion-content [dir]=\"dir\">\n  <div class=\"\">\n    <div  [ngClass]=\"{'back':dir == 'ltr', 'backIfRight':dir == 'rtl'}\">\n      <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n    </div>\n\n    <section class=\"Content\">\n      <ion-grid style=\"padding: 0\">\n        <ion-row>\n          <ion-col  size=\"3\" class=\"navgation\">\n              <p class=\"mainMenu\"> {{Menu}} </p>\n            <div>\n              <!-- (click)=\"gotToSugg()\"  -->\n              <div class=\"menuItem\" routerLink=\"/compo\">\n                <img src=\"assets/images/mostSelling.png\">\n                <p>{{Compo}}</p>\n              </div>\n              <div class=\"menuItem\" (click)=\"gotToDetails('Discount')\">\n                <img src=\"assets/images/discount.png\">\n                <p>{{discount}}</p>\n              </div>\n              <div  class=\"menuItem\" routerLink=\"/promtions\">\n                <img src=\"assets/images/promotion.png\">\n                <p>{{promotions}}</p>\n              </div>\n              <div *ngFor=\"let item of categoris\" class=\"menuItem\" (click)=\"gotToDetails(item)\">\n                <img src=\"{{item.Image}}\">\n                <p>{{item.Name}}</p>\n              </div>\n            </div>\n          </ion-col>\n          <ion-col>\n            <div class=\"products\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col size=\"4\" class=\"rowOne colOne\">\n                    <div routerLink=\"/compo\">\n                      <img src=\"assets/images/mostSelling.png\">\n                      <p class=\"name\">{{Compo}}</p>\n                    </div>\n                  </ion-col>\n                  <ion-col size=\"4\" class=\"rowOne colOne\">\n                    <div (click)=\"gotToDetails('Discount')\">\n                      <img src=\"assets/images/discount.png\">\n                      <p class=\"name\">{{discount}}</p>\n                    </div>\n                  </ion-col>\n                  <ion-col size=\"4\" class=\"rowOne colOne\">\n                    <div routerLink=\"/promtions\">\n                      <img src=\"assets/images/promotion.png\">\n                      <p class=\"name\">{{promotions}}</p>\n                    </div>\n                  </ion-col>\n                  <!-- [ngClass]=\"{'colOne':item.status == false}\" -->\n                  <ion-col size=\"4\" class=\"rowOne colOne\" \n                    *ngFor=\"let item of categoris ; let i = index\" (click)=\"gotToDetails(item)\">\n                    <img src=\"{{item.Image}}\">\n                    <p class=\"name\">{{item.Name}}</p>\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </section>\n  </div>\n\n  <section class=\"footer\">\n    <div class=\"myOrder\">\n      <h4>{{MyOrder}}</h4>\n    </div>\n    <div class=\"foter\">\n      <p>{{arrOfModLength}}</p>\n      <div class=\"confirmOrCancel\" dir=\"ltr\">\n        <ion-button (click)=\"cancelOrder()\" [disabled]=\"disalbedButton\">{{Cancel}}</ion-button>\n        <ion-button (click)=\"Done()\" [disabled]='disalbedButton'>{{OrderDone}}</ion-button>\n      </div>\n    </div>\n  </section>\n\n\n\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_main-menu_main-menu_module_ts.js.map