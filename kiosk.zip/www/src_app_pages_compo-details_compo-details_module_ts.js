"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_compo-details_compo-details_module_ts"],{

/***/ 4059:
/*!*********************************************************************!*\
  !*** ./src/app/pages/compo-details/compo-details-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompoDetailsPageRoutingModule": () => (/* binding */ CompoDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _compo_details_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./compo-details.page */ 5231);




const routes = [
    {
        path: '',
        component: _compo_details_page__WEBPACK_IMPORTED_MODULE_0__.CompoDetailsPage
    }
];
let CompoDetailsPageRoutingModule = class CompoDetailsPageRoutingModule {
};
CompoDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CompoDetailsPageRoutingModule);



/***/ }),

/***/ 5445:
/*!*************************************************************!*\
  !*** ./src/app/pages/compo-details/compo-details.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompoDetailsPageModule": () => (/* binding */ CompoDetailsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _compo_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./compo-details-routing.module */ 4059);
/* harmony import */ var _compo_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./compo-details.page */ 5231);







let CompoDetailsPageModule = class CompoDetailsPageModule {
};
CompoDetailsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _compo_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.CompoDetailsPageRoutingModule
        ],
        declarations: [_compo_details_page__WEBPACK_IMPORTED_MODULE_1__.CompoDetailsPage]
    })
], CompoDetailsPageModule);



/***/ }),

/***/ 5231:
/*!***********************************************************!*\
  !*** ./src/app/pages/compo-details/compo-details.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompoDetailsPage": () => (/* binding */ CompoDetailsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _compo_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./compo-details.page.html?ngResource */ 4881);
/* harmony import */ var _compo_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./compo-details.page.scss?ngResource */ 278);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6362);







let CompoDetailsPage = class CompoDetailsPage {
    constructor(rest, location, route) {
        this.rest = rest;
        this.location = location;
        this.route = route;
        this.arrOfProductSize = [];
        this.count = 0;
        this.ifCount = false;
    }
    ngOnInit() {
        this.langId = localStorage.getItem('lang');
        this.comboName = sessionStorage.getItem("comboName");
        if (this.langId == '1') {
            this.dir = "rtl";
            this.Back = "رجوع";
            this.Cancel = "إلغاء";
            this.addChange = "اضف الي العربة";
            this.LE = "جنيه";
            this.SelectSize = "اختر الحجم";
        }
        else {
            this.Back = "Back";
            this.dir = "ltr";
            this.Cancel = "Cancel";
            this.addChange = "Add To Order";
            this.LE = "LE";
            this.SelectSize = "Select Size";
        }
        this.getDetailsOfCombo();
    }
    getDetailsOfCombo() {
        this.objOfCombo = JSON.parse(sessionStorage.getItem('productOfCombo'));
        console.log(this.objOfCombo);
        let id = sessionStorage.getItem('comboId');
        let totalPrice = 0;
        if (this.objOfCombo.SizeProductsLst.length != 0) {
            this.name = this.objOfCombo.Name;
            this.desc = this.objOfCombo.description;
            this.image = this.objOfCombo.image;
            if (this.image == "") {
                this.image = "assets/images/kiosk.png";
            }
            this.arrayOfProducts = this.objOfCombo.SizeProductsLst;
            for (let i = 0; i < this.arrayOfProducts.length; i++) {
                totalPrice = 0;
                for (let j = 0; j < this.arrayOfProducts[i].products.length; j++) {
                    totalPrice = totalPrice + this.arrayOfProducts[i].products[j].Price;
                    this.arrayOfProducts[i].count = 0;
                }
                this.arrayOfProducts[i].totalPrice = totalPrice;
                this.arrayOfProducts[i].status = false;
            }
        }
    }
    getItem(item) {
        for (let i = 0; i < this.arrayOfProducts.length; i++) {
            this.arrayOfProducts[i].status = false;
        }
        item.status = true;
        this.arrOfProductSize = [];
        let arrOfProd = [];
        for (let i = 0; i < item.products.length; i++) {
            arrOfProd.push({
                Id: item.products[i].Id,
                Name: item.products[i].Name,
                Price: item.products[i].Price,
                count: this.count,
                status: false
            });
        }
        let obj = {
            ingridtArr: [],
            modfire: [],
            Prdoucts: arrOfProd
        };
        this.arrOfProductSize.push(obj);
        console.log(item);
    }
    plus(item) {
        this.ifCount = true;
        item.count = item.count + 1;
        for (let i = 0; i < item.products.length; i++) {
            item.products[i].count = item.count;
        }
        console.log(this.arrayOfProducts);
    }
    minus(item) {
        this.ifCount = true;
        if (item.count > 1) {
            item.count = item.count - 1;
            for (let i = 0; i < item.products.length; i++) {
                item.products[i].count = item.count;
            }
        }
    }
    addOrder() {
        let arrOfProd = [];
        let arrOfObj = [];
        for (let i = 0; i < this.arrayOfProducts.length; i++) {
            arrOfProd = [];
            if (this.arrayOfProducts[i].count != 0) {
                for (let j = 0; j < this.arrayOfProducts[i].products.length; j++) {
                    arrOfProd.push({
                        Id: this.arrayOfProducts[i].products[j].Id,
                        Name: this.arrayOfProducts[i].products[j].Name,
                        Price: this.arrayOfProducts[i].products[j].Price,
                        count: this.arrayOfProducts[i].products[j].count,
                        sizeId: this.arrayOfProducts[i].sizeId,
                        sizeName: this.arrayOfProducts[i].SizeName,
                        compoName: this.comboName,
                        parentCombo: this.objOfCombo.Name
                    });
                }
                let obj = {
                    ingridtArr: [],
                    modfire: [],
                    Prdoucts: arrOfProd
                };
                arrOfObj.push(obj);
            }
        }
        console.log("arrOfProd", arrOfObj);
        let dumyarr = JSON.parse(sessionStorage.getItem('arrOfModfire'));
        if (dumyarr) {
            for (let i = 0; i < arrOfObj.length; i++) {
                dumyarr.push(arrOfObj[i]);
            }
            sessionStorage.setItem('arrOfModfire', JSON.stringify(dumyarr));
        }
        else {
            sessionStorage.setItem('arrOfModfire', JSON.stringify(arrOfObj));
        }
        this.rest.sendObsData('true');
        this.route.navigateByUrl('/main_menu');
    }
    cancel() {
        this.route.navigateByUrl('/main_menu');
    }
    goBack() {
        this.location.back();
    }
};
CompoDetailsPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__.Location },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
CompoDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-compo-details',
        template: _compo_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_compo_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CompoDetailsPage);



/***/ }),

/***/ 278:
/*!************************************************************************!*\
  !*** ./src/app/pages/compo-details/compo-details.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcef50;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: black;\n  text-transform: none;\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 5%;\n  font-size: 5vw;\n  height: 100px;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\nion-content {\n  --background:#fff ;\n  --color: black;\n  font-size: 3rem;\n}\n\nh3 {\n  font-size: 3rem;\n  margin-bottom: 5%;\n}\n\n.nameAndDesc {\n  font-size: 2.5rem;\n}\n\n.nameAndDesc span {\n  font-size: 3rem;\n}\n\n.menuItem img {\n  height: 150px;\n}\n\n.mainSecion {\n  margin: 10px 20px;\n  height: 54vh;\n  overflow: scroll;\n}\n\n.nameOfProduct span {\n  background: gray;\n  padding: 10px;\n}\n\n.product {\n  display: flex;\n}\n\n.size {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 5%;\n}\n\n.ifClick {\n  background: gainsboro;\n  padding: 6;\n  margin-bottom: 10px;\n  border-radius: 10px;\n}\n\n.itemOfSize {\n  display: flex;\n  width: 75%;\n}\n\n.itemOfSize p {\n  margin: 12px 10px 0 10px;\n}\n\n.itemSize {\n  background: #3a3a3a;\n  margin-right: 5% !important;\n  height: 100px;\n  width: 100px;\n  text-align: center;\n  padding-top: 18px;\n  margin-top: 30px !important;\n  color: #fff;\n}\n\n.quantity p {\n  font-size: 5vw;\n}\n\n.plus {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.plus ion-button {\n  --background: #fcef50;\n  color: #000;\n  font-size: 5vw;\n  height: 113px;\n}\n\n.plus div {\n  display: flex;\n}\n\n.count {\n  justify-content: center;\n  align-items: center;\n}\n\n.count p {\n  background: #bababa;\n  padding: 24px 72px;\n  border-radius: 5px;\n  margin: 22px 15px 0 15px;\n}\n\n.footer {\n  position: absolute;\n  bottom: 1%;\n  width: 100%;\n}\n\n.footer div {\n  display: flex;\n  justify-content: space-around;\n}\n\n.footer ion-button {\n  width: 35%;\n  font-size: 4vw;\n  height: 120px;\n}\n\n@media only screen and (max-width: 768px) {\n  .nameAndDesc {\n    font-size: 1.5rem;\n  }\n\n  .nameAndDesc span {\n    font-size: 1rem;\n  }\n\n  h3 {\n    font-size: 1rem;\n  }\n\n  .size {\n    font-size: 1rem;\n  }\n\n  .itemSize {\n    background: #3a3a3a;\n    margin-right: 5% !important;\n    height: 49px;\n    width: 46px;\n    text-align: center;\n    padding-top: 18px;\n    margin-top: 0 !important;\n    color: #fff;\n  }\n\n  .itemOfSize p {\n    margin: 2px 10px 0 10px;\n    font-size: 12px;\n  }\n\n  .footer ion-button {\n    font-size: 13px;\n    height: 39px;\n  }\n\n  h3 {\n    margin-top: 0;\n  }\n\n  .mainSecion {\n    margin-top: 0;\n  }\n\n  .back ion-button {\n    margin-top: 0;\n  }\n\n  .count p {\n    background: #bababa;\n    padding: 8px 48px;\n    border-radius: 5px;\n    margin: 11px 15px 0 15px;\n  }\n\n  .plus ion-button {\n    --background: #fcef50;\n    color: #000;\n    font-size: 3vw;\n    height: 37px;\n  }\n\n  .imgProduct {\n    height: 71px;\n  }\n\n  .menu {\n    height: 67vh;\n    margin-top: -19%;\n  }\n\n  .menuItem {\n    padding: 12px 0;\n  }\n\n  .menuItem img {\n    height: 50px;\n    width: auto;\n  }\n\n  .back ion-button {\n    height: 36px;\n  }\n\n  .menu .mainMenu {\n    font-size: 13px;\n  }\n\n  .products img {\n    width: auto;\n    height: 90px;\n  }\n\n  .confirmOrCancel ion-button {\n    height: 44px;\n  }\n\n  .ifClick {\n    padding: 6px;\n    border-radius: 10px;\n  }\n\n  .cover2 {\n    height: 23vh;\n  }\n\n  .next {\n    height: 36px !important;\n  }\n\n  .back ion-button, .backIfRight ion-button {\n    height: 41px;\n  }\n\n  .next {\n    bottom: 25%;\n    left: 5px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXBvLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksa0JBQUE7RUFDQSxtQkFBQTtBQUFKOztBQUVBO0VBQ0kscUJBQUE7RUFDQSxjQUFBO0VBQ0Esb0JBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7QUFDSjs7QUFFRTtFQUNFLGlCQUFBO0FBQ0o7O0FBQ0U7RUFDRSxnQkFBQTtBQUVKOztBQUFFO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQUdKOztBQURBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FBSUo7O0FBRkE7RUFDSSxpQkFBQTtBQUtKOztBQUhBO0VBQ0ksZUFBQTtBQU1KOztBQUpBO0VBQ0ksYUFBQTtBQU9KOztBQUpBO0VBQ0ksaUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFPSjs7QUFMQTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtBQVFKOztBQU5BO0VBQ0ksYUFBQTtBQVNKOztBQVBBO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsaUJBQUE7QUFVSjs7QUFQQTtFQUNJLHFCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUFVSjs7QUFQQTtFQUNJLGFBQUE7RUFDQSxVQUFBO0FBVUo7O0FBUkE7RUFDSSx3QkFBQTtBQVdKOztBQVRBO0VBQ0ksbUJBQUE7RUFDQSwyQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLDJCQUFBO0VBQ0EsV0FBQTtBQVlKOztBQVJBO0VBQ0ksY0FBQTtBQVdKOztBQVRFO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUFZSjs7QUFWRTtFQUNJLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0FBYU47O0FBWEU7RUFDSSxhQUFBO0FBY047O0FBWkU7RUFDSSx1QkFBQTtFQUNBLG1CQUFBO0FBZU47O0FBYkU7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSx3QkFBQTtBQWdCSjs7QUFaRTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUFlSjs7QUFiRTtFQUNFLGFBQUE7RUFDQSw2QkFBQTtBQWdCSjs7QUFkRTtFQUNFLFVBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQWlCSjs7QUFiQTtFQUNJO0lBQ0ksaUJBQUE7RUFnQk47O0VBZEU7SUFDSSxlQUFBO0VBaUJOOztFQWZFO0lBQ0ksZUFBQTtFQWtCTjs7RUFoQkU7SUFDSSxlQUFBO0VBbUJOOztFQWpCRTtJQUNJLG1CQUFBO0lBQ0EsMkJBQUE7SUFDQSxZQUFBO0lBQ0EsV0FBQTtJQUNBLGtCQUFBO0lBQ0EsaUJBQUE7SUFDQSx3QkFBQTtJQUNBLFdBQUE7RUFvQk47O0VBbEJFO0lBQ0ksdUJBQUE7SUFDQSxlQUFBO0VBcUJOOztFQW5CRTtJQUNJLGVBQUE7SUFDQSxZQUFBO0VBc0JOOztFQXBCRTtJQUNJLGFBQUE7RUF1Qk47O0VBckJFO0lBQ0ksYUFBQTtFQXdCTjs7RUF0QkU7SUFDSSxhQUFBO0VBeUJOOztFQXZCRTtJQUNJLG1CQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtJQUNBLHdCQUFBO0VBMEJOOztFQXhCRTtJQUNJLHFCQUFBO0lBQ0EsV0FBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0VBMkJOOztFQXpCRTtJQUNJLFlBQUE7RUE0Qk47O0VBMUJFO0lBQ0ksWUFBQTtJQUNBLGdCQUFBO0VBNkJOOztFQTNCRTtJQUNJLGVBQUE7RUE4Qk47O0VBNUJFO0lBQ0ksWUFBQTtJQUNBLFdBQUE7RUErQk47O0VBN0JFO0lBQ0ksWUFBQTtFQWdDTjs7RUE5QkU7SUFDSSxlQUFBO0VBaUNOOztFQS9CRTtJQUNJLFdBQUE7SUFDQSxZQUFBO0VBa0NOOztFQS9CRTtJQUNFLFlBQUE7RUFrQ0o7O0VBaENFO0lBQ0ksWUFBQTtJQUNBLG1CQUFBO0VBbUNOOztFQWpDRTtJQUNJLFlBQUE7RUFvQ047O0VBbENFO0lBQ0ksdUJBQUE7RUFxQ047O0VBbkNFO0lBQ0ksWUFBQTtFQXNDTjs7RUFwQ0k7SUFDRSxXQUFBO0lBQ0EsU0FBQTtFQXVDTjtBQUNGIiwiZmlsZSI6ImNvbXBvLWRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4uaGVhZGVye1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kOiAjZmNlZjUwXG59XG5pb24tYnV0dG9uIHtcbiAgICAtLWJhY2tncm91bmQ6ICNFMUUxRTE7XG4gICAgLS1jb2xvcjogYmxhY2s7IFxuICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICAgIC0tcGFkZGluZy1zdGFydDogMmVtO1xuICAgIC0tcGFkZGluZy1lbmQ6IDJlbTtcbiAgICAtLWJvcmRlci1yYWRpdXM6NXB4O1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICAgIGZvbnQtc2l6ZTogNXZ3O1xuICAgIGhlaWdodDogMTAwcHg7XG5cbiAgfVxuICAuYmFjayB7XG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIH1cbiAgLmJhY2tJZlJpZ2h0e1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gIH1cbiAgaW9uLWNvbnRlbnR7XG4gICAgLS1iYWNrZ3JvdW5kOiNmZmYgO1xuICAgIC0tY29sb3I6IGJsYWNrO1xuICAgIGZvbnQtc2l6ZTogM3JlbVxufVxuaDMge1xuICAgIGZvbnQtc2l6ZTogM3JlbTtcbiAgICBtYXJnaW4tYm90dG9tOjUlXG59XG4ubmFtZUFuZERlc2Mge1xuICAgIGZvbnQtc2l6ZTogMi41cmVtO1xufVxuLm5hbWVBbmREZXNjIHNwYW4ge1xuICAgIGZvbnQtc2l6ZTogM3JlbTtcbn1cbi5tZW51SXRlbSBpbWcge1xuICAgIGhlaWdodDogMTUwcHg7XG59XG5cbi5tYWluU2VjaW9ue1xuICAgIG1hcmdpbjogMTBweCAyMHB4O1xuICAgIGhlaWdodDogNTR2aDtcbiAgICBvdmVyZmxvdzogc2Nyb2xsXG59XG4ubmFtZU9mUHJvZHVjdCBzcGFuIHtcbiAgICBiYWNrZ3JvdW5kOiBncmF5O1xuICAgIHBhZGRpbmc6IDEwcHhcbn1cbi5wcm9kdWN0e1xuICAgIGRpc3BsYXk6IGZsZXg7XG59XG4uc2l6ZSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgbWFyZ2luLWJvdHRvbTo1JVxufVxuXG4uaWZDbGljayB7XG4gICAgYmFja2dyb3VuZDogZ2FpbnNib3JvO1xuICAgIHBhZGRpbmc6NjtcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHhcbn1cblxuLml0ZW1PZlNpemV7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICB3aWR0aDogNzUlO1xufVxuLml0ZW1PZlNpemUgcCB7XG4gICAgbWFyZ2luOiAxMnB4IDEwcHggMCAxMHB4O1xufVxuLml0ZW1TaXple1xuICAgIGJhY2tncm91bmQ6ICMzYTNhM2E7XG4gICAgbWFyZ2luLXJpZ2h0OiA1JSAhaW1wb3J0YW50O1xuICAgIGhlaWdodDogMTAwcHg7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwYWRkaW5nLXRvcDogMThweDtcbiAgICBtYXJnaW4tdG9wOiAzMHB4ICFpbXBvcnRhbnQ7XG4gICAgY29sb3I6ICNmZmY7XG59XG5cblxuLnF1YW50aXR5IHAge1xuICAgIGZvbnQtc2l6ZTogNXZ3XG4gIH1cbiAgLnBsdXMge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgfVxuICAucGx1cyBpb24tYnV0dG9ue1xuICAgICAgLS1iYWNrZ3JvdW5kOiAjZmNlZjUwO1xuICAgICAgY29sb3I6ICMwMDA7XG4gICAgICBmb250LXNpemU6IDV2dztcbiAgICAgIGhlaWdodDogMTEzcHg7XG4gIH1cbiAgLnBsdXMgZGl2e1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgfVxuICAuY291bnQge1xuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyXG4gIH1cbiAgLmNvdW50IHAge1xuICAgIGJhY2tncm91bmQ6ICNiYWJhYmE7XG4gICAgcGFkZGluZzogMjRweCA3MnB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICBtYXJnaW46IDIycHggMTVweCAwIDE1cHg7XG5cbiAgfVxuXG4gIC5mb290ZXIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBib3R0b206IDElO1xuICAgIHdpZHRoOiAxMDAlXG4gIH1cbiAgLmZvb3RlciBkaXYge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmRcbiAgfVxuICAuZm9vdGVyIGlvbi1idXR0b257XG4gICAgd2lkdGg6IDM1JTtcbiAgICBmb250LXNpemU6IDR2dztcbiAgICBoZWlnaHQ6IDEyMHB4O1xuICAgIFxuXG4gIH1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDo3NjhweCl7XG4gICAgLm5hbWVBbmREZXNje1xuICAgICAgICBmb250LXNpemU6IDEuNXJlbVxuICAgIH1cbiAgICAubmFtZUFuZERlc2Mgc3BhbntcbiAgICAgICAgZm9udC1zaXplOiAxcmVtXG4gICAgfVxuICAgIGgze1xuICAgICAgICBmb250LXNpemU6IDFyZW1cbiAgICB9XG4gICAgLnNpemV7XG4gICAgICAgIGZvbnQtc2l6ZTogMXJlbVxuICAgIH1cbiAgICAuaXRlbVNpemV7XG4gICAgICAgIGJhY2tncm91bmQ6ICMzYTNhM2E7XG4gICAgICAgIG1hcmdpbi1yaWdodDogNSUgIWltcG9ydGFudDtcbiAgICAgICAgaGVpZ2h0OiA0OXB4O1xuICAgICAgICB3aWR0aDogNDZweDtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICBwYWRkaW5nLXRvcDogMThweDtcbiAgICAgICAgbWFyZ2luLXRvcDogMCAhaW1wb3J0YW50O1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICB9XG4gICAgLml0ZW1PZlNpemUgcCB7XG4gICAgICAgIG1hcmdpbjogMnB4IDEwcHggMCAxMHB4O1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgfVxuICAgIC5mb290ZXIgaW9uLWJ1dHRvbntcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICBoZWlnaHQ6IDM5cHg7XG4gICAgfVxuICAgIGgze1xuICAgICAgICBtYXJnaW4tdG9wOiAwXG4gICAgfVxuICAgIC5tYWluU2VjaW9ue1xuICAgICAgICBtYXJnaW4tdG9wOiAwXG4gICAgfVxuICAgIC5iYWNrIGlvbi1idXR0b257XG4gICAgICAgIG1hcmdpbi10b3A6IDBcbiAgICB9XG4gICAgLmNvdW50IHB7XG4gICAgICAgIGJhY2tncm91bmQ6ICNiYWJhYmE7XG4gICAgICAgIHBhZGRpbmc6IDhweCA0OHB4O1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgIG1hcmdpbjogMTFweCAxNXB4IDAgMTVweDtcbiAgICB9XG4gICAgLnBsdXMgaW9uLWJ1dHRvbntcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZmNlZjUwO1xuICAgICAgICBjb2xvcjogIzAwMDtcbiAgICAgICAgZm9udC1zaXplOiAzdnc7XG4gICAgICAgIGhlaWdodDogMzdweDtcbiAgICB9XG4gICAgLmltZ1Byb2R1Y3R7XG4gICAgICAgIGhlaWdodDogNzFweDtcbiAgICB9XG4gICAgLm1lbnUge1xuICAgICAgICBoZWlnaHQ6IDY3dmg7XG4gICAgICAgIG1hcmdpbi10b3A6IC0xOSU7XG4gICAgfVxuICAgIC5tZW51SXRlbXtcbiAgICAgICAgcGFkZGluZzogMTJweCAwO1xuICAgIH1cbiAgICAubWVudUl0ZW0gaW1nIHtcbiAgICAgICAgaGVpZ2h0OiA1MHB4O1xuICAgICAgICB3aWR0aDogYXV0b1xuICAgIH1cbiAgICAuYmFjayBpb24tYnV0dG9ue1xuICAgICAgICBoZWlnaHQ6IDM2cHg7XG4gICAgfVxuICAgIC5tZW51IC5tYWluTWVudXtcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgIH1cbiAgICAucHJvZHVjdHMgaW1ne1xuICAgICAgICB3aWR0aDogYXV0bztcbiAgICAgICAgaGVpZ2h0OiA5MHB4O1xuICAgICAgICBcbiAgICB9XG4gICAgLmNvbmZpcm1PckNhbmNlbCBpb24tYnV0dG9ue1xuICAgICAgaGVpZ2h0OiA0NHB4O1xuICAgIH1cbiAgICAuaWZDbGlja3tcbiAgICAgICAgcGFkZGluZzo2cHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHhcbiAgICB9XG4gICAgLmNvdmVyMntcbiAgICAgICAgaGVpZ2h0OjIzdmg7XG4gICAgfVxuICAgIC5uZXh0IHtcbiAgICAgICAgaGVpZ2h0OiAzNnB4ICFpbXBvcnRhbnQ7XG4gICAgfVxuICAgIC5iYWNrIGlvbi1idXR0b24gLCAuYmFja0lmUmlnaHQgaW9uLWJ1dHRvbntcbiAgICAgICAgaGVpZ2h0OiA0MXB4O1xuICAgICAgfVxuICAgICAgLm5leHQgIHtcbiAgICAgICAgYm90dG9tOiAyNSU7XG4gICAgICAgIGxlZnQ6IDVweDtcbiAgICB9XG4gIH0iXX0= */";

/***/ }),

/***/ 4881:
/*!************************************************************************!*\
  !*** ./src/app/pages/compo-details/compo-details.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"header\">\n  <img class=\"imgProduct \" src=\"assets/images/bingo.png\">\n</div>\n\n<ion-content [dir]=\"dir\">\n\n  <div class=\"back\" [ngClass]=\"{'back':dir == 'ltr','backIfRight':dir == 'rtl'}\">\n    <ion-button  (click)=\"goBack()\">{{Back}}</ion-button>\n  </div>\n  \n\n  <div class=\"product\">\n    <img class=\"imgProduct\" src=\"{{image}}\">\n    <p class=\"nameAndDesc\">\n      <span>{{name}}</span><br>\n      {{desc}}\n    </p>\n  </div>\n\n  <!-- [ngClass]=\"{'ifClick' : item.status == true}\" -->\n  <section class=\"mainSecion\">\n    <h3>{{SelectSize}}</h3>\n    <div class=\" ifClick\"  *ngFor=\"let item of arrayOfProducts\" >\n      <div class=\"size\">\n          <div class=\"itemOfSize\" >\n              <p class=\"itemSize\">{{item.SizeName[0]}}</p>\n              <div>\n                <div *ngFor=\"let product of item.products\">\n                  <p class=\"nameOfProduct\">\n                    {{product.Name}}\n                  </p>\n                </div>\n              </div>\n            </div>\n            <p class=\"price\"> {{item.totalPrice}} {{LE}}</p>\n      </div>\n      <div class=\"quantity\">\n          <div class=\"plus\" >\n            <div>\n              <ion-button  (click)=\"plus(item)\">+</ion-button>\n              <div class=\"count\">\n                <p>{{item.count}}</p>\n                <ion-button  (click)=\"minus(item)\">-</ion-button>\n              </div>\n            </div>\n          </div>\n        </div>\n    </div>\n  </section>\n\n \n\n    <div class=\"footer\" dir=\"ltr\">\n        <div>\n          <ion-button (click)=\"cancel()\">{{Cancel}}</ion-button>\n          <ion-button (click)=\"addOrder()\" [disabled]=\"!ifCount\" >{{addChange}}</ion-button>\n        </div>\n      </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_compo-details_compo-details_module_ts.js.map