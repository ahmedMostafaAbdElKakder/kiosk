"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_add-souce_add-souce_module_ts"],{

/***/ 9895:
/*!*************************************************************!*\
  !*** ./src/app/pages/add-souce/add-souce-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddSoucePageRoutingModule": () => (/* binding */ AddSoucePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _add_souce_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-souce.page */ 608);




const routes = [
    {
        path: '',
        component: _add_souce_page__WEBPACK_IMPORTED_MODULE_0__.AddSoucePage
    }
];
let AddSoucePageRoutingModule = class AddSoucePageRoutingModule {
};
AddSoucePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddSoucePageRoutingModule);



/***/ }),

/***/ 9275:
/*!*****************************************************!*\
  !*** ./src/app/pages/add-souce/add-souce.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddSoucePageModule": () => (/* binding */ AddSoucePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _add_souce_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-souce-routing.module */ 9895);
/* harmony import */ var _add_souce_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-souce.page */ 608);







let AddSoucePageModule = class AddSoucePageModule {
};
AddSoucePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _add_souce_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddSoucePageRoutingModule
        ],
        declarations: [_add_souce_page__WEBPACK_IMPORTED_MODULE_1__.AddSoucePage]
    })
], AddSoucePageModule);



/***/ }),

/***/ 608:
/*!***************************************************!*\
  !*** ./src/app/pages/add-souce/add-souce.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddSoucePage": () => (/* binding */ AddSoucePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _add_souce_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-souce.page.html?ngResource */ 4234);
/* harmony import */ var _add_souce_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-souce.page.scss?ngResource */ 6670);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);







let AddSoucePage = class AddSoucePage {
    constructor(rest, route, navCtr) {
        this.rest = rest;
        this.route = route;
        this.navCtr = navCtr;
        this.arrOfSouces = [];
    }
    ngOnInit() {
        this.langId = localStorage.getItem("lang");
        if (this.langId == '1') {
            this.dir = 'rtl';
            this.Back = "رجوع";
            this.Cancel = "إلغاء";
            this.addChange = "اضف المكونات";
            this.ingrdtiont = "المكونات";
            this.LE = "جنيه";
        }
        else {
            this.dir = 'ltr';
            this.Back = "Back";
            this.Cancel = "Cancel";
            this.addChange = "Apply Changes";
            this.ingrdtiont = "Ingredients";
            this.LE = "LE";
        }
        this.getData();
    }
    getData() {
        this.item = JSON.parse(sessionStorage.getItem('ModfireOfChose'));
        this.prdouct = JSON.parse(sessionStorage.getItem('ProductOfChose'));
        this.prdouctName = this.prdouct.Name;
        this.productPrice = this.prdouct.Price;
        this.productImage = this.prdouct.Image;
        this.rest.GetItemsbyProductId(this.langId, this.prdouct.Id).subscribe((res) => {
            console.log(res);
            if (res.length != 0) {
                this.arrOfSouces = res;
                for (let i = 0; i < this.arrOfSouces.length; i++) {
                    this.arrOfSouces[i].count = 0;
                }
            }
            else {
                console.log(res.length);
                let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
                this.item.ingridtArr = [];
                this.item.Prdoucts = [products];
                sessionStorage.setItem('ModfireOfChose', JSON.stringify(this.item));
                this.route.navigateByUrl('/quantity');
            }
        });
    }
    goCheckOut() {
        let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
        let ingridtArr = [];
        if (this.arrOfSouces.length != 0) {
            for (let i = 0; i < this.arrOfSouces.length; i++) {
                if (this.arrOfSouces[i].count != 0) {
                    ingridtArr.push(this.arrOfSouces[i]);
                }
            }
            console.log("inas", this.item);
            this.item.ingridtArr = ingridtArr;
            this.item.Prdoucts = [products];
            sessionStorage.setItem('ModfireOfChose', JSON.stringify(this.item));
            this.route.navigateByUrl('/quantity');
        }
        else {
            this.item.ingridtArr = [];
            this.item.Prdoucts = [products];
            sessionStorage.setItem('ModfireOfChose', JSON.stringify(this.item));
            this.route.navigateByUrl('/quantity');
        }
    }
    goBack() {
        this.route.navigateByUrl('/categoris');
    }
    minus(item) {
        if (item.count > 0) {
            item.count = item.count - 1;
        }
    }
    plus(item) {
        item.count = item.count + 1;
    }
};
AddSoucePage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController }
];
AddSoucePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-add-souce',
        template: _add_souce_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_add_souce_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AddSoucePage);



/***/ }),

/***/ 6670:
/*!****************************************************************!*\
  !*** ./src/app/pages/add-souce/add-souce.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcb400;\n}\n\nion-content {\n  --background: #fff;\n  --color: #000 ;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: #000;\n  text-transform: none;\n}\n\n.cover {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  left: 0%;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #fff;\n  top: 0;\n}\n\n.cover h1 {\n  font-weight: bold;\n  margin-top: 12%;\n  font-size: 5vw;\n  color: black;\n}\n\n.imgProduct {\n  width: auto;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.back, .backIfRight {\n  text-align: right;\n  text-transform: none;\n  margin-top: 5px;\n}\n\n.back ion-button, .backIfRight ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 5%;\n  font-size: 5vw;\n  height: 100px;\n  margin-bottom: 3%;\n}\n\n.order {\n  display: flex;\n  justify-content: space-between;\n}\n\n.orderName {\n  display: flex;\n}\n\n.orderName p {\n  margin-left: 5px;\n  font-size: 5vw;\n}\n\n.orderName img {\n  max-width: 250px;\n}\n\n.order .parg {\n  font-size: 5vw;\n}\n\n.addSouce {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 10px;\n}\n\n.addSouce ion-button {\n  --background: rgb(252, 180, 0);\n  color: #000;\n  height: 135px;\n  font-size: 5vw;\n}\n\n.count {\n  background: gainsboro;\n  height: 135px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-radius: 6px;\n  margin-top: 3px;\n  font-size: 5vw;\n}\n\n.count p {\n  margin: 0;\n}\n\n.extra {\n  margin-top: 6px;\n  font-size: 5vw;\n}\n\n.extra span {\n  font-size: 4vw;\n  color: gray;\n}\n\n.fotter {\n  position: absolute;\n  bottom: 1%;\n  width: 100%;\n}\n\n.fotter div {\n  display: flex;\n  justify-content: space-around;\n}\n\n.fotter ion-button {\n  width: 39%;\n  height: 138px;\n  font-size: 4vw;\n}\n\nh5 {\n  margin-top: 18px;\n  margin-bottom: 18px;\n  font-size: 7vw;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n\n@media only screen and (max-width: 768px) {\n  .orderName img {\n    width: 26%;\n  }\n\n  .imgProduct {\n    width: 82px;\n  }\n\n  .products img {\n    height: 74px;\n  }\n\n  .menuItem img {\n    height: 74px;\n  }\n\n  .fotter ion-button {\n    height: 44px;\n  }\n\n  .back ion-button {\n    margin-bottom: 0;\n    height: 36px;\n    margin-top: 0;\n  }\n\n  .addSouce ion-button {\n    height: 43px;\n    font-size: 4vw;\n  }\n\n  .count {\n    height: 43px;\n  }\n\n  .back ion-button, .backIfRight ion-button {\n    height: 41px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZC1zb3VjZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLG1CQUFBO0FBQ0Y7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLGNBQUE7QUFDSjs7QUFDQTtFQUNFLHFCQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0FBRUY7O0FBQUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsUUFBQTtFQUNBLHFDQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsTUFBQTtBQUdGOztBQURBO0VBQ0UsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFJRjs7QUFGRTtFQUNFLFdBQUE7QUFLSjs7QUFGRTtFQUNFLGlCQUFBO0FBS0o7O0FBSEU7RUFDRSxnQkFBQTtBQU1KOztBQUhFO0VBQ0UsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLGVBQUE7QUFNSjs7QUFKRTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUVBLGlCQUFBO0FBTUo7O0FBSkU7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7QUFPTjs7QUFMRTtFQUNJLGFBQUE7QUFRTjs7QUFORTtFQUNJLGdCQUFBO0VBQ0EsY0FBQTtBQVNOOztBQVBFO0VBQ0UsZ0JBQUE7QUFVSjs7QUFSRTtFQUNFLGNBQUE7QUFXSjs7QUFURTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBWU47O0FBVEU7RUFDSSw4QkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtBQVlOOztBQVZFO0VBQ0UscUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FBYUo7O0FBWEU7RUFDSSxTQUFBO0FBY047O0FBWkU7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQWVKOztBQWJFO0VBQ0UsY0FBQTtFQUNBLFdBQUE7QUFnQko7O0FBZEU7RUFDSSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FBaUJOOztBQWZFO0VBQ0UsYUFBQTtFQUNBLDZCQUFBO0FBa0JKOztBQWhCRTtFQUNFLFVBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtBQW1CSjs7QUFqQkU7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFvQko7O0FBakJFO0VBQ0U7SUFDRSxVQUFBO0VBb0JKOztFQWxCRTtJQUNFLFdBQUE7RUFxQko7O0VBbkJFO0lBQ0UsWUFBQTtFQXNCSjs7RUFwQkU7SUFDRSxZQUFBO0VBdUJKOztFQXJCRTtJQUNFLFlBQUE7RUF3Qko7O0VBdEJFO0lBQ0UsZ0JBQUE7SUFDQSxZQUFBO0lBQ0EsYUFBQTtFQXlCSjs7RUF2QkU7SUFDRSxZQUFBO0lBQ0EsY0FBQTtFQTBCSjs7RUF4QkU7SUFDRSxZQUFBO0VBMkJKOztFQXpCRTtJQUNFLFlBQUE7RUE0Qko7QUFDRiIsImZpbGUiOiJhZGQtc291Y2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlcntcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiByZ2IoMjUyLCAxODAsIDApXG59XG5cbmlvbi1jb250ZW50e1xuICAgIC0tYmFja2dyb3VuZDogI2ZmZjtcbiAgICAtLWNvbG9yOiAjMDAwXG59XG5pb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjRTFFMUUxO1xuICAtLWNvbG9yOiAjMDAwOyBcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG59XG4uY292ZXIge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGxlZnQ6IDAlO1xuICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNzkpO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xuICB0b3A6IDBcbn1cbi5jb3ZlciBoMSB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW4tdG9wOiAxMiU7XG4gIGZvbnQtc2l6ZTogNXZ3O1xuICBjb2xvcjogYmxhY2tcbn1cbiAgLmltZ1Byb2R1Y3R7XG4gICAgd2lkdGg6YXV0bztcbiAgfVxuXG4gIC5iYWNrIHtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgfVxuICAuYmFja0lmUmlnaHR7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgfVxuICBcbiAgLmJhY2sgLCAuYmFja0lmUmlnaHR7XG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gICAgbWFyZ2luLXRvcDogNXB4O1xuICB9XG4gIC5iYWNrIGlvbi1idXR0b24gLCAuYmFja0lmUmlnaHQgaW9uLWJ1dHRvbntcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDJlbTtcbiAgICAtLXBhZGRpbmctZW5kOiAyZW07XG4gICAgLS1ib3JkZXItcmFkaXVzOjVweDtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICBmb250LXNpemU6IDV2dztcbiAgICBoZWlnaHQ6IDEwMHB4O1xuXG4gICAgbWFyZ2luLWJvdHRvbTozJVxuICB9XG4gIC5vcmRlcntcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIH1cbiAgLm9yZGVyTmFtZXtcbiAgICAgIGRpc3BsYXk6IGZsZXhcbiAgfVxuICAub3JkZXJOYW1lIHAge1xuICAgICAgbWFyZ2luLWxlZnQ6IDVweDtcbiAgICAgIGZvbnQtc2l6ZTogNXZ3XG4gIH1cbiAgLm9yZGVyTmFtZSBpbWcge1xuICAgIG1heC13aWR0aDoyNTBweFxuICB9XG4gIC5vcmRlciAucGFyZ3tcbiAgICBmb250LXNpemU6IDV2d1xuICB9XG4gIC5hZGRTb3VjZSB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgbWFyZ2luLWJvdHRvbTogMTBweFxuICB9XG5cbiAgLmFkZFNvdWNlIGlvbi1idXR0b24ge1xuICAgICAgLS1iYWNrZ3JvdW5kOiByZ2IoMjUyLCAxODAsIDApO1xuICAgICAgY29sb3I6ICMwMDA7XG4gICAgICBoZWlnaHQ6IDEzNXB4O1xuICAgICAgZm9udC1zaXplOiA1dndcbiAgfVxuICAuY291bnQge1xuICAgIGJhY2tncm91bmQ6IGdhaW5zYm9ybztcbiAgICBoZWlnaHQ6IDEzNXB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XG4gICAgbWFyZ2luLXRvcDogM3B4O1xuICAgIGZvbnQtc2l6ZTogNXZ3O1xuICB9XG4gIC5jb3VudCBwIHtcbiAgICAgIG1hcmdpbjogMDtcbiAgfVxuICAuZXh0cmF7XG4gICAgbWFyZ2luLXRvcDogNnB4O1xuICAgIGZvbnQtc2l6ZTo1dnc7XG4gIH1cbiAgLmV4dHJhIHNwYW4ge1xuICAgIGZvbnQtc2l6ZTogNHZ3O1xuICAgIGNvbG9yOiBncmF5O1xuICB9XG4gIC5mb3R0ZXIge1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgYm90dG9tOiAxJTtcbiAgICAgIHdpZHRoOiAxMDAlXG4gIH1cbiAgLmZvdHRlciBkaXYge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmRcbiAgfVxuICAuZm90dGVyIGlvbi1idXR0b257XG4gICAgd2lkdGg6IDM5JTtcbiAgICBoZWlnaHQ6IDEzOHB4O1xuICAgIGZvbnQtc2l6ZTogNHZ3O1xuICB9XG4gIGg1IHtcbiAgICBtYXJnaW4tdG9wOiAxOHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDE4cHg7XG4gICAgZm9udC1zaXplOiA3dnc7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuXG4gIH1cbiAgQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjc2OHB4KXtcbiAgICAub3JkZXJOYW1lIGltZyB7XG4gICAgICB3aWR0aDogMjYlO1xuICAgIH1cbiAgICAuaW1nUHJvZHVjdHtcbiAgICAgIHdpZHRoOiA4MnB4O1xuICAgIH1cbiAgICAucHJvZHVjdHMgaW1ne1xuICAgICAgaGVpZ2h0OiA3NHB4O1xuICAgIH1cbiAgICAubWVudUl0ZW0gaW1ne1xuICAgICAgaGVpZ2h0OiA3NHB4O1xuICAgIH1cbiAgICAuZm90dGVyIGlvbi1idXR0b257XG4gICAgICBoZWlnaHQ6IDQ0cHg7XG4gICAgfVxuICAgIC5iYWNrIGlvbi1idXR0b257XG4gICAgICBtYXJnaW4tYm90dG9tOiAwO1xuICAgICAgaGVpZ2h0OiAzNnB4O1xuICAgICAgbWFyZ2luLXRvcDogMDtcbiAgICB9XG4gICAgLmFkZFNvdWNlIGlvbi1idXR0b257XG4gICAgICBoZWlnaHQ6IDQzcHg7XG4gICAgICBmb250LXNpemU6IDR2dztcbiAgICB9XG4gICAgLmNvdW50e1xuICAgICAgaGVpZ2h0OjQzcHg7XG4gICAgfVxuICAgIC5iYWNrIGlvbi1idXR0b24gLCAuYmFja0lmUmlnaHQgaW9uLWJ1dHRvbntcbiAgICAgIGhlaWdodDogNDFweDtcbiAgICB9XG4gIH0iXX0= */";

/***/ }),

/***/ 4234:
/*!****************************************************************!*\
  !*** ./src/app/pages/add-souce/add-souce.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <div>\n    <img class=\"imgProduct\" src=\"assets/images/panner.jpeg\">\n  </div>\n  <div class=\"cover\">\n    <h1>{{prdouctName}}</h1>\n  </div>\n</ion-header> -->\n<div class=\"header\">\n  <img class=\"imgProduct \" src=\"assets/images/kiosk.png\">\n</div>\n\n\n<ion-content [dir]=\"dir\">\n  <div [ngClass]=\"{'back':dir == 'ltr','backIfRight':dir == 'rtl'}\">\n    <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n  </div>\n  <section class=\"ion-padding-start ion-padding-end\">\n    <div class=\"order\">\n      <div class=\"orderName\">\n        <img src=\"{{productImage}}\">\n        <p>{{prdouctName}}</p>\n      </div>\n      <p class=\"parg\" *ngIf=\"langId != 1\">{{LE}} {{productPrice}}</p>\n      <p class=\"parg\" *ngIf=\"langId == 1\">{{productPrice}} {{LE}}</p>\n    </div>\n\n    <h5> {{ingrdtiont}}</h5>\n\n    <ion-grid>\n      <ion-row class=\"addSouce\" *ngFor=\"let item of arrOfSouces\">\n        <ion-col size=\"2\">\n          <ion-button (click)=\"plus(item)\">+</ion-button>\n        </ion-col>\n\n        <ion-col size=\"2\">\n          <ion-button (click)=\"minus(item)\">-</ion-button>\n        </ion-col>\n\n        <ion-col size=\"2\">\n          <div class=\"count\">\n            <p>{{item.count}}</p>\n          </div>\n        </ion-col>\n        <ion-col size=\"4\">\n          <p class=\"extra\">{{item.Name}}<br>\n            <span *ngIf=\"langId != 1\">{{LE}} {{item.Price}}</span>\n            <span *ngIf=\"langId == 1\">{{item.Price}} {{LE}}</span>\n          </p>\n        </ion-col>\n        <ion-col size=\"2\">\n          <img src=\"{{item.Image}}\">\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </section>\n  <div class=\"fotter\" dir=\"ltr\">\n    <div>\n      <ion-button (click)=\"goBack()\">{{Cancel}}</ion-button>\n      <ion-button (click)=\"goCheckOut()\">{{addChange}}</ion-button>\n    </div>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_add-souce_add-souce_module_ts.js.map