"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_choose-combo_choose-combo_module_ts"],{

/***/ 6773:
/*!*******************************************************************!*\
  !*** ./src/app/pages/choose-combo/choose-combo-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChooseComboPageRoutingModule": () => (/* binding */ ChooseComboPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _choose_combo_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./choose-combo.page */ 6722);




const routes = [
    {
        path: '',
        component: _choose_combo_page__WEBPACK_IMPORTED_MODULE_0__.ChooseComboPage
    }
];
let ChooseComboPageRoutingModule = class ChooseComboPageRoutingModule {
};
ChooseComboPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ChooseComboPageRoutingModule);



/***/ }),

/***/ 4990:
/*!***********************************************************!*\
  !*** ./src/app/pages/choose-combo/choose-combo.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChooseComboPageModule": () => (/* binding */ ChooseComboPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _choose_combo_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./choose-combo-routing.module */ 6773);
/* harmony import */ var _choose_combo_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./choose-combo.page */ 6722);







let ChooseComboPageModule = class ChooseComboPageModule {
};
ChooseComboPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _choose_combo_routing_module__WEBPACK_IMPORTED_MODULE_0__.ChooseComboPageRoutingModule
        ],
        declarations: [_choose_combo_page__WEBPACK_IMPORTED_MODULE_1__.ChooseComboPage]
    })
], ChooseComboPageModule);



/***/ }),

/***/ 6722:
/*!*********************************************************!*\
  !*** ./src/app/pages/choose-combo/choose-combo.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChooseComboPage": () => (/* binding */ ChooseComboPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _choose_combo_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./choose-combo.page.html?ngResource */ 8795);
/* harmony import */ var _choose_combo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./choose-combo.page.scss?ngResource */ 7114);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);






let ChooseComboPage = class ChooseComboPage {
    constructor(rest, route) {
        this.rest = rest;
        this.route = route;
        this.products = [];
        this.items = [];
        this.showModfire = false;
        this.ModifiresbyProductId = [];
        this.disalbedButton = true;
    }
    ngOnInit() {
        this.langId = localStorage.getItem('lang');
        if (this.langId == '1') {
            this.dir = "rtl";
            this.Menu = "قائمة الطلبات";
            this.Back = "رجوع";
            this.Cancel = "إلغاء الطلب";
            this.OrderDone = "دفع";
            this.MyOrder = "طلباتي - في المتجر";
            this.Modfires = "الاضافات";
            this.Next = "التالي";
            this.bestSelling = "افضل المنتجات";
            this.discount = "الخصومات";
            this.promotions = "العروض";
            this.LE = "جنيه";
            this.combo = "كومبو";
        }
        else {
            this.dir = "ltr";
            this.Menu = "Main Menu";
            this.Back = "Back";
            this.Cancel = "Cancel Order";
            this.OrderDone = "Done";
            this.MyOrder = "My Order - In Shop";
            this.Modfires = "Modifiers";
            this.Next = "Next";
            this.bestSelling = "Best Selling";
            this.discount = "Discount";
            this.promotions = "Promotion";
            this.LE = "LE";
            this.combo = "combo";
        }
        // this.getData()
        this.getCategoris();
        this.getCommbo();
        this.ifArrOfModfier();
        this.getDatas();
    }
    getDatas() {
        let id = sessionStorage.getItem('comboId');
        this.rest.comboDetails(id, this.langId).subscribe((res) => {
            console.log("dasds", res);
            this.products = res;
            for (let i = 0; this.products.length; i++) {
                if (this.products[i].image == "") {
                    this.products[i].image = "assets/images/kiosk.png";
                }
            }
        });
    }
    goToProd(item) {
        this.route.navigateByUrl("/compo-details");
        sessionStorage.setItem('productOfCombo', JSON.stringify(item));
        console.log(item);
    }
    goBack() {
        this.route.navigateByUrl('/compo');
    }
    getCommbo() {
        this.rest.combo(this.langId).subscribe((res) => {
            console.log("combo", res);
            this.items = res;
        });
    }
    getCategoris() {
        this.rest.getCategoriWithProduct(this.langId).subscribe((res) => {
            console.log(res);
            this.categoris = res.categoriesProducts;
            for (let i = 0; i < this.categoris.length; i++) {
                if (i == 2 || i == 5 || i == 8 || i == 11) {
                    this.categoris[i].status = true;
                }
                else {
                    this.categoris[i].status = false;
                }
            }
        });
    }
    getData() {
        this.categoriObj = JSON.parse(sessionStorage.getItem('obj'));
        console.log(this.categoriObj);
        this.nameOfCat = this.categoriObj.Name;
        // this.items = this.categoriObj.Products
        for (let i = 0; i < this.items.length; i++) {
            if (i == 2 || i == 5 || i == 8 || i == 11) {
                this.items[i].status = true;
            }
            else {
                this.items[i].status = false;
            }
        }
    }
    GetModifiresbyProductId(item, id) {
        this.idOfIngrdtiont = id;
        sessionStorage.setItem('ProductOfChose', JSON.stringify(item));
        this.price = item.Price;
        this.rest.GetModifiresbyProductId(id, this.langId).subscribe((res) => {
            console.log(res);
            if (res.length != 0) {
                sessionStorage.setItem('modfiresArr', JSON.stringify(res));
                this.route.navigateByUrl('/add-modfires');
            }
            else {
                this.rest.GetItemsbyProductId(this.langId, id).subscribe((res) => {
                    if (res.length == 0) {
                        let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
                        console.log("hamdaaaa");
                        let item = {};
                        item.ingridtArr = [];
                        item.Prdoucts = [products];
                        item.modfire = [];
                        sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                        this.route.navigateByUrl('/quantity');
                    }
                    else {
                        this.gotToDetails('normal');
                    }
                });
            }
        });
    }
    close() {
        this.showModfire = false;
    }
    ifArrOfModfier() {
        let arrOfMod = JSON.parse(sessionStorage.getItem('arrOfModfire'));
        if (arrOfMod) {
            this.disalbedButton = false;
            if (this.langId == '1') {
                this.arrOfModLength = "إجمالي المنتجات" + " " + `(${arrOfMod.length})`;
            }
            else {
                this.arrOfModLength = "Total Items" + " " + `(${arrOfMod.length})`;
            }
        }
        else {
            this.disalbedButton = true;
            if (this.langId == '1') {
                this.arrOfModLength = "لا يوجد طلبات";
            }
            else {
                this.arrOfModLength = "You Order is Empty";
            }
        }
    }
    gotToDetails(item) {
        if (item == "normal") {
            let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
            this.rest.GetItemsbyProductId(this.langId, this.idOfIngrdtiont).subscribe((res) => {
                if (res.length == 0) {
                    let item = {};
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    let item = {};
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/add-souce');
                }
            });
            sessionStorage.setItem("ifModFire", 'false');
        }
        else if (item == 'Discount') {
            this.rest.gitDiscount(this.langId).subscribe((res) => {
                console.log(res);
                let obj = {
                    Name: 'Discount',
                    Products: res
                };
                sessionStorage.setItem('obj', JSON.stringify(obj));
                this.route.navigateByUrl('/discount');
            });
        }
        else {
            console.log("asdasdsa", item);
            this.rest.GetItemsbyProductId(this.langId, this.idOfIngrdtiont).subscribe((res) => {
                if (res.length == 0) {
                    let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/add-souce');
                }
            });
        }
    }
    ChoseCategori(item) {
        sessionStorage.setItem('obj', JSON.stringify(item));
        this.route.navigateByUrl('/categoris');
    }
    cancelOrder() {
        sessionStorage.clear();
        this.route.navigateByUrl('/suggestions');
    }
    Done() {
        this.route.navigateByUrl('/review');
    }
    goTocomboDetails(id) {
        sessionStorage.setItem("comboId", id);
        this.route.navigateByUrl("/choose-combo");
    }
};
ChooseComboPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
ChooseComboPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-choose-combo',
        template: _choose_combo_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_choose_combo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ChooseComboPage);



/***/ }),

/***/ 7114:
/*!**********************************************************************!*\
  !*** ./src/app/pages/choose-combo/choose-combo.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcef50;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: black;\n  text-transform: none;\n}\n\nion-content {\n  --background:#fff ;\n  --color: black ;\n}\n\n.cover {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  left: 0%;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #fff;\n  top: 0;\n}\n\n.cover2 {\n  position: absolute;\n  width: 100%;\n  height: 27vh;\n  top: 0;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #000;\n}\n\n.cover h1 {\n  font-weight: bold;\n  margin-top: 12%;\n  font-size: 5vw;\n  color: black;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.back p, .backIfRight P {\n  font-weight: bold;\n  font-size: 5vw;\n}\n\n.back ion-button, .backIfRight ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 2%;\n  font-size: 5vw;\n  height: auto;\n  margin-bottom: 5%;\n  height: 100px;\n}\n\n.products {\n  text-align: center;\n}\n\n.products .price {\n  text-align: left;\n  font-size: 11px;\n  margin: 0;\n}\n\n.products .name {\n  font-size: 0.8rem;\n  margin-bottom: 5px;\n  margin-top: 0;\n  font-weight: bold;\n}\n\n.products .rowOne {\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.colOne {\n  border-right: 1px solid #c2c2c2;\n}\n\n.menuItem {\n  padding: 30px 0;\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.menuItem p {\n  margin: 0;\n  font-size: 0.5rem;\n  text-align: center;\n  font-weight: bold;\n  font-size: 3vw;\n}\n\n.menuItem img {\n  height: 150px;\n}\n\n.price_name {\n  display: flex;\n  justify-content: space-between;\n  font-size: 10px;\n  margin-top: 10px;\n  font-size: 3vw;\n}\n\n.myOrder {\n  background: #E1E1E1;\n  padding: 5px 10px;\n}\n\n.myOrder h4 {\n  margin: 0;\n  font-size: 5vw;\n  color: black;\n}\n\n.confirmOrCancel {\n  display: flex;\n  justify-content: space-around;\n}\n\n.confirmOrCancel ion-button {\n  width: 33%;\n}\n\n.foter p {\n  text-align: center;\n  font-size: 5vw;\n}\n\n.footer {\n  position: absolute;\n  width: 100%;\n  bottom: 1%;\n}\n\n.recmoended p {\n  margin: 0;\n  font-size: 5vw;\n}\n\n.menu {\n  overflow-y: scroll;\n  border-radius: 5px;\n  margin-top: -17%;\n  background: #f0f0f0;\n  height: 72vh;\n  text-align: center;\n}\n\n.menu div {\n  border-bottom: 1px solid gray;\n}\n\n.menu .mainMenu {\n  font-size: 3rem;\n  font-weight: bold;\n  margin-top: 50%;\n}\n\n.products {\n  height: 52vh;\n  overflow-y: scroll;\n  padding-bottom: 10px;\n}\n\n.products img {\n  height: 150px;\n}\n\n.ifClick {\n  height: 19vh !important;\n}\n\n.recmoended ion-button {\n  --background: #E1E1E1;\n  font-size: 5vw;\n  height: auto;\n}\n\n.Modfires {\n  display: flex;\n  justify-content: space-between;\n}\n\n.Modfires h1 {\n  margin-top: 8px;\n  padding-left: 5px;\n  font-size: 7vw;\n}\n\n.confirmOrCancel ion-button {\n  font-size: 4vw;\n  height: 112px;\n}\n\n.next {\n  position: absolute;\n  bottom: 24%;\n  height: 100px !important;\n  left: 14px;\n  --background: rgb(252, 180, 0)!important;\n  color: #000;\n}\n\n@media only screen and (max-width: 768px) {\n  .imgProduct {\n    height: 71px;\n  }\n\n  .menu {\n    height: 67vh;\n    margin-top: -19%;\n  }\n\n  .menuItem {\n    padding: 12px 0;\n  }\n\n  .menuItem img {\n    height: 50px;\n    width: auto;\n  }\n\n  .back ion-button {\n    height: 36px;\n  }\n\n  .menu .mainMenu {\n    font-size: 13px;\n  }\n\n  .products img {\n    width: auto;\n    height: 90px;\n  }\n\n  .confirmOrCancel ion-button {\n    height: 44px;\n  }\n\n  .ifClick {\n    height: 10vh !important;\n  }\n\n  .cover2 {\n    height: 23vh;\n  }\n\n  .next {\n    height: 36px !important;\n  }\n\n  .back ion-button, .backIfRight ion-button {\n    height: 41px;\n  }\n\n  .next {\n    bottom: 25%;\n    left: 5px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNob29zZS1jb21iby5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDRSxrQkFBQTtFQUNBLG1CQUFBO0FBQUY7O0FBRUE7RUFDRSxxQkFBQTtFQUNBLGNBQUE7RUFDQSxvQkFBQTtBQUNGOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0FBRUY7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsUUFBQTtFQUNBLHFDQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsTUFBQTtBQUVGOztBQUFBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLE1BQUE7RUFDQSxxQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQUdGOztBQURBO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFJSjs7QUFGQTtFQUNFLGlCQUFBO0FBS0Y7O0FBSEE7RUFDRSxnQkFBQTtBQU1GOztBQUpBO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0FBT0o7O0FBTEE7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7QUFRRjs7QUFOQTtFQUNFLGtCQUFBO0FBU0Y7O0FBUEE7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxTQUFBO0FBVUY7O0FBUkE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0FBV0Y7O0FBVEE7RUFDRSxnQ0FBQTtBQVlGOztBQVZBO0VBQ0UsK0JBQUE7QUFhRjs7QUFYQTtFQUNFLGVBQUE7RUFDQSxnQ0FBQTtBQWNGOztBQVhBO0VBQ0UsU0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFjRjs7QUFYQTtFQUNFLGFBQUE7QUFjRjs7QUFaQTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFlRjs7QUFiQTtFQUNFLG1CQUFBO0VBQ0EsaUJBQUE7QUFnQkY7O0FBZEE7RUFDRSxTQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFpQkY7O0FBZEE7RUFDRSxhQUFBO0VBQ0EsNkJBQUE7QUFpQkY7O0FBZkE7RUFDRSxVQUFBO0FBa0JGOztBQWhCQTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtBQW1CRjs7QUFoQkE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0FBbUJGOztBQWhCQTtFQUNFLFNBQUE7RUFDQSxjQUFBO0FBbUJGOztBQWZBO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFrQkY7O0FBaEJBO0VBQ0UsNkJBQUE7QUFtQkY7O0FBakJBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQW9CRjs7QUFsQkE7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQkFBQTtBQXFCRjs7QUFuQkE7RUFDRSxhQUFBO0FBc0JGOztBQW5CQTtFQUNFLHVCQUFBO0FBc0JGOztBQW5CQTtFQUNDLHFCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFzQkQ7O0FBbkJBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0FBc0JBOztBQW5CQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFzQkY7O0FBcEJBO0VBQ0UsY0FBQTtFQUNBLGFBQUE7QUF1QkY7O0FBckJBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0Esd0JBQUE7RUFDQSxVQUFBO0VBQ0Esd0NBQUE7RUFDQSxXQUFBO0FBd0JGOztBQWRBO0VBQ0U7SUFDSSxZQUFBO0VBaUJKOztFQWZBO0lBQ0ksWUFBQTtJQUNBLGdCQUFBO0VBa0JKOztFQWhCQTtJQUNJLGVBQUE7RUFtQko7O0VBakJBO0lBQ0ksWUFBQTtJQUNBLFdBQUE7RUFvQko7O0VBbEJBO0lBQ0ksWUFBQTtFQXFCSjs7RUFuQkE7SUFDSSxlQUFBO0VBc0JKOztFQXBCQTtJQUNJLFdBQUE7SUFDQSxZQUFBO0VBdUJKOztFQXBCQTtJQUNFLFlBQUE7RUF1QkY7O0VBckJBO0lBQ0ksdUJBQUE7RUF3Qko7O0VBdEJBO0lBQ0ksWUFBQTtFQXlCSjs7RUF2QkE7SUFDSSx1QkFBQTtFQTBCSjs7RUF4QkE7SUFDSSxZQUFBO0VBMkJKOztFQXpCRTtJQUNFLFdBQUE7SUFDQSxTQUFBO0VBNEJKO0FBQ0YiLCJmaWxlIjoiY2hvb3NlLWNvbWJvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuLmhlYWRlcntcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiAjZmNlZjUwXG59XG5pb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjRTFFMUUxO1xuICAtLWNvbG9yOiBibGFjazsgXG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xufVxuaW9uLWNvbnRlbnR7XG4gIC0tYmFja2dyb3VuZDojZmZmIDtcbiAgLS1jb2xvcjogYmxhY2tcbn1cblxuLmNvdmVyIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBsZWZ0OiAwJTtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjc5KTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgdG9wOiAwXG59XG4uY292ZXIyIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OjI3dmg7XG4gIHRvcDogMDtcbiAgYmFja2dyb3VuZDogcmdiKDI1NSAyNTUgMjU1IC8gNzklKTs7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICMwMDBcbn1cbi5jb3ZlciBoMSB7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgbWFyZ2luLXRvcDogMTIlO1xuICAgIGZvbnQtc2l6ZTogNXZ3O1xuICAgIGNvbG9yOiBibGFja1xufVxuLmJhY2sge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cbi5iYWNrSWZSaWdodHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cbi5iYWNrIHAgLCAuYmFja0lmUmlnaHQgUHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXNpemU6IDV2dztcbn1cbi5iYWNrIGlvbi1idXR0b24gLCAuYmFja0lmUmlnaHQgaW9uLWJ1dHRvbntcbiAgLS1wYWRkaW5nLXN0YXJ0OiAyZW07XG4gIC0tcGFkZGluZy1lbmQ6IDJlbTtcbiAgLS1ib3JkZXItcmFkaXVzOjVweDtcbiAgbWFyZ2luLXRvcDogMiU7XG4gIGZvbnQtc2l6ZTogNXZ3O1xuICBoZWlnaHQ6IGF1dG87XG4gIG1hcmdpbi1ib3R0b206IDUlO1xuICBoZWlnaHQ6IDEwMHB4O1xufVxuLnByb2R1Y3Rze1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4ucHJvZHVjdHMgLnByaWNle1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LXNpemU6IDExcHg7XG4gIG1hcmdpbjogMFxufVxuLnByb2R1Y3RzIC5uYW1le1xuICBmb250LXNpemU6IC44cmVtO1xuICBtYXJnaW4tYm90dG9tOjVweDtcbiAgbWFyZ2luLXRvcDogMDtcbiAgZm9udC13ZWlnaHQ6IGJvbGRcbn1cbi5wcm9kdWN0cyAucm93T25le1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2MyYzJjMjtcbn1cbi5jb2xPbmV7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNjMmMyYzI7XG59XG4ubWVudUl0ZW17XG4gIHBhZGRpbmc6IDMwcHggMDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjMmMyYzI7XG5cbn1cbi5tZW51SXRlbSBwe1xuICBtYXJnaW46IDA7XG4gIGZvbnQtc2l6ZTogLjVyZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtc2l6ZTogM3Z3O1xuXG59XG4ubWVudUl0ZW0gaW1nIHtcbiAgaGVpZ2h0OiAxNTBweDtcbn1cbi5wcmljZV9uYW1le1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgZm9udC1zaXplOiAzdndcbn1cbi5teU9yZGVye1xuICBiYWNrZ3JvdW5kOiAjRTFFMUUxO1xuICBwYWRkaW5nIDo1cHggMTBweFxufVxuLm15T3JkZXIgaDQge1xuICBtYXJnaW46IDA7XG4gIGZvbnQtc2l6ZTogNXZ3O1xuICBjb2xvcjogYmxhY2tcbn1cblxuLmNvbmZpcm1PckNhbmNlbHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG59XG4uY29uZmlybU9yQ2FuY2VsIGlvbi1idXR0b257XG4gIHdpZHRoOiAzMyU7XG59XG4uZm90ZXIgcCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiA1dnc7XG59XG5cbi5mb290ZXIge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiAxMDAlO1xuICBib3R0b206IDElXG5cbn1cbi5yZWNtb2VuZGVkIHB7XG4gIG1hcmdpbjogMDtcbiAgZm9udC1zaXplOiA1dnc7XG5cbn1cblxuLm1lbnV7XG4gIG92ZXJmbG93LXk6IHNjcm9sbDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBtYXJnaW4tdG9wOiAtMTclO1xuICBiYWNrZ3JvdW5kOiAjZjBmMGYwO1xuICBoZWlnaHQ6IDcydmg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5tZW51IGRpdiB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBncmF5O1xufVxuLm1lbnUgLm1haW5NZW51e1xuICBmb250LXNpemU6IDNyZW07XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW4tdG9wOiA1MCU7XG59XG4ucHJvZHVjdHN7XG4gIGhlaWdodDogNTJ2aDtcbiAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbn1cbi5wcm9kdWN0cyBpbWcge1xuICBoZWlnaHQ6IDE1MHB4O1xufVxuXG4uaWZDbGlja3tcbiAgaGVpZ2h0OjE5dmggIWltcG9ydGFudDtcbn1cblxuLnJlY21vZW5kZWQgaW9uLWJ1dHRvbntcbiAtLWJhY2tncm91bmQ6ICNFMUUxRTE7XG4gZm9udC1zaXplOiA1dnc7XG4gaGVpZ2h0OiBhdXRvOztcbiBcbn1cbi5Nb2RmaXJlc3tcbmRpc3BsYXk6IGZsZXg7XG5qdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW5cbn1cblxuLk1vZGZpcmVzIGgxIHtcbiAgbWFyZ2luLXRvcDogOHB4O1xuICBwYWRkaW5nLWxlZnQ6IDVweDtcbiAgZm9udC1zaXplOiA3dnc7XG59XG4uY29uZmlybU9yQ2FuY2VsIGlvbi1idXR0b257XG4gIGZvbnQtc2l6ZTogNHZ3O1xuICBoZWlnaHQ6IDExMnB4O1xufVxuLm5leHQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMjQlO1xuICBoZWlnaHQ6IDEwMHB4ICFpbXBvcnRhbnQ7XG4gIGxlZnQ6IDE0cHg7XG4gIC0tYmFja2dyb3VuZDogcmdiKDI1MiwgMTgwLCAwKSFpbXBvcnRhbnQ7XG4gIGNvbG9yOiAjMDAwXG59XG4vLyAubmV4dE1vZGZpcmUge1xuLy8gICAgIGhlaWdodDogMTAwcHg7XG4vLyB9XG4vLyAubmV4dE1vZGZpcmUgaW9uLWJ1dHRvbntcbi8vICAgICAtLWJhY2tncm91bmQ6ICNjMmMyYzI7XG4vLyAgICAgaGVpZ2h0OiAxMDAlO1xuLy8gfVxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6NzY4cHgpe1xuICAuaW1nUHJvZHVjdHtcbiAgICAgIGhlaWdodDogNzFweDtcbiAgfVxuICAubWVudSB7XG4gICAgICBoZWlnaHQ6IDY3dmg7XG4gICAgICBtYXJnaW4tdG9wOiAtMTklO1xuICB9XG4gIC5tZW51SXRlbXtcbiAgICAgIHBhZGRpbmc6IDEycHggMDtcbiAgfVxuICAubWVudUl0ZW0gaW1nIHtcbiAgICAgIGhlaWdodDogNTBweDtcbiAgICAgIHdpZHRoOiBhdXRvXG4gIH1cbiAgLmJhY2sgaW9uLWJ1dHRvbntcbiAgICAgIGhlaWdodDogMzZweDtcbiAgfVxuICAubWVudSAubWFpbk1lbnV7XG4gICAgICBmb250LXNpemU6IDEzcHg7XG4gIH1cbiAgLnByb2R1Y3RzIGltZ3tcbiAgICAgIHdpZHRoOiBhdXRvO1xuICAgICAgaGVpZ2h0OiA5MHB4O1xuICAgICAgXG4gIH1cbiAgLmNvbmZpcm1PckNhbmNlbCBpb24tYnV0dG9ue1xuICAgIGhlaWdodDogNDRweDtcbiAgfVxuICAuaWZDbGlja3tcbiAgICAgIGhlaWdodDoxMHZoICFpbXBvcnRhbnQ7XG4gIH1cbiAgLmNvdmVyMntcbiAgICAgIGhlaWdodDoyM3ZoO1xuICB9XG4gIC5uZXh0IHtcbiAgICAgIGhlaWdodDogMzZweCAhaW1wb3J0YW50O1xuICB9XG4gIC5iYWNrIGlvbi1idXR0b24gLCAuYmFja0lmUmlnaHQgaW9uLWJ1dHRvbntcbiAgICAgIGhlaWdodDogNDFweDtcbiAgICB9XG4gICAgLm5leHQgIHtcbiAgICAgIGJvdHRvbTogMjUlO1xuICAgICAgbGVmdDogNXB4O1xuICB9XG59Il19 */";

/***/ }),

/***/ 8795:
/*!**********************************************************************!*\
  !*** ./src/app/pages/choose-combo/choose-combo.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"header\">\n    <img class=\"imgProduct \" src=\"assets/images/bingo.png\">\n  </div>\n  \n  <ion-content [dir]=\"dir\">\n    <div class=\"\">\n      <div class=\"back\" [ngClass]=\"{'back':dir == 'ltr', 'backIfRight':dir == 'rtl'}\">\n        <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n      </div>\n      <ion-grid style=\"padding: 0\">\n        <ion-row>\n          <ion-col class=\"menu\" [ngClass]=\"{'ifClick':showModfire}\" size=\"3\">\n            <p class=\"mainMenu\"> {{Menu}} </p>\n            <div  class=\"menuItem\" routerLink=\"/compo\">\n                <img src=\"assets/images/mostSelling.png\">\n                <p>{{combo}}</p>\n              </div>\n            <div class=\"menuItem\" (click)=\"gotToDetails('Discount')\">\n              <img src=\"assets/images/discount.png\">\n              <p>{{discount}}</p>\n            </div>\n            <div class=\"menuItem\" routerLink=\"/promtions\">\n              <img src=\"assets/images/promotion.png\">\n              <p>{{promotions}}</p>\n            </div>\n            <div>\n              <div *ngFor=\"let item of categoris\" class=\"menuItem\" (click)=\"ChoseCategori(item)\">\n                <img src=\"{{item.Image}}\">\n                <p>{{item.Name}}</p>\n              </div>\n            </div>\n          </ion-col>\n          <ion-col>\n            <div class=\"products\" [ngClass]=\"{'ifClick':showModfire}\">\n              <ion-grid>\n                <ion-row>\n                  <!--  [ngClass]=\"{'colOne':item.status == false}\" -->\n                  <ion-col size=\"6\" class=\"rowOne colOne\"\n                   (click)=\"goToProd(item)\"\n                    *ngFor=\"let item of products ; let i = index\">\n                    <!-- <span *ngIf=\"langId != 1\" class=\"price_name\">{{LE}} {{item.Price}}</span>\n                    <span *ngIf=\"langId == 1\" class=\"price_name\">{{item.Price}} {{LE}}</span> -->\n                    <img src=\"{{item.image}}\">\n                    <p class=\"price_name\">{{item.Name}}</p>\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n      <div [ngClass]=\"{'cover2':showModfire}\"></div>\n    </div>\n  \n  \n  \n  \n    <section class=\"footer\">\n      <div class=\"myOrder\">\n        <h4>{{MyOrder}}</h4>\n      </div>\n      <div class=\"foter\">\n        <p>{{arrOfModLength}}</p>\n        <div class=\"confirmOrCancel\" dir=\"ltr\">\n          <ion-button [disabled]=\"arrOfModLength\" (click)=\"cancelOrder()\">{{Cancel}}</ion-button>\n          <ion-button [disabled]=\"arrOfModLength\" (click)=\"Done()\">{{OrderDone}}</ion-button>\n        </div>\n      </div>\n    </section>\n  \n  \n  \n  \n  </ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_choose-combo_choose-combo_module_ts.js.map