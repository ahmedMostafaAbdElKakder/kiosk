"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_order-number_order-number_module_ts"],{

/***/ 752:
/*!*******************************************************************!*\
  !*** ./src/app/pages/order-number/order-number-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderNumberPageRoutingModule": () => (/* binding */ OrderNumberPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _order_number_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-number.page */ 5685);




const routes = [
    {
        path: '',
        component: _order_number_page__WEBPACK_IMPORTED_MODULE_0__.OrderNumberPage
    }
];
let OrderNumberPageRoutingModule = class OrderNumberPageRoutingModule {
};
OrderNumberPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], OrderNumberPageRoutingModule);



/***/ }),

/***/ 5518:
/*!***********************************************************!*\
  !*** ./src/app/pages/order-number/order-number.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderNumberPageModule": () => (/* binding */ OrderNumberPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _order_number_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-number-routing.module */ 752);
/* harmony import */ var _order_number_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order-number.page */ 5685);







let OrderNumberPageModule = class OrderNumberPageModule {
};
OrderNumberPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _order_number_routing_module__WEBPACK_IMPORTED_MODULE_0__.OrderNumberPageRoutingModule
        ],
        declarations: [_order_number_page__WEBPACK_IMPORTED_MODULE_1__.OrderNumberPage]
    })
], OrderNumberPageModule);



/***/ }),

/***/ 5685:
/*!*********************************************************!*\
  !*** ./src/app/pages/order-number/order-number.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderNumberPage": () => (/* binding */ OrderNumberPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _order_number_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-number.page.html?ngResource */ 1664);
/* harmony import */ var _order_number_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order-number.page.scss?ngResource */ 4687);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);







let OrderNumberPage = class OrderNumberPage {
    constructor(navCtr, route, rest) {
        this.navCtr = navCtr;
        this.route = route;
        this.rest = rest;
    }
    ngOnInit() {
        this.langId = localStorage.getItem("lang");
        this.orderNumber = sessionStorage.getItem('numberOfOrder');
        if (this.langId == '1') {
            this.OrderDone = "الرئيسية";
            this.title = "رقم الطلب";
        }
        else {
            this.title = "Your Order Number is";
            this.OrderDone = "Go Home";
        }
    }
    Done() {
        this.route.navigateByUrl('/order-here');
        sessionStorage.clear();
        sessionStorage.setItem('status', 'false');
        this.rest.sendObsData("false");
    }
};
OrderNumberPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService }
];
OrderNumberPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-order-number',
        template: _order_number_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_order_number_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], OrderNumberPage);



/***/ }),

/***/ 4687:
/*!**********************************************************************!*\
  !*** ./src/app/pages/order-number/order-number.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background:#000000;\n}\n\nion-button {\n  --background: #c6c6c6;\n  --color: black;\n  text-transform: none;\n}\n\n.back {\n  text-align: right;\n  text-transform: none;\n}\n\n.logo {\n  display: flex;\n  margin-top: 20%;\n  justify-content: center;\n}\n\n.logo .logoImage {\n  width: 60%;\n  border-radius: 10px;\n}\n\n.title {\n  text-align: center;\n  font-size: 5vw;\n}\n\n.product {\n  border: 10px solid #fff;\n  height: 170px;\n  flex-direction: column;\n  display: flex;\n  justify-content: space-between;\n}\n\n.product .imgProduct {\n  width: 50%;\n  margin: 30px auto;\n  height: 50px;\n}\n\n.product .button {\n  --background:#ffc107;\n  text-transform: none;\n}\n\n.fotter {\n  position: absolute;\n  bottom: 1%;\n  left: 34.5%;\n  width: 100%;\n}\n\n.fotter ion-button {\n  width: auto;\n  font-size: 5vw;\n  height: 112px;\n  color: black;\n}\n\n@media only screen and (max-width: 768px) {\n  .fotter ion-button {\n    height: 45px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLW51bWJlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQkFBQTtBQUNGOztBQUNBO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0VBQ0Esb0JBQUE7QUFFRjs7QUFBRTtFQUNFLGlCQUFBO0VBQ0Esb0JBQUE7QUFHSjs7QUFERTtFQUNFLGFBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7QUFJSjs7QUFGRTtFQUNFLFVBQUE7RUFDQSxtQkFBQTtBQUtKOztBQUZFO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0FBS0o7O0FBSEU7RUFDRSx1QkFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtBQU1KOztBQUpFO0VBQ0UsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtBQU9KOztBQUxFO0VBQ0Usb0JBQUE7RUFDQSxvQkFBQTtBQVFKOztBQUxFO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7QUFRSjs7QUFORTtFQUNFLFdBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7QUFTSjs7QUFMRTtFQUNFO0lBQ0UsWUFBQTtFQVFKO0FBQ0YiLCJmaWxlIjoib3JkZXItbnVtYmVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xuICAtLWJhY2tncm91bmQ6IzAwMDAwMDtcbn1cbmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6ICNjNmM2YzY7XG4gIC0tY29sb3I6IGJsYWNrOyBcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG59XG4gIC5iYWNrIHtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogbm9uZVxuICB9XG4gIC5sb2dve1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgbWFyZ2luLXRvcDogMjAlO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyXG4gIH1cbiAgLmxvZ28gLmxvZ29JbWFnZSB7XG4gICAgd2lkdGg6IDYwJTtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4XG4gIH1cbiAgXG4gIC50aXRsZXtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiA1dnc7XG4gIH1cbiAgLnByb2R1Y3R7XG4gICAgYm9yZGVyOiAxMHB4IHNvbGlkICNmZmY7XG4gICAgaGVpZ2h0OiAxNzBweDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICB9XG4gIC5wcm9kdWN0IC5pbWdQcm9kdWN0e1xuICAgIHdpZHRoOiA1MCU7XG4gICAgbWFyZ2luOiAzMHB4IGF1dG87XG4gICAgaGVpZ2h0OiA1MHB4O1xuICB9XG4gIC5wcm9kdWN0IC5idXR0b257XG4gICAgLS1iYWNrZ3JvdW5kOiNmZmMxMDc7IFxuICAgIHRleHQtdHJhbnNmb3JtOiBub25lXG4gIH1cbiBcbiAgLmZvdHRlcntcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgYm90dG9tOiAxJTtcbiAgICBsZWZ0OiAzNC41JTtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxuICAuZm90dGVyIGlvbi1idXR0b257XG4gICAgd2lkdGg6IGF1dG87XG4gICAgZm9udC1zaXplOiA1dnc7XG4gICAgaGVpZ2h0OiAxMTJweDtcbiAgICBjb2xvcjogYmxhY2tcblxuICB9XG5cbiAgQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjc2OHB4KXtcbiAgICAuZm90dGVyIGlvbi1idXR0b257XG4gICAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgfVxuICB9Il19 */";

/***/ }),

/***/ 1664:
/*!**********************************************************************!*\
  !*** ./src/app/pages/order-number/order-number.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-content [fullscreen]=\"true\">\n  <div class=\"logo\">\n    <ion-img class=\"logoImage\" src=\"assets/images/bingo.png\"></ion-img>\n  </div>\n  <div class=\"title\">\n    <p style=\"color: #fff ; font-weight: bold\">{{title}}</p>\n    <h1 style=\"color: #fff ; font-size: 5vw ; font-weight: bold\">{{orderNumber}}</h1>\n  </div>\n  \n  <div class=\"fotter\">\n    <ion-button (click)=\"Done()\">{{OrderDone}}</ion-button>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_order-number_order-number_module_ts.js.map