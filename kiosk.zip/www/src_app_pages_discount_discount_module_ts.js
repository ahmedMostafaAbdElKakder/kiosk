"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_discount_discount_module_ts"],{

/***/ 1578:
/*!***********************************************************!*\
  !*** ./src/app/pages/discount/discount-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DiscountPageRoutingModule": () => (/* binding */ DiscountPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _discount_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./discount.page */ 2316);




const routes = [
    {
        path: '',
        component: _discount_page__WEBPACK_IMPORTED_MODULE_0__.DiscountPage
    }
];
let DiscountPageRoutingModule = class DiscountPageRoutingModule {
};
DiscountPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DiscountPageRoutingModule);



/***/ }),

/***/ 9923:
/*!***************************************************!*\
  !*** ./src/app/pages/discount/discount.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DiscountPageModule": () => (/* binding */ DiscountPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _discount_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./discount-routing.module */ 1578);
/* harmony import */ var _discount_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./discount.page */ 2316);







let DiscountPageModule = class DiscountPageModule {
};
DiscountPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _discount_routing_module__WEBPACK_IMPORTED_MODULE_0__.DiscountPageRoutingModule
        ],
        declarations: [_discount_page__WEBPACK_IMPORTED_MODULE_1__.DiscountPage]
    })
], DiscountPageModule);



/***/ }),

/***/ 2316:
/*!*************************************************!*\
  !*** ./src/app/pages/discount/discount.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DiscountPage": () => (/* binding */ DiscountPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _discount_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./discount.page.html?ngResource */ 6502);
/* harmony import */ var _discount_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./discount.page.scss?ngResource */ 2077);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);







let DiscountPage = class DiscountPage {
    constructor(rest, route, location) {
        this.rest = rest;
        this.route = route;
        this.location = location;
        this.items = [];
        this.showModfire = false;
        this.ModifiresbyProductId = [];
        this.disalbedButton = true;
        this.categoris = [];
    }
    ngOnInit() {
        this.langId = localStorage.getItem('lang');
        if (this.langId == '1') {
            this.dir = "rtl";
            this.Menu = "قائمة الطلبات";
            this.Back = "رجوع";
            this.Cancel = "إلغاء الطلب";
            this.OrderDone = "دفع";
            this.MyOrder = "طلباتي - في المتجر";
            this.Modfires = "الاضافات";
            this.Next = "التالي";
            this.bestSelling = "افضل المنتجات";
            this.discount = "الخصومات";
            this.promotions = "العروض";
            this.Compo = "كومبو";
            this.After = "بعد";
            this.Befor = "قبل";
            this.LE = "جنيه";
        }
        else {
            this.dir = "ltr";
            this.Menu = "Main Menu";
            this.Back = "Back";
            this.Cancel = "Cancel Order";
            this.OrderDone = "Done";
            this.MyOrder = "My Order - In Shop";
            this.Modfires = "Modfires";
            this.Next = "Next";
            this.bestSelling = "Best Selling";
            this.discount = "Discount";
            this.promotions = "Promotion";
            this.Compo = "Combo";
            this.After = "After";
            this.Befor = "Befor";
            this.LE = "LE";
        }
        this.getData();
        this.getCategoris();
        this.ifArrOfModfier();
    }
    getData() {
        this.categoriObj = JSON.parse(sessionStorage.getItem('obj'));
        console.log(this.categoriObj);
        this.nameOfCat = this.categoriObj.Name;
        this.items = this.categoriObj.Products;
        // for (let i = 0; i < this.items.length; i++) {
        //   if(this.items[i].DiscountAmount == "10 %"){
        //     this.items[i].PriceAfterDiscount = this.items[i].Price - (this.items[i].Price / 10)
        //   }
        //   if (i == 2 || i == 5 || i == 8 || i == 11) {
        //     this.items[i].status = true
        //   } else {
        //     this.items[i].status = false
        //   }
        // }
    }
    getCategoris() {
        this.rest.getCategoriWithProduct(this.langId).subscribe((res) => {
            console.log(res);
            this.categoris = res.categoriesProducts;
            for (let i = 0; i < this.categoris.length; i++) {
                if (i == 2 || i == 5 || i == 8 || i == 11) {
                    this.categoris[i].status = true;
                }
                else {
                    this.categoris[i].status = false;
                }
            }
        });
    }
    // GetModifiresbyProductId(item , id) {
    //   this.idOfIngrdtiont = id
    //   sessionStorage.setItem('ProductOfChose', JSON.stringify(item))
    //   this.price = item.Price
    //   this.rest.GetModifiresbyProductId(id,this.langId).subscribe((res: any) => {
    //     console.log(res)
    //     if(res.length != 0){
    //       console.log("hello")
    //       this.showModfire = true
    //       this.ModifiresbyProductId = res
    //     }else {
    //       this.rest.GetItemsbyProductId(this.langId,id).subscribe((res : any) => {
    //         if(res.length == 0){
    //           let products = JSON.parse(sessionStorage.getItem('ProductOfChose'))
    //           let item:any = {}
    //           item.ingridtArr = []
    //           item.Prdoucts = [products]
    //           item.Modfire = []
    //           sessionStorage.setItem('ModfireOfChose', JSON.stringify(item))
    //           this.route.navigateByUrl('/quantity')
    //         }else {
    //           this.gotToDetails('normal')
    //         }
    //       })
    //     }
    //   })
    // }
    // GetModifiresbyProductId(item, id) {
    //   this.idOfIngrdtiont = id
    //   sessionStorage.setItem('ProductOfChose', JSON.stringify(item))
    //   this.price = item.Price
    //   this.rest.GetModifiresbyProductId(id, this.langId).subscribe((res: any) => {
    //     console.log(res)
    //     if (res.length != 0) {
    //       sessionStorage.setItem('modfiresArr', JSON.stringify(res))
    //       this.route.navigateByUrl('/add-modfires')
    //     } else {
    //       this.rest.GetItemsbyProductId(this.langId, id).subscribe((res: any) => {
    //         if (res.length == 0) {
    //           let products = JSON.parse(sessionStorage.getItem('ProductOfChose'))
    //           console.log("hamdaaaa")
    //           let item: any = {}
    //           item.ingridtArr = []
    //           item.Prdoucts = [products]
    //           item.modfire = []
    //           sessionStorage.setItem('ModfireOfChose', JSON.stringify(item))
    //           this.route.navigateByUrl('/quantity')
    //         } else {
    //           this.gotToDetails('normal')
    //         }
    //       })
    //     }
    //   })
    // }
    GetModifiresbyProductId(item, id) {
        this.idOfIngrdtiont = id;
        sessionStorage.setItem('ProductOfChose', JSON.stringify(item));
        this.price = item.Price;
        this.rest.GetModifiresbyProductId(id, this.langId).subscribe((res) => {
            console.log(res);
            if (res.length == 0) {
                let arr = [];
                sessionStorage.setItem('modfiresArr', JSON.stringify(arr));
                // this.route.navigateByUrl('/add-modfires')
            }
            else {
                sessionStorage.setItem('modfiresArr', JSON.stringify(res));
            }
            this.rest.GetItemsbyProductId(this.langId, id).subscribe((res) => {
                let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
                if (res.length == 0) {
                    console.log("hamdaaaa");
                    let item = {};
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('IngrdDub', JSON.stringify([]));
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    let item = {};
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('IngrdDub', JSON.stringify(res));
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                    // this.gotToDetails('normal')
                }
            });
        });
    }
    // GetModifiresbyProductId(item , id) {
    //   sessionStorage.setItem('ProductOfChose', JSON.stringify(item))
    //   this.price = item.Price
    //   this.rest.GetModifiresbyProductId(id,this.langId).subscribe((res: any) => {
    //     console.log(res)
    //     if(res.length != 0){
    //       this.showModfire = true
    //       this.ModifiresbyProductId = res
    //     }else {
    //       this.rest.GetItemsbyProductId(this.langId,id).subscribe((res : any) => {
    //         if(res.length == 0){
    //           let products = JSON.parse(sessionStorage.getItem('ProductOfChose'))
    //           let item:any = {}
    //           item.ingridtArr = []
    //           item.Prdoucts = [products]
    //           item.Modfire = []
    //           sessionStorage.setItem('ModfireOfChose', JSON.stringify(item))
    //           this.route.navigateByUrl('/quantity')
    //         }else {
    //           this.gotToDetails('normal')
    //         }
    //       })
    //     }
    //   })
    // }
    close() {
        this.showModfire = false;
    }
    ifArrOfModfier() {
        let arrOfMod = JSON.parse(sessionStorage.getItem('arrOfModfire'));
        if (arrOfMod) {
            this.disalbedButton = false;
            if (this.langId == '1') {
                this.arrOfModLength = "إجمالي المنتجات" + " " + `(${arrOfMod.length})`;
            }
            else {
                this.arrOfModLength = "Total Items" + " " + `(${arrOfMod.length})`;
            }
        }
        else {
            this.disalbedButton = true;
            if (this.langId == '1') {
                this.arrOfModLength = "لا يوجد طلبات";
            }
            else {
                this.arrOfModLength = "You Order is Empty";
            }
        }
    }
    // gotToDetails(item) {
    //   if(item == "normal"){
    //     this.route.navigateByUrl('/add-souce')
    //     let empty = {}
    //     sessionStorage.setItem('ModfireOfChose', JSON.stringify(empty))
    //     sessionStorage.setItem("ifModFire",'false')
    //   }else {
    //     sessionStorage.setItem('ModfireOfChose', JSON.stringify(item))
    //     this.route.navigateByUrl('/add-souce')
    //   }
    // }
    // gotToDetails(item) {
    //   if(item == "normal"){
    //     this.rest.GetItemsbyProductId(this.langId,this.idOfIngrdtiont).subscribe((res : any) => {
    //       if(res.length == 0){
    //         let products = JSON.parse(sessionStorage.getItem('ProductOfChose'))
    //         let item:any = {}
    //         item.ingridtArr = []
    //         item.Prdoucts = [products]
    //         item.Modfire = []
    //         sessionStorage.setItem('ModfireOfChose', JSON.stringify(item))
    //         this.route.navigateByUrl('/quantity')
    //       }else {
    //         this.route.navigateByUrl('/add-souce')
    //       }
    //     })
    //     let empty = {}
    //     sessionStorage.setItem('ModfireOfChose', JSON.stringify(empty))
    //     sessionStorage.setItem("ifModFire",'false')
    //   } 
    //   else {
    //     console.log("asdasdsa",item)
    //     this.rest.GetItemsbyProductId(this.langId,this.idOfIngrdtiont).subscribe((res : any) => {
    //       if(res.length == 0){
    //         let products = JSON.parse(sessionStorage.getItem('ProductOfChose'))
    //         item.ingridtArr = []
    //         item.Prdoucts = [products]
    //         sessionStorage.setItem('ModfireOfChose', JSON.stringify(item))
    //         this.route.navigateByUrl('/quantity')
    //       }else {
    //         sessionStorage.setItem('ModfireOfChose', JSON.stringify(item))
    //         this.route.navigateByUrl('/add-souce')
    //       }
    //     })
    //   }
    // }
    gotToDetails(item) {
        if (item == "normal") {
            let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
            this.rest.GetItemsbyProductId(this.langId, this.idOfIngrdtiont).subscribe((res) => {
                if (res.length == 0) {
                    let item = {};
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    let item = {};
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/add-souce');
                }
            });
            sessionStorage.setItem("ifModFire", 'false');
        }
        else if (item == 'Discount') {
            this.rest.gitDiscount(this.langId).subscribe((res) => {
                console.log(res);
                let obj = {
                    Name: 'Discount',
                    Products: res
                };
                sessionStorage.setItem('obj', JSON.stringify(obj));
                this.route.navigateByUrl('/discount');
            });
        }
        else {
            console.log("asdasdsa", item);
            this.rest.GetItemsbyProductId(this.langId, this.idOfIngrdtiont).subscribe((res) => {
                if (res.length == 0) {
                    let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/add-souce');
                }
            });
        }
    }
    ChoseCategori(item) {
        sessionStorage.setItem("obj", JSON.stringify(item));
        this.route.navigateByUrl('/categoris');
    }
    goBack() {
        this.location.back();
    }
    cancelOrder() {
        sessionStorage.clear();
        this.route.navigateByUrl('/suggestions');
    }
    Done() {
        this.route.navigateByUrl('/review');
    }
};
DiscountPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__.Location }
];
DiscountPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-discount',
        template: _discount_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_discount_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DiscountPage);



/***/ }),

/***/ 2077:
/*!**************************************************************!*\
  !*** ./src/app/pages/discount/discount.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcef50;\n}\n\nion-header div {\n  text-align: center;\n}\n\nion-header img {\n  width: 120px;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: #000;\n  text-transform: none;\n  width: 250px;\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius: 5px;\n  font-size: 5vw;\n  height: 100px;\n}\n\nion-content {\n  --background:#fff ;\n  --color: black ;\n}\n\n.cover {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  left: 0%;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #fff;\n  top: 0;\n}\n\n.cover2 {\n  position: absolute;\n  width: 100%;\n  height: 27vh;\n  top: 0;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #000;\n}\n\n.cover h1 {\n  font-weight: bold;\n  margin-top: 12%;\n  font-size: 5vw;\n  color: black;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.back ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius: 5px;\n  margin-top: 2%;\n  font-size: 5vw;\n  height: auto;\n  margin-bottom: 5%;\n  height: 100px;\n}\n\n.back p {\n  font-weight: bold;\n  font-size: 5vw;\n}\n\n.products {\n  text-align: center;\n}\n\n.products .price {\n  text-align: left;\n  font-size: 11px;\n  margin: 0;\n}\n\n.products .name {\n  font-size: 0.8rem;\n  margin-bottom: 5px;\n  margin-top: 0;\n  font-weight: bold;\n}\n\n.products .rowOne {\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.products .colOne {\n  border-right: 1px solid #c2c2c2;\n}\n\n.menuItem {\n  padding: 30px 0;\n  border-bottom: 1px solid #c2c2c2;\n  text-align: center;\n}\n\n.menuItem p {\n  margin: 0;\n  font-size: 0.5rem;\n  text-align: center;\n  font-weight: bold;\n  font-size: 3vw;\n}\n\n.menuItem img {\n  height: 150px;\n}\n\n.price_name {\n  display: flex;\n  justify-content: space-between;\n  margin-top: 10px;\n  font-size: 3vw;\n}\n\n.nameOfPrdocuct {\n  font-size: 3vw;\n}\n\n.price_name .after {\n  margin-left: 17px;\n}\n\n.price_name .after span {\n  color: red;\n}\n\n.price_name .befor {\n  margin-right: 17px;\n}\n\n.myOrder {\n  background: #E1E1E1;\n  padding: 5px 10px;\n}\n\n.myOrder h4 {\n  margin: 0;\n  font-size: 5vw;\n  color: black;\n}\n\n.confirmOrCancel {\n  display: flex;\n  justify-content: space-around;\n}\n\n.confirmOrCancel ion-button {\n  width: 33%;\n}\n\n.foter p {\n  text-align: center;\n  font-size: 5vw;\n}\n\n.footer {\n  position: absolute;\n  width: 100%;\n  bottom: 8px;\n}\n\n.recmoended p {\n  margin: 0;\n  font-size: 5vw;\n}\n\n.menu {\n  height: 72vh;\n  overflow-y: scroll;\n  background: #e7e7e7;\n  margin-top: -17%;\n}\n\n.products {\n  height: 52vh;\n  overflow-y: scroll;\n  padding-bottom: 10px;\n}\n\n.products img {\n  width: 220px;\n  height: 200px;\n}\n\n.ifClick {\n  height: 19vh !important;\n}\n\n.recmoended ion-button {\n  --background: #c6c6c6;\n  font-size: 5vw;\n  height: auto;\n}\n\n.Modfires {\n  display: flex;\n  justify-content: space-between;\n}\n\n.Modfires h1 {\n  margin-top: 8px;\n  padding-left: 5px;\n  font-size: 7vw;\n}\n\n.confirmOrCancel ion-button {\n  font-size: 4vw;\n  height: 112px;\n}\n\n.next {\n  position: absolute;\n  bottom: 24%;\n  height: 100px !important;\n  left: 14px;\n  --background: #e1e1e1 !important;\n  color: #000;\n}\n\n.mainMenu {\n  font-size: 3rem;\n  font-weight: bold;\n  margin-top: 50%;\n  text-align: center;\n}\n\n@media only screen and (max-width: 768px) {\n  .backButton {\n    width: auto;\n    height: 37px !important;\n  }\n\n  .imgProduct {\n    width: 81px;\n  }\n\n  .products img {\n    height: 74px;\n    width: auto;\n  }\n\n  .menuItem img {\n    height: 50px;\n  }\n\n  .menuItem {\n    padding: 15px 0;\n  }\n\n  .confirmOrCancel ion-button {\n    height: 44px;\n  }\n\n  .ifClick {\n    height: 10vh !important;\n  }\n\n  .cover2 {\n    height: 30vh;\n  }\n\n  .next {\n    height: 36px !important;\n    --background: #e1e1e1 !important;\n  }\n\n  .mainMenu {\n    font-size: 13px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRpc2NvdW50LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0EsbUJBQUE7QUFDSjs7QUFDQTtFQUNJLGtCQUFBO0FBRUo7O0FBQUE7RUFDSSxZQUFBO0FBR0o7O0FBREE7RUFDSSxxQkFBQTtFQUNBLGFBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQUlKOztBQUZFO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0FBS0o7O0FBRkU7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsUUFBQTtFQUNBLHFDQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsTUFBQTtBQUtKOztBQUhFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLE1BQUE7RUFDQSxxQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQU1KOztBQUpFO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFPTjs7QUFKRTtFQUNFLGlCQUFBO0FBT0o7O0FBTEU7RUFDRSxnQkFBQTtBQVFKOztBQUpFO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG9CQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0FBT0o7O0FBTEU7RUFDSSxpQkFBQTtFQUNBLGNBQUE7QUFRTjs7QUFORTtFQUNFLGtCQUFBO0FBU0o7O0FBUEE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxTQUFBO0FBVUo7O0FBUkE7RUFDSSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0FBV0o7O0FBVEE7RUFDSSxnQ0FBQTtBQVlKOztBQVZBO0VBQ0ksK0JBQUE7QUFhSjs7QUFYQTtFQUNJLGVBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0FBY0o7O0FBWkE7RUFDSSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQWVKOztBQWJBO0VBQ0ksYUFBQTtBQWdCSjs7QUFiQTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQWdCSjs7QUFkQTtFQUNJLGNBQUE7QUFpQko7O0FBZkE7RUFDSSxpQkFBQTtBQWtCSjs7QUFoQkE7RUFDSSxVQUFBO0FBbUJKOztBQWpCQTtFQUNJLGtCQUFBO0FBb0JKOztBQWpCQTtFQUNJLG1CQUFBO0VBQ0EsaUJBQUE7QUFvQko7O0FBbEJBO0VBQ0ksU0FBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FBcUJKOztBQWxCQTtFQUNJLGFBQUE7RUFDQSw2QkFBQTtBQXFCSjs7QUFuQkE7RUFDSSxVQUFBO0FBc0JKOztBQXBCQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQXVCSjs7QUFwQkE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0FBdUJKOztBQXJCQTtFQUNJLFNBQUE7RUFDQSxjQUFBO0FBd0JKOztBQXBCQTtFQUNJLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUF1Qko7O0FBckJBO0VBQ0ksWUFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7QUF3Qko7O0FBdEJBO0VBQ0ksWUFBQTtFQUNBLGFBQUE7QUF5Qko7O0FBdEJBO0VBQ0ksdUJBQUE7QUF5Qko7O0FBdEJBO0VBQ0cscUJBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQXlCSDs7QUF0QkE7RUFDQyxhQUFBO0VBQ0EsOEJBQUE7QUF5QkQ7O0FBdEJBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQXlCSjs7QUF2QkE7RUFDSSxjQUFBO0VBQ0EsYUFBQTtBQTBCSjs7QUF4QkE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSx3QkFBQTtFQUNBLFVBQUE7RUFDQSxnQ0FBQTtFQUNBLFdBQUE7QUEyQko7O0FBekJBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBNEJKOztBQWxCQTtFQUNJO0lBQ0ksV0FBQTtJQUNBLHVCQUFBO0VBcUJOOztFQW5CRTtJQUNJLFdBQUE7RUFzQk47O0VBcEJFO0lBQ0UsWUFBQTtJQUNBLFdBQUE7RUF1Qko7O0VBcEJFO0lBQ0ksWUFBQTtFQXVCTjs7RUFyQkk7SUFDRSxlQUFBO0VBd0JOOztFQXRCRTtJQUNFLFlBQUE7RUF5Qko7O0VBdkJFO0lBQ0ksdUJBQUE7RUEwQk47O0VBeEJFO0lBQ0ksWUFBQTtFQTJCTjs7RUF6QkU7SUFDSSx1QkFBQTtJQUNBLGdDQUFBO0VBNEJOOztFQTFCRTtJQUNJLGVBQUE7RUE2Qk47QUFDRiIsImZpbGUiOiJkaXNjb3VudC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVye1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kOiAjZmNlZjUwXG59XG5pb24taGVhZGVyIGRpdntcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXJcbn1cbmlvbi1oZWFkZXIgaW1nIHtcbiAgICB3aWR0aDogMTIwcHg7XG59XG5pb24tYnV0dG9uIHtcbiAgICAtLWJhY2tncm91bmQ6ICNFMUUxRTE7XG4gICAgLS1jb2xvcjogIzAwMDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgICB3aWR0aDogMjUwcHg7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAyZW07XG4gICAgLS1wYWRkaW5nLWVuZDogMmVtO1xuICAgIC0tYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIGZvbnQtc2l6ZTogNXZ3O1xuICAgIGhlaWdodDogMTAwcHg7XG4gIH1cbiAgaW9uLWNvbnRlbnR7XG4gICAgLS1iYWNrZ3JvdW5kOiNmZmYgO1xuICAgIC0tY29sb3I6IGJsYWNrXG59XG5cbiAgLmNvdmVyIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIGxlZnQ6IDAlO1xuICAgIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC43OSk7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIHRvcDogMFxuICB9XG4gIC5jb3ZlcjIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6Mjd2aDtcbiAgICB0b3A6IDA7XG4gICAgYmFja2dyb3VuZDogcmdiKDI1NSAyNTUgMjU1IC8gNzklKTs7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwXG4gIH1cbiAgLmNvdmVyIGgxIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgbWFyZ2luLXRvcDogMTIlO1xuICAgICAgZm9udC1zaXplOiA1dnc7XG4gICAgICBjb2xvcjogYmxhY2tcbiAgfVxuICBcbiAgLmJhY2sge1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICB9XG4gIC5iYWNrSWZSaWdodHtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICB9XG5cblxuICAuYmFjayBpb24tYnV0dG9ue1xuICAgIC0tcGFkZGluZy1zdGFydDogMmVtO1xuICAgIC0tcGFkZGluZy1lbmQ6IDJlbTtcbiAgICAtLWJvcmRlci1yYWRpdXM6IDVweDtcbiAgICBtYXJnaW4tdG9wOiAyJTtcbiAgICBmb250LXNpemU6IDV2dztcbiAgICBoZWlnaHQ6IGF1dG87XG4gICAgbWFyZ2luLWJvdHRvbTogNSU7XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgfVxuICAuYmFjayBwIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgZm9udC1zaXplOiA1dndcbiAgfVxuICAucHJvZHVjdHN7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLnByb2R1Y3RzIC5wcmljZXtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtc2l6ZTogMTFweDtcbiAgICBtYXJnaW46IDBcbn1cbi5wcm9kdWN0cyAubmFtZXtcbiAgICBmb250LXNpemU6IC44cmVtO1xuICAgIG1hcmdpbi1ib3R0b206NXB4O1xuICAgIG1hcmdpbi10b3A6IDA7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGRcbn1cbi5wcm9kdWN0cyAucm93T25le1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjYzJjMmMyO1xufVxuLnByb2R1Y3RzIC5jb2xPbmV7XG4gICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2MyYzJjMjtcbn1cbi5tZW51SXRlbXtcbiAgICBwYWRkaW5nOiAzMHB4IDA7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjMmMyYzI7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyXG59XG4ubWVudUl0ZW0gcHtcbiAgICBtYXJnaW46IDA7XG4gICAgZm9udC1zaXplOiAuNXJlbTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zaXplOiAzdnc7XG59XG4ubWVudUl0ZW0gaW1nIHtcbiAgICBoZWlnaHQ6IDE1MHB4O1xufVxuXG4ucHJpY2VfbmFtZXtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgIGZvbnQtc2l6ZTogM3Z3XG59XG4ubmFtZU9mUHJkb2N1Y3R7XG4gICAgZm9udC1zaXplOiAzdndcbn1cbi5wcmljZV9uYW1lIC5hZnRlciB7XG4gICAgbWFyZ2luLWxlZnQ6IDE3cHg7XG59XG4ucHJpY2VfbmFtZSAuYWZ0ZXIgc3BhbntcbiAgICBjb2xvcjogcmVkXG59XG4ucHJpY2VfbmFtZSAuYmVmb3Ige1xuICAgIG1hcmdpbi1yaWdodDogMTdweDtcbiAgICBcbn1cbi5teU9yZGVye1xuICAgIGJhY2tncm91bmQ6ICNFMUUxRTE7XG4gICAgcGFkZGluZyA6NXB4IDEwcHhcbn1cbi5teU9yZGVyIGg0IHtcbiAgICBtYXJnaW46IDA7XG4gICAgZm9udC1zaXplOiA1dnc7XG4gICAgY29sb3I6IGJsYWNrXG59XG5cbi5jb25maXJtT3JDYW5jZWx7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbn1cbi5jb25maXJtT3JDYW5jZWwgaW9uLWJ1dHRvbntcbiAgICB3aWR0aDogMzMlO1xufVxuLmZvdGVyIHAge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDV2dztcbn1cblxuLmZvb3RlciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJvdHRvbTo4cHg7XG59XG4ucmVjbW9lbmRlZCBwe1xuICAgIG1hcmdpbjogMDtcbiAgICBmb250LXNpemU6IDV2dztcblxufVxuXG4ubWVudXtcbiAgICBoZWlnaHQ6IDcydmg7XG4gICAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICAgIGJhY2tncm91bmQ6ICNlN2U3ZTc7XG4gICAgbWFyZ2luLXRvcDogLTE3JTtcbn1cbi5wcm9kdWN0c3tcbiAgICBoZWlnaHQ6IDUydmg7XG4gICAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuLnByb2R1Y3RzIGltZyB7XG4gICAgd2lkdGg6IDIyMHB4O1xuICAgIGhlaWdodDogMjAwcHg7XG59XG5cbi5pZkNsaWNre1xuICAgIGhlaWdodDoxOXZoICFpbXBvcnRhbnQ7XG59XG5cbi5yZWNtb2VuZGVkIGlvbi1idXR0b257XG4gICAtLWJhY2tncm91bmQ6ICNjNmM2YzY7XG4gICBmb250LXNpemU6IDV2dztcbiAgIGhlaWdodDogYXV0bzs7XG4gICBcbn1cbi5Nb2RmaXJlc3tcbiBkaXNwbGF5OiBmbGV4O1xuIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlblxufVxuXG4uTW9kZmlyZXMgaDEge1xuICAgIG1hcmdpbi10b3A6IDhweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDVweDtcbiAgICBmb250LXNpemU6IDd2dztcbn1cbi5jb25maXJtT3JDYW5jZWwgaW9uLWJ1dHRvbntcbiAgICBmb250LXNpemU6IDR2dztcbiAgICBoZWlnaHQ6IDExMnB4O1xufVxuLm5leHQge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBib3R0b206MjQlO1xuICAgIGhlaWdodDogMTAwcHggIWltcG9ydGFudDtcbiAgICBsZWZ0OiAxNHB4O1xuICAgIC0tYmFja2dyb3VuZDogI2UxZTFlMSAhaW1wb3J0YW50O1xuICAgIGNvbG9yOiAjMDAwXG59XG4ubWFpbk1lbnV7XG4gICAgZm9udC1zaXplOiAzcmVtO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIG1hcmdpbi10b3A6IDUwJTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXJcbn1cbi8vIC5uZXh0TW9kZmlyZSB7XG4vLyAgICAgaGVpZ2h0OiAxMDBweDtcbi8vIH1cbi8vIC5uZXh0TW9kZmlyZSBpb24tYnV0dG9ue1xuLy8gICAgIC0tYmFja2dyb3VuZDogI2MyYzJjMjtcbi8vICAgICBoZWlnaHQ6IDEwMCU7XG4vLyB9XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDo3NjhweCl7XG4gICAgLmJhY2tCdXR0b257XG4gICAgICAgIHdpZHRoOiBhdXRvO1xuICAgICAgICBoZWlnaHQ6IDM3cHggIWltcG9ydGFudDtcbiAgICB9XG4gICAgLmltZ1Byb2R1Y3R7XG4gICAgICAgIHdpZHRoOiA4MXB4O1xuICAgIH1cbiAgICAucHJvZHVjdHMgaW1ne1xuICAgICAgaGVpZ2h0OiA3NHB4O1xuICAgICAgd2lkdGg6IGF1dG9cbiAgICB9XG5cbiAgICAubWVudUl0ZW0gaW1ne1xuICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICB9XG4gICAgICAubWVudUl0ZW17XG4gICAgICAgIHBhZGRpbmc6IDE1cHggMDtcbiAgICAgIH1cbiAgICAuY29uZmlybU9yQ2FuY2VsIGlvbi1idXR0b257XG4gICAgICBoZWlnaHQ6IDQ0cHg7XG4gICAgfVxuICAgIC5pZkNsaWNre1xuICAgICAgICBoZWlnaHQ6MTB2aCAhaW1wb3J0YW50O1xuICAgIH1cbiAgICAuY292ZXIye1xuICAgICAgICBoZWlnaHQ6IDMwdmg7XG4gICAgfVxuICAgIC5uZXh0IHtcbiAgICAgICAgaGVpZ2h0OiAzNnB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIC0tYmFja2dyb3VuZDogI2UxZTFlMSAhaW1wb3J0YW50O1xuICAgIH1cbiAgICAubWFpbk1lbnV7XG4gICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICB9XG4gIH0iXX0= */";

/***/ }),

/***/ 6502:
/*!**************************************************************!*\
  !*** ./src/app/pages/discount/discount.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"header\">\n    <img class=\"imgProduct \" src=\"assets/images/bingo.png\">\n  </div>\n  \n\n<ion-content [dir]=\"dir\">\n  <div class=\"\">\n    <div  [ngClass]=\"{'back':dir == 'ltr', 'backIfRight':dir == 'rtl'}\">\n      <ion-button class=\"backButton\" (click)=\"goBack()\">{{Back}}</ion-button>\n    </div>\n\n    <ion-grid style=\"padding: 0\">\n      <ion-row>\n        <ion-col class=\"menu\" [ngClass]=\"{'ifClick':showModfire}\" size=\"3\">\n          <p class=\"mainMenu\"> {{Menu}} </p>\n          <div  class=\"menuItem\" routerLink=\"/compo\">\n            <img src=\"assets/images/mostSelling.png\">\n            <p>{{Compo}}</p>\n          </div>\n          <div class=\"menuItem\" (click)=\"gotToDetails('Discount')\">\n            <img src=\"assets/images/discount.png\">\n            <p>{{discount}}</p>\n          </div>\n          <div  class=\"menuItem\" routerLink=\"/promtions\">\n            <img src=\"assets/images/promotion.png\">\n            <p>{{promotions}}</p>\n          </div>\n          <div>\n            <div *ngFor=\"let item of categoris\" class=\"menuItem\" (click)=\"ChoseCategori(item)\">\n              <img src=\"{{item.Image}}\">\n              <p>{{item.Name}}</p>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col>\n          <div class=\"products\" [ngClass]=\"{'ifClick':showModfire}\">\n            <ion-grid>\n              <ion-row>\n\n                <ion-col size=\"6\" class=\"rowOne colOne\" (click)=\"GetModifiresbyProductId(item,item.Id)\"\n                  *ngFor=\"let item of items ; let i = index\">\n                  <div class=\"price_name\">\n                    <p class=\"after\">\n                      {{Befor}}\n                      <br>\n                      <span><s>{{LE}} {{item.Price | number : '1.2-2'}}</s></span>\n                    </p>\n                    <p class=\"befor\">\n                      {{After}}\n                      <br>\n                      <span>{{LE}} {{item.PriceAfterDiscount | number : '1.2-2'}}</span>\n                    </p>\n                  </div>\n\n                  <img src=\"{{item.Image}}\">\n                  <p class=\"nameOfPrdocuct\">{{item.Name}}</p>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <div [ngClass]=\"{'cover2':showModfire}\"></div>\n  </div>\n\n\n  <section class=\"recmoended\" *ngIf=\"showModfire\">\n    <div class=\"Modfires\">\n      <h1>{{Modfires}}</h1>\n      <ion-button (click)=\"close()\">{{Back}}</ion-button>\n    </div>\n\n    <ion-grid>\n      <ion-row>\n        <ion-col (click)=\"gotToDetails(item)\" *ngFor=\"let item of ModifiresbyProductId ; let i = index\" size=\"3\">\n          <p class=\"price\">LE {{item.Price}}</p>\n          <img src=\"{{item.Image}}\">\n          <p class=\"name\">{{item.Name}}</p>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <ion-button class=\"next\" (click)=\"gotToDetails('normal')\">{{Next}}</ion-button>\n  </section>\n\n  <section class=\"footer\">\n    <div class=\"myOrder\">\n      <h4>{{MyOrder}}</h4>\n    </div>\n    <div class=\"foter\">\n      <p>{{arrOfModLength}}</p>\n      <div class=\"confirmOrCancel\">\n        <ion-button [disabled]=\"arrOfModLength\" (click)=\"Done()\">{{OrderDone}}</ion-button>\n        <ion-button [disabled]=\"arrOfModLength\" (click)=\"cancelOrder()\">{{Cancel}}</ion-button>\n      </div>\n    </div>\n  </section>\n\n\n\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_discount_discount_module_ts.js.map