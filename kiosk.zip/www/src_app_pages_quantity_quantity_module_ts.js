"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_quantity_quantity_module_ts"],{

/***/ 9839:
/*!***********************************************************!*\
  !*** ./src/app/pages/quantity/quantity-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuantityPageRoutingModule": () => (/* binding */ QuantityPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _quantity_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./quantity.page */ 4386);




const routes = [
    {
        path: '',
        component: _quantity_page__WEBPACK_IMPORTED_MODULE_0__.QuantityPage
    }
];
let QuantityPageRoutingModule = class QuantityPageRoutingModule {
};
QuantityPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], QuantityPageRoutingModule);



/***/ }),

/***/ 8497:
/*!***************************************************!*\
  !*** ./src/app/pages/quantity/quantity.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuantityPageModule": () => (/* binding */ QuantityPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _quantity_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./quantity-routing.module */ 9839);
/* harmony import */ var _quantity_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./quantity.page */ 4386);







let QuantityPageModule = class QuantityPageModule {
};
QuantityPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _quantity_routing_module__WEBPACK_IMPORTED_MODULE_0__.QuantityPageRoutingModule
        ],
        declarations: [_quantity_page__WEBPACK_IMPORTED_MODULE_1__.QuantityPage]
    })
], QuantityPageModule);



/***/ }),

/***/ 4386:
/*!*************************************************!*\
  !*** ./src/app/pages/quantity/quantity.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuantityPage": () => (/* binding */ QuantityPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _quantity_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./quantity.page.html?ngResource */ 8425);
/* harmony import */ var _quantity_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./quantity.page.scss?ngResource */ 1519);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);








let QuantityPage = class QuantityPage {
    constructor(navCtr, location, route, rest) {
        this.navCtr = navCtr;
        this.location = location;
        this.route = route;
        this.rest = rest;
        this.count = 1;
        this.showOrHideMod = false;
    }
    ngOnInit() {
        this.langId = localStorage.getItem("lang");
        if (this.langId == '1') {
            this.dir = 'rtl';
            this.Back = "رجوع";
            this.Cancel = "إلغاء";
            this.addChange = "متابعة";
            this.Quantity = "العدد";
            this.price = "السعر";
            this.ingedtiont = "الاضافات";
            this.modfieres = 'المكونات';
            this.edit = "هل تريد تغير اي إضافات";
            this.Customized = "تعديل";
            this.LE = "جنيه";
        }
        else {
            this.dir = 'ltr';
            this.Back = "Back";
            this.Cancel = "Cancel";
            this.addChange = "continue";
            this.Quantity = "Quantity";
            this.price = "Price";
            this.ingedtiont = "Ingredients";
            this.modfieres = 'Modifiers ';
            this.edit = "Want to Change Ingredients ?";
            this.Customized = "Customized";
            this.LE = "LE";
        }
        this.getData();
    }
    getData() {
        this.item = JSON.parse(sessionStorage.getItem('ModfireOfChose'));
        console.log(this.item);
        // if(!this.item.Name){
        //   this.showOrHideMod = false
        // }else {
        //   this.showOrHideMod = true
        //   this.modfireName = this.item.Name
        //   this.modfirePrice = this.item.Price
        //   console.log(this.modfireName,this.modfirePrice)
        // }
        this.prdouct = JSON.parse(sessionStorage.getItem('ProductOfChose'));
        this.nameOfItem = this.prdouct.Name;
        if (this.prdouct.NewPrice == 0) {
            this.itemPrice = this.prdouct.Price;
        }
        else {
            this.itemPrice = this.prdouct.NewPrice;
        }
        this.image = this.prdouct.Image;
        this.modfiresArr = this.item.modfire;
        if (this.item.ingridtArr.length != 0) {
            this.arrayOfIngr = this.item.ingridtArr;
            this.souceName = this.item.ingridtArr[0].Name;
            this.souceCount = this.item.ingridtArr[0].count;
            this.soucePrice = this.item.ingridtArr[0].Price * this.item.ingridtArr[0].count;
            console.log(this.souceName, this.souceCount, this.soucePrice);
        }
        else {
            this.souceName = " ";
            this.souceCount = " ";
        }
    }
    plus() {
        // this.itemPrice = this.item.Price
        this.count = this.count + 1;
        // this.itemPrice = this.itemPrice * this.count
    }
    minus() {
        if (this.count != 1) {
            // this.itemPrice = this.item.Price
            this.count = this.count - 1;
            // this.itemPrice = this.itemPrice * this.count
        }
    }
    goBack() {
        this.location.back();
        // if(this.item.ingridtArr.length != 0){
        //   this.route.navigateByUrl('/add-souce')
        // }else {
        //   this.route.navigateByUrl('/categoris')
        // }
    }
    // gotoMenu(){
    //   console.log(this.item)
    //   this.item.Prdoucts[0].count = this.count
    //   if(this.item.ingridtArr.length != 0){
    //     for(let i = 0 ;  i < this.item.ingridtArr.length ; i++){
    //       this.item.ingridtArr[i].count = this.item.ingridtArr[i].count * this.count
    //     }
    //   }
    //   if(this.item.modfire.length != 0){
    //     for(let i = 0 ;  i < this.item.modfire.length ; i++){
    //       this.item.modfire[i].count = this.item.modfire[i].count * this.count
    //     }
    //   }
    //   let dumy = []
    //  let arrOfModfire = JSON.parse(sessionStorage.getItem('arrOfModfire'))
    //   if(arrOfModfire){
    //     arrOfModfire.push(this.item)
    //     sessionStorage.setItem('arrOfModfire',JSON.stringify(arrOfModfire))
    //   }else {
    //     dumy.push(this.item)
    //     sessionStorage.setItem('arrOfModfire',JSON.stringify(dumy))
    //   }
    //   this.rest.sendObsData('true')
    //   this.route.navigateByUrl('/main_menu')
    //   sessionStorage.removeItem('ifModFire')
    // }
    gotoCustmoize() {
        let modfireArrInsession = JSON.parse(sessionStorage.getItem('modfiresArr'));
        let ingrdArrInsession = JSON.parse(sessionStorage.getItem('IngrdDub'));
        if (ingrdArrInsession.length == 0 && modfireArrInsession.length == 0) {
            this.item.Prdoucts[0].count = this.count;
            let arrOfModfire = JSON.parse(sessionStorage.getItem('arrOfModfire'));
            if (arrOfModfire) {
                arrOfModfire.push(this.item);
                sessionStorage.setItem('arrOfModfire', JSON.stringify(arrOfModfire));
            }
            else {
                let dumy = [];
                dumy.push(this.item);
                sessionStorage.setItem('arrOfModfire', JSON.stringify(dumy));
            }
            this.rest.sendObsData('true');
            this.route.navigateByUrl('/main_menu');
            sessionStorage.removeItem('ifModFire');
        }
        else {
            sessionStorage.setItem("countOfProduct", this.count + "");
            this.route.navigateByUrl('/customize');
        }
    }
    cancelOrder() {
        sessionStorage.clear();
        this.route.navigateByUrl('/main_menu');
    }
};
QuantityPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__.Location },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService }
];
QuantityPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-quantity',
        template: _quantity_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_quantity_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], QuantityPage);



/***/ }),

/***/ 1519:
/*!**************************************************************!*\
  !*** ./src/app/pages/quantity/quantity.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcef50;\n}\n\nion-content {\n  --background:#fff ;\n  --color: black ;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: #000;\n  text-transform: none;\n}\n\n.cover {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  left: 0%;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #fff;\n  top: 0;\n}\n\n.cover h1 {\n  font-weight: bold;\n  margin-top: 12%;\n  font-size: 5vw;\n  color: black;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.back, .backIfRight {\n  text-transform: none;\n  margin-top: 5px;\n}\n\n.back ion-button, .backIfRight ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 5%;\n  font-size: 5vw;\n  height: 84px;\n  margin-bottom: 3%;\n}\n\n.order {\n  display: flex;\n  justify-content: space-between;\n}\n\n.order .orderInfo {\n  display: flex;\n}\n\n.orderInfo img {\n  margin-right: 20px;\n  margin-left: 20px;\n  max-width: 250px;\n  max-height: 200px;\n}\n\n.orderInfo p {\n  font-size: 4vw;\n  margin-bottom: 5px;\n}\n\n.orderInfo span {\n  font-size: 4vw;\n}\n\n.ExtraName {\n  height: 18vh;\n  overflow: scroll;\n}\n\n.ExtraName p {\n  font-size: 4vw;\n}\n\nhr {\n  background: #ccc9c9;\n}\n\n.quantity {\n  text-align: center;\n}\n\n.quantity p {\n  font-size: 5vw;\n}\n\n.plus {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.plus ion-button {\n  --background: #fcef50;\n  color: #000;\n  font-size: 5vw;\n  height: 113px;\n}\n\n.plus div {\n  display: flex;\n}\n\n.count {\n  justify-content: center;\n  align-items: center;\n}\n\n.count p {\n  background: gainsboro;\n  padding: 24px 72px;\n  border-radius: 5px;\n  margin: 0 15px;\n}\n\n.footer {\n  position: absolute;\n  bottom: 1%;\n  width: 100%;\n}\n\n.footer div {\n  display: flex;\n  justify-content: space-around;\n}\n\n.footer ion-button {\n  width: 35%;\n  font-size: 4vw;\n  height: 120px;\n}\n\n.cistomiz {\n  --background: #000 ;\n  color: #fff;\n  font-size: 4vw;\n  height: 91px;\n}\n\n@media only screen and (max-width: 768px) {\n  .orderInfo img {\n    width: 26%;\n  }\n\n  .imgProduct {\n    width: 82px;\n  }\n\n  .products img {\n    height: 74px;\n  }\n\n  .menuItem img {\n    height: 74px;\n  }\n\n  .footer ion-button {\n    height: 44px;\n  }\n\n  .back ion-button {\n    margin-bottom: 0;\n    height: 36px;\n    margin-top: 0;\n  }\n\n  .addSouce ion-button {\n    height: 43px;\n  }\n\n  .cistomiz {\n    height: 45px;\n  }\n\n  .plus ion-button {\n    height: 40px;\n  }\n\n  .count p {\n    padding: 12px 59px;\n  }\n\n  .orderInfo p {\n    font-size: 4vw;\n  }\n\n  .back ion-button, .backIfRight ion-button {\n    height: 41px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInF1YW50aXR5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUNBO0VBQ0UscUJBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7QUFFRjs7QUFBQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxRQUFBO0VBQ0EscUNBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxNQUFBO0FBR0Y7O0FBREE7RUFDRSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQUlGOztBQUZBO0VBQ0UsaUJBQUE7QUFLRjs7QUFIQTtFQUNFLGdCQUFBO0FBTUY7O0FBSEU7RUFDRSxvQkFBQTtFQUNBLGVBQUE7QUFNSjs7QUFKRTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FBT0o7O0FBTEU7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7QUFRTjs7QUFORTtFQUNJLGFBQUE7QUFTTjs7QUFQRTtFQUNJLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBVU47O0FBUEU7RUFDRSxjQUFBO0VBQ0Esa0JBQUE7QUFVSjs7QUFSRTtFQUNFLGNBQUE7QUFXSjs7QUFSRTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtBQVdKOztBQVRFO0VBQ0UsY0FBQTtBQVlKOztBQVRFO0VBQ0ksbUJBQUE7QUFZTjs7QUFURTtFQUNJLGtCQUFBO0FBWU47O0FBVkU7RUFDRSxjQUFBO0FBYUo7O0FBWEU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQWNKOztBQVpFO0VBQ0kscUJBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7QUFlTjs7QUFiRTtFQUNJLGFBQUE7QUFnQk47O0FBZEU7RUFDSSx1QkFBQTtFQUNBLG1CQUFBO0FBaUJOOztBQWZFO0VBQ0UscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQWtCSjs7QUFoQkU7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FBbUJKOztBQWpCRTtFQUNFLGFBQUE7RUFDQSw2QkFBQTtBQW9CSjs7QUFsQkU7RUFDRSxVQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7QUFxQko7O0FBakJFO0VBQ0UsbUJBQUE7RUFBcUIsV0FBQTtFQUFhLGNBQUE7RUFBYyxZQUFBO0FBdUJwRDs7QUFyQkU7RUFDRTtJQUNFLFVBQUE7RUF3Qko7O0VBdEJFO0lBQ0UsV0FBQTtFQXlCSjs7RUF2QkU7SUFDRSxZQUFBO0VBMEJKOztFQXhCRTtJQUNFLFlBQUE7RUEyQko7O0VBekJFO0lBQ0UsWUFBQTtFQTRCSjs7RUExQkU7SUFDRSxnQkFBQTtJQUNBLFlBQUE7SUFDQSxhQUFBO0VBNkJKOztFQTNCRTtJQUNFLFlBQUE7RUE4Qko7O0VBekJFO0lBQ0UsWUFBQTtFQTRCSjs7RUExQkU7SUFDRSxZQUFBO0VBNkJKOztFQTNCRTtJQUNFLGtCQUFBO0VBOEJKOztFQTVCRTtJQUNFLGNBQUE7RUErQko7O0VBN0JFO0lBQ0UsWUFBQTtFQWdDSjtBQUNGIiwiZmlsZSI6InF1YW50aXR5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJ7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZDogI2ZjZWY1MFxufVxuXG5pb24tY29udGVudHtcbiAgLS1iYWNrZ3JvdW5kOiNmZmYgO1xuICAtLWNvbG9yOiBibGFja1xufVxuaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogI0UxRTFFMTtcbiAgLS1jb2xvcjogIzAwMDsgXG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xufVxuLmNvdmVyIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBsZWZ0OiAwJTtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjc5KTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgdG9wOiAwXG59XG4uY292ZXIgaDEge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luLXRvcDogMTIlO1xuICBmb250LXNpemU6IDV2dztcbiAgY29sb3I6IGJsYWNrXG59XG4uYmFjayB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuLmJhY2tJZlJpZ2h0e1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuXG4gIC5iYWNrICwuYmFja0lmUmlnaHR7XG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gICAgbWFyZ2luLXRvcDogNXB4O1xuICB9XG4gIC5iYWNrIGlvbi1idXR0b24gLCAuYmFja0lmUmlnaHQgaW9uLWJ1dHRvbntcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDJlbTtcbiAgICAtLXBhZGRpbmctZW5kOiAyZW07XG4gICAgLS1ib3JkZXItcmFkaXVzOjVweDtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICBmb250LXNpemU6IDV2dztcbiAgICBoZWlnaHQ6IDg0cHg7XG4gICAgbWFyZ2luLWJvdHRvbTozJVxuICB9XG4gIC5vcmRlcntcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6c3BhY2UtYmV0d2VlbjtcbiAgfVxuICAub3JkZXIgLm9yZGVySW5mbyB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICB9XG4gIC5vcmRlckluZm8gaW1nIHtcbiAgICAgIG1hcmdpbi1yaWdodDoyMHB4O1xuICAgICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gICAgICBtYXgtd2lkdGg6IDI1MHB4O1xuICAgICAgbWF4LWhlaWdodDogMjAwcHg7XG5cbiAgfVxuICAub3JkZXJJbmZvIHAge1xuICAgIGZvbnQtc2l6ZTogNHZ3O1xuICAgIG1hcmdpbi1ib3R0b206IDVweDtcbiAgfVxuICAub3JkZXJJbmZvIHNwYW57XG4gICAgZm9udC1zaXplOiA0dnc7XG4gIH1cblxuICAuRXh0cmFOYW1lIHtcbiAgICBoZWlnaHQ6IDE4dmg7XG4gICAgb3ZlcmZsb3c6IHNjcm9sbDtcbiAgfVxuICAuRXh0cmFOYW1lIHAge1xuICAgIGZvbnQtc2l6ZTogNHZ3O1xuXG4gIH1cbiAgaHJ7XG4gICAgICBiYWNrZ3JvdW5kOiAjY2NjOWM5XG4gIH1cblxuICAucXVhbnRpdHl7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXJcbiAgfVxuICAucXVhbnRpdHkgcCB7XG4gICAgZm9udC1zaXplOiA1dndcbiAgfVxuICAucGx1cyB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICB9XG4gIC5wbHVzIGlvbi1idXR0b257XG4gICAgICAtLWJhY2tncm91bmQ6ICNmY2VmNTA7XG4gICAgICBjb2xvcjogIzAwMDtcbiAgICAgIGZvbnQtc2l6ZTogNXZ3O1xuICAgICAgaGVpZ2h0OiAxMTNweDtcbiAgfVxuICAucGx1cyBkaXZ7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICB9XG4gIC5jb3VudCB7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXJcbiAgfVxuICAuY291bnQgcCB7XG4gICAgYmFja2dyb3VuZDogZ2FpbnNib3JvO1xuICAgIHBhZGRpbmc6IDI0cHggNzJweDtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgbWFyZ2luOiAwIDE1cHg7XG4gIH1cbiAgLmZvb3RlciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJvdHRvbTogMSU7XG4gICAgd2lkdGg6IDEwMCVcbiAgfVxuICAuZm9vdGVyIGRpdiB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZFxuICB9XG4gIC5mb290ZXIgaW9uLWJ1dHRvbntcbiAgICB3aWR0aDogMzUlO1xuICAgIGZvbnQtc2l6ZTogNHZ3O1xuICAgIGhlaWdodDogMTIwcHg7XG4gICAgXG5cbiAgfVxuICAuY2lzdG9taXoge1xuICAgIC0tYmFja2dyb3VuZDogIzAwMCA7IGNvbG9yOiAjZmZmIDtmb250LXNpemU6NHZ3O2hlaWdodDogOTFweDtcbiAgfVxuICBAbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6NzY4cHgpe1xuICAgIC5vcmRlckluZm8gaW1nIHtcbiAgICAgIHdpZHRoOiAyNiVcbiAgICB9XG4gICAgLmltZ1Byb2R1Y3R7XG4gICAgICB3aWR0aDogODJweDtcbiAgICB9XG4gICAgLnByb2R1Y3RzIGltZ3tcbiAgICAgIGhlaWdodDogNzRweDtcbiAgICB9XG4gICAgLm1lbnVJdGVtIGltZ3tcbiAgICAgIGhlaWdodDogNzRweDtcbiAgICB9XG4gICAgLmZvb3RlciBpb24tYnV0dG9ue1xuICAgICAgaGVpZ2h0OiA0NHB4O1xuICAgIH1cbiAgICAuYmFjayBpb24tYnV0dG9ue1xuICAgICAgbWFyZ2luLWJvdHRvbTogMDtcbiAgICAgIGhlaWdodDogMzZweDtcbiAgICAgIG1hcmdpbi10b3A6IDA7XG4gICAgfVxuICAgIC5hZGRTb3VjZSBpb24tYnV0dG9ue1xuICAgICAgaGVpZ2h0OiA0M3B4O1xuICAgIH1cbiAgICAvLyAuY291bnR7XG4gICAgLy8gICBoZWlnaHQ6NDNweDtcbiAgICAvLyB9XG4gICAgLmNpc3RvbWl6IHtcbiAgICAgIGhlaWdodDogNDVweDtcbiAgICB9XG4gICAgLnBsdXMgaW9uLWJ1dHRvbntcbiAgICAgIGhlaWdodDogNDBweDtcbiAgICB9XG4gICAgLmNvdW50IHAge1xuICAgICAgcGFkZGluZzogMTJweCA1OXB4O1xuICAgIH1cbiAgICAub3JkZXJJbmZvIHAge1xuICAgICAgZm9udC1zaXplOiA0dnc7XG4gICAgfVxuICAgIC5iYWNrIGlvbi1idXR0b24gLCAuYmFja0lmUmlnaHQgaW9uLWJ1dHRvbntcbiAgICAgIGhlaWdodDogNDFweDtcbiAgICB9XG4gIH0iXX0= */";

/***/ }),

/***/ 8425:
/*!**************************************************************!*\
  !*** ./src/app/pages/quantity/quantity.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <div>\n    <img class=\"imgProduct\" src=\"assets/images/panner.jpeg\">\n  </div>\n  <div class=\"cover\">\n    <h1>{{nameOfItem}}</h1>\n  </div>\n</ion-header> -->\n<div class=\"header\">\n  <img class=\"imgProduct \" src=\"assets/images/bingo.png\">\n</div>\n\n\n<ion-content [dir]=\"dir\">\n  <div [ngClass]=\"{'back':dir == 'ltr','backIfRight':dir == 'rtl'}\">\n    <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n  </div>\n\n  <section class=\"order ion-padding-start ion-padding-end\">\n    <div class=\"orderInfo\">\n      <img src=\"{{image}}\">\n      <div>\n        <p>{{nameOfItem}}</p>\n        <!-- <p *ngIf=\"item.ingridtArr.length != 0\">{{edit}}</p> -->\n        <span *ngIf=\"langId != 1\">{{LE}} {{itemPrice | number : '1.2-2'}}</span>\n        <span *ngIf=\"langId == 1\">{{itemPrice | number : '1.2-2'}} {{LE}}</span>\n      </div>\n    </div>\n    <!-- <div *ngIf=\"item.ingridtArr.length != 0\">\n      <ion-button class=\"cistomiz\" routerLink=\"/add-modfires\">{{Customized}}</ion-button>\n    </div> -->\n\n  </section>\n  <!-- <div *ngIf=\"item.ingridtArr.length != 0\" class=\"ExtraName  ion-padding-start ion-padding-end\">\n    <div class=\"order\" *ngFor=\"let item of arrayOfIngr\">\n      <p> ( {{modfieres}} ) : {{item.count}} {{item.Name}}</p>\n      <p *ngIf=\"langId != 1\">{{Price}} {{LE}} {{item.Price}}</p>\n      <p *ngIf=\"langId == 1\">{{item.Price}} {{LE}} {{Price}} </p>\n    </div>\n    <hr>\n  </div>\n  <div *ngIf=\"item.modfire.length != 0\" class=\" ExtraName  ion-padding-start ion-padding-end\">\n    <div class=\"order\" *ngFor=\"let item of modfiresArr\">\n      <p>( {{ingedtiont}} )  : {{item.count}} {{item.Name}}</p>\n      <p *ngIf=\"langId != 1\">{{Price}} {{LE}} {{item.Price}}</p>\n      <p *ngIf=\"langId == 1\">{{item.Price}} {{LE}} {{Price}} </p>\n    </div>\n  </div> -->\n  <!-- <div *ngIf=\"showOrHideMod\" class=\"ion-padding-start ion-padding-end\">\n    <hr>\n  </div> -->\n\n  <div class=\"quantity\">\n    <p>\n      {{Quantity}}\n    </p>\n    <div class=\"plus\" [dir]=\"dir\">\n      <div>\n        <ion-button (click)=\"plus()\">+</ion-button>\n        <div class=\"count\">\n          <p>{{count}}</p>\n          <ion-button (click)=\"minus()\">-</ion-button>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div class=\"footer\" dir=\"ltr\">\n    <div>\n      <ion-button (click)=\"cancelOrder()\">{{Cancel}}</ion-button>\n      <ion-button (click)=\"gotoCustmoize()\">{{addChange}}</ion-button>\n    </div>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_quantity_quantity_module_ts.js.map