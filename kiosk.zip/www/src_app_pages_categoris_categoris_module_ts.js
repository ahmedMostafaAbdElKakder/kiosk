"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_categoris_categoris_module_ts"],{

/***/ 5378:
/*!*************************************************************!*\
  !*** ./src/app/pages/categoris/categoris-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CategorisPageRoutingModule": () => (/* binding */ CategorisPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _categoris_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./categoris.page */ 3050);




const routes = [
    {
        path: '',
        component: _categoris_page__WEBPACK_IMPORTED_MODULE_0__.CategorisPage
    }
];
let CategorisPageRoutingModule = class CategorisPageRoutingModule {
};
CategorisPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CategorisPageRoutingModule);



/***/ }),

/***/ 1829:
/*!*****************************************************!*\
  !*** ./src/app/pages/categoris/categoris.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CategorisPageModule": () => (/* binding */ CategorisPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _categoris_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./categoris-routing.module */ 5378);
/* harmony import */ var _categoris_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./categoris.page */ 3050);







let CategorisPageModule = class CategorisPageModule {
};
CategorisPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _categoris_routing_module__WEBPACK_IMPORTED_MODULE_0__.CategorisPageRoutingModule
        ],
        declarations: [_categoris_page__WEBPACK_IMPORTED_MODULE_1__.CategorisPage]
    })
], CategorisPageModule);



/***/ }),

/***/ 3050:
/*!***************************************************!*\
  !*** ./src/app/pages/categoris/categoris.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CategorisPage": () => (/* binding */ CategorisPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _categoris_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./categoris.page.html?ngResource */ 1395);
/* harmony import */ var _categoris_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./categoris.page.scss?ngResource */ 3979);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);







let CategorisPage = class CategorisPage {
    constructor(rest, route, navCtr) {
        this.rest = rest;
        this.route = route;
        this.navCtr = navCtr;
        this.items = [];
        this.showModfire = false;
        this.ModifiresbyProductId = [];
        this.disalbedButton = true;
    }
    ngOnInit() {
        this.langId = localStorage.getItem('lang');
        if (this.langId == '1') {
            this.dir = "rtl";
            this.Menu = "قائمة الطلبات";
            this.Back = "رجوع";
            this.Cancel = "إلغاء الطلب";
            this.OrderDone = "دفع";
            this.MyOrder = "طلباتي - في المتجر";
            this.Modfires = "الاضافات";
            this.Next = "التالي";
            this.bestSelling = "افضل المنتجات";
            this.discount = "الخصومات";
            this.promotions = "العروض";
            this.LE = "جنيه";
        }
        else {
            this.dir = "ltr";
            this.Menu = "Main Menu";
            this.Back = "Back";
            this.Cancel = "Cancel Order";
            this.OrderDone = "Done";
            this.MyOrder = "My Order - In Shop";
            this.Modfires = "Modifiers";
            this.Next = "Next";
            this.bestSelling = "Best Selling";
            this.discount = "Discount";
            this.promotions = "Promotion";
            this.LE = "LE";
        }
        this.getData();
        this.getCategoris();
        this.ifArrOfModfier();
    }
    getCategoris() {
        this.rest.getCategoriWithProduct(this.langId).subscribe((res) => {
            console.log(res);
            this.categoris = res.categoriesProducts;
            for (let i = 0; i < this.categoris.length; i++) {
                if (i == 2 || i == 5 || i == 8 || i == 11) {
                    this.categoris[i].status = true;
                }
                else {
                    this.categoris[i].status = false;
                }
            }
        });
    }
    getData() {
        this.categoriObj = JSON.parse(sessionStorage.getItem('obj'));
        console.log(this.categoriObj);
        this.nameOfCat = this.categoriObj.Name;
        this.items = this.categoriObj.Products;
        for (let i = 0; i < this.items.length; i++) {
            if (i == 2 || i == 5 || i == 8 || i == 11) {
                this.items[i].status = true;
            }
            else {
                this.items[i].status = false;
            }
        }
    }
    GetModifiresbyProductId(item, id) {
        this.idOfIngrdtiont = id;
        sessionStorage.setItem('ProductOfChose', JSON.stringify(item));
        this.price = item.Price;
        this.rest.GetModifiresbyProductId(id, this.langId).subscribe((res) => {
            console.log(res);
            if (res.length == 0) {
                let arr = [];
                sessionStorage.setItem('modfiresArr', JSON.stringify(arr));
                // this.route.navigateByUrl('/add-modfires')
            }
            else {
                sessionStorage.setItem('modfiresArr', JSON.stringify(res));
            }
            this.rest.GetItemsbyProductId(this.langId, id).subscribe((res) => {
                let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
                if (res.length == 0) {
                    console.log("hamdaaaa");
                    let item = {};
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('IngrdDub', JSON.stringify([]));
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    let item = {};
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('IngrdDub', JSON.stringify(res));
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                    // this.gotToDetails('normal')
                }
            });
        });
    }
    close() {
        this.showModfire = false;
    }
    ifArrOfModfier() {
        let arrOfMod = JSON.parse(sessionStorage.getItem('arrOfModfire'));
        if (arrOfMod) {
            this.disalbedButton = false;
            if (this.langId == '1') {
                this.arrOfModLength = "إجمالي المنتجات" + " " + `(${arrOfMod.length})`;
            }
            else {
                this.arrOfModLength = "Total Items" + " " + `(${arrOfMod.length})`;
            }
        }
        else {
            this.disalbedButton = true;
            if (this.langId == '1') {
                this.arrOfModLength = "لا يوجد طلبات";
            }
            else {
                this.arrOfModLength = "You Order is Empty";
            }
        }
    }
    gotToDetails(item) {
        if (item == "normal") {
            let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
            this.rest.GetItemsbyProductId(this.langId, this.idOfIngrdtiont).subscribe((res) => {
                if (res.length == 0) {
                    let item = {};
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    let item = {};
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/add-souce');
                }
            });
            sessionStorage.setItem("ifModFire", 'false');
        }
        else if (item == 'Discount') {
            this.rest.gitDiscount(this.langId).subscribe((res) => {
                console.log(res);
                let obj = {
                    Name: 'Discount',
                    Products: res
                };
                sessionStorage.setItem('obj', JSON.stringify(obj));
                this.route.navigateByUrl('/discount');
            });
        }
        else {
            console.log("asdasdsa", item);
            this.rest.GetItemsbyProductId(this.langId, this.idOfIngrdtiont).subscribe((res) => {
                if (res.length == 0) {
                    let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/add-souce');
                }
            });
        }
    }
    ChoseCategori(item) {
        sessionStorage.setItem("obj", JSON.stringify(item));
        this.getData();
    }
    goBack() {
        this.route.navigateByUrl('/main_menu');
    }
    cancelOrder() {
        sessionStorage.clear();
        this.route.navigateByUrl('/suggestions');
    }
    Done() {
        this.route.navigateByUrl('/review');
    }
};
CategorisPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController }
];
CategorisPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-categoris',
        template: _categoris_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_categoris_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CategorisPage);



/***/ }),

/***/ 3979:
/*!****************************************************************!*\
  !*** ./src/app/pages/categoris/categoris.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcef50;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: black;\n  text-transform: none;\n}\n\nion-content {\n  --background:#fff ;\n  --color: black ;\n}\n\n.cover {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  left: 0%;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #fff;\n  top: 0;\n}\n\n.cover2 {\n  position: absolute;\n  width: 100%;\n  height: 27vh;\n  top: 0;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #000;\n}\n\n.cover h1 {\n  font-weight: bold;\n  margin-top: 12%;\n  font-size: 5vw;\n  color: black;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.back p, .backIfRight P {\n  font-weight: bold;\n  font-size: 5vw;\n}\n\n.back ion-button, .backIfRight ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 2%;\n  font-size: 5vw;\n  height: auto;\n  margin-bottom: 5%;\n  height: 100px;\n}\n\n.products {\n  text-align: center;\n}\n\n.products .price {\n  text-align: left;\n  font-size: 11px;\n  margin: 0;\n}\n\n.products .name {\n  font-size: 0.8rem;\n  margin-bottom: 5px;\n  margin-top: 0;\n  font-weight: bold;\n}\n\n.products .rowOne {\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.colOne {\n  border-right: 1px solid #c2c2c2;\n}\n\n.menuItem {\n  padding: 30px 0;\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.menuItem p {\n  margin: 0;\n  font-size: 0.5rem;\n  text-align: center;\n  font-weight: bold;\n  font-size: 3vw;\n}\n\n.menuItem img {\n  height: 150px;\n}\n\n.price_name {\n  display: flex;\n  justify-content: space-between;\n  font-size: 10px;\n  margin-top: 10px;\n  font-size: 3vw;\n}\n\n.myOrder {\n  background: #E1E1E1;\n  padding: 5px 10px;\n}\n\n.myOrder h4 {\n  margin: 0;\n  font-size: 5vw;\n  color: black;\n}\n\n.confirmOrCancel {\n  display: flex;\n  justify-content: space-around;\n}\n\n.confirmOrCancel ion-button {\n  width: 33%;\n}\n\n.foter p {\n  text-align: center;\n  font-size: 5vw;\n}\n\n.footer {\n  position: absolute;\n  width: 100%;\n  bottom: 1%;\n}\n\n.recmoended p {\n  margin: 0;\n  font-size: 5vw;\n}\n\n.menu {\n  overflow-y: scroll;\n  border-radius: 5px;\n  margin-top: -17%;\n  background: #f0f0f0;\n  height: 72vh;\n  text-align: center;\n}\n\n.menu div {\n  border-bottom: 1px solid gray;\n}\n\n.menu .mainMenu {\n  font-size: 3rem;\n  font-weight: bold;\n  margin-top: 50%;\n}\n\n.products {\n  height: 52vh;\n  overflow-y: scroll;\n  padding-bottom: 10px;\n}\n\n.products img {\n  height: 150px;\n}\n\n.ifClick {\n  height: 19vh !important;\n}\n\n.recmoended ion-button {\n  --background: #E1E1E1;\n  font-size: 5vw;\n  height: auto;\n}\n\n.Modfires {\n  display: flex;\n  justify-content: space-between;\n}\n\n.Modfires h1 {\n  margin-top: 8px;\n  padding-left: 5px;\n  font-size: 7vw;\n}\n\n.confirmOrCancel ion-button {\n  font-size: 4vw;\n  height: 112px;\n}\n\n.next {\n  position: absolute;\n  bottom: 24%;\n  height: 100px !important;\n  left: 14px;\n  --background: rgb(252, 180, 0)!important;\n  color: #000;\n}\n\n@media only screen and (max-width: 768px) {\n  .imgProduct {\n    height: 71px;\n  }\n\n  .menu {\n    height: 67vh;\n    margin-top: -19%;\n  }\n\n  .menuItem {\n    padding: 12px 0;\n  }\n\n  .menuItem img {\n    height: 50px;\n    width: auto;\n  }\n\n  .back ion-button {\n    height: 36px;\n  }\n\n  .menu .mainMenu {\n    font-size: 13px;\n  }\n\n  .products img {\n    width: auto;\n    height: 90px;\n  }\n\n  .confirmOrCancel ion-button {\n    height: 44px;\n  }\n\n  .ifClick {\n    height: 10vh !important;\n  }\n\n  .cover2 {\n    height: 23vh;\n  }\n\n  .next {\n    height: 36px !important;\n  }\n\n  .back ion-button, .backIfRight ion-button {\n    height: 41px;\n  }\n\n  .next {\n    bottom: 25%;\n    left: 5px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhdGVnb3Jpcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0FBQUo7O0FBRUE7RUFDSSxxQkFBQTtFQUNBLGNBQUE7RUFDQSxvQkFBQTtBQUNKOztBQUNFO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0FBRUo7O0FBQ0U7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsUUFBQTtFQUNBLHFDQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsTUFBQTtBQUVKOztBQUFFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLE1BQUE7RUFDQSxxQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQUdKOztBQURFO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFJTjs7QUFGRTtFQUNFLGlCQUFBO0FBS0o7O0FBSEU7RUFDRSxnQkFBQTtBQU1KOztBQUpFO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0FBT047O0FBTEU7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7QUFRSjs7QUFORTtFQUNFLGtCQUFBO0FBU0o7O0FBUEE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxTQUFBO0FBVUo7O0FBUkE7RUFDSSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0FBV0o7O0FBVEE7RUFDSSxnQ0FBQTtBQVlKOztBQVZBO0VBQ0ksK0JBQUE7QUFhSjs7QUFYQTtFQUNJLGVBQUE7RUFDQSxnQ0FBQTtBQWNKOztBQVhBO0VBQ0ksU0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFjSjs7QUFYQTtFQUNJLGFBQUE7QUFjSjs7QUFaQTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFlSjs7QUFiQTtFQUNJLG1CQUFBO0VBQ0EsaUJBQUE7QUFnQko7O0FBZEE7RUFDSSxTQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFpQko7O0FBZEE7RUFDSSxhQUFBO0VBQ0EsNkJBQUE7QUFpQko7O0FBZkE7RUFDSSxVQUFBO0FBa0JKOztBQWhCQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQW1CSjs7QUFoQkE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0FBbUJKOztBQWhCQTtFQUNJLFNBQUE7RUFDQSxjQUFBO0FBbUJKOztBQWZBO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFrQko7O0FBaEJBO0VBQ0ksNkJBQUE7QUFtQko7O0FBakJBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQW9CSjs7QUFsQkE7RUFDSSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQkFBQTtBQXFCSjs7QUFuQkE7RUFDSSxhQUFBO0FBc0JKOztBQW5CQTtFQUNJLHVCQUFBO0FBc0JKOztBQW5CQTtFQUNHLHFCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFzQkg7O0FBbkJBO0VBQ0MsYUFBQTtFQUNBLDhCQUFBO0FBc0JEOztBQW5CQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFzQko7O0FBcEJBO0VBQ0ksY0FBQTtFQUNBLGFBQUE7QUF1Qko7O0FBckJBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0Esd0JBQUE7RUFDQSxVQUFBO0VBQ0Esd0NBQUE7RUFDQSxXQUFBO0FBd0JKOztBQWRBO0VBQ0k7SUFDSSxZQUFBO0VBaUJOOztFQWZFO0lBQ0ksWUFBQTtJQUNBLGdCQUFBO0VBa0JOOztFQWhCRTtJQUNJLGVBQUE7RUFtQk47O0VBakJFO0lBQ0ksWUFBQTtJQUNBLFdBQUE7RUFvQk47O0VBbEJFO0lBQ0ksWUFBQTtFQXFCTjs7RUFuQkU7SUFDSSxlQUFBO0VBc0JOOztFQXBCRTtJQUNJLFdBQUE7SUFDQSxZQUFBO0VBdUJOOztFQXBCRTtJQUNFLFlBQUE7RUF1Qko7O0VBckJFO0lBQ0ksdUJBQUE7RUF3Qk47O0VBdEJFO0lBQ0ksWUFBQTtFQXlCTjs7RUF2QkU7SUFDSSx1QkFBQTtFQTBCTjs7RUF4QkU7SUFDSSxZQUFBO0VBMkJOOztFQXpCSTtJQUNFLFdBQUE7SUFDQSxTQUFBO0VBNEJOO0FBQ0YiLCJmaWxlIjoiY2F0ZWdvcmlzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuLmhlYWRlcntcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgYmFja2dyb3VuZDogI2ZjZWY1MFxufVxuaW9uLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjRTFFMUUxO1xuICAgIC0tY29sb3I6IGJsYWNrOyBcbiAgICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgfVxuICBpb24tY29udGVudHtcbiAgICAtLWJhY2tncm91bmQ6I2ZmZiA7XG4gICAgLS1jb2xvcjogYmxhY2tcbn1cblxuICAuY292ZXIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbGVmdDogMCU7XG4gICAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjc5KTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgdG9wOiAwXG4gIH1cbiAgLmNvdmVyMiB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDoyN3ZoO1xuICAgIHRvcDogMDtcbiAgICBiYWNrZ3JvdW5kOiByZ2IoMjU1IDI1NSAyNTUgLyA3OSUpOztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDBcbiAgfVxuICAuY292ZXIgaDEge1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICBtYXJnaW4tdG9wOiAxMiU7XG4gICAgICBmb250LXNpemU6IDV2dztcbiAgICAgIGNvbG9yOiBibGFja1xuICB9XG4gIC5iYWNrIHtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgfVxuICAuYmFja0lmUmlnaHR7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgfVxuICAuYmFjayBwICwgLmJhY2tJZlJpZ2h0IFB7XG4gICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgIGZvbnQtc2l6ZTogNXZ3O1xuICB9XG4gIC5iYWNrIGlvbi1idXR0b24gLCAuYmFja0lmUmlnaHQgaW9uLWJ1dHRvbntcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDJlbTtcbiAgICAtLXBhZGRpbmctZW5kOiAyZW07XG4gICAgLS1ib3JkZXItcmFkaXVzOjVweDtcbiAgICBtYXJnaW4tdG9wOiAyJTtcbiAgICBmb250LXNpemU6IDV2dztcbiAgICBoZWlnaHQ6IGF1dG87XG4gICAgbWFyZ2luLWJvdHRvbTogNSU7XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgfVxuICAucHJvZHVjdHN7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLnByb2R1Y3RzIC5wcmljZXtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtc2l6ZTogMTFweDtcbiAgICBtYXJnaW46IDBcbn1cbi5wcm9kdWN0cyAubmFtZXtcbiAgICBmb250LXNpemU6IC44cmVtO1xuICAgIG1hcmdpbi1ib3R0b206NXB4O1xuICAgIG1hcmdpbi10b3A6IDA7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGRcbn1cbi5wcm9kdWN0cyAucm93T25le1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjYzJjMmMyO1xufVxuLmNvbE9uZXtcbiAgICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjYzJjMmMyO1xufVxuLm1lbnVJdGVte1xuICAgIHBhZGRpbmc6IDMwcHggMDtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2MyYzJjMjtcblxufVxuLm1lbnVJdGVtIHB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGZvbnQtc2l6ZTogLjVyZW07XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc2l6ZTogM3Z3O1xuXG59XG4ubWVudUl0ZW0gaW1nIHtcbiAgICBoZWlnaHQ6IDE1MHB4O1xufVxuLnByaWNlX25hbWV7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgZm9udC1zaXplOiAxMHB4O1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgZm9udC1zaXplOiAzdndcbn1cbi5teU9yZGVye1xuICAgIGJhY2tncm91bmQ6ICNFMUUxRTE7XG4gICAgcGFkZGluZyA6NXB4IDEwcHhcbn1cbi5teU9yZGVyIGg0IHtcbiAgICBtYXJnaW46IDA7XG4gICAgZm9udC1zaXplOiA1dnc7XG4gICAgY29sb3I6IGJsYWNrXG59XG5cbi5jb25maXJtT3JDYW5jZWx7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbn1cbi5jb25maXJtT3JDYW5jZWwgaW9uLWJ1dHRvbntcbiAgICB3aWR0aDogMzMlO1xufVxuLmZvdGVyIHAge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDV2dztcbn1cblxuLmZvb3RlciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJvdHRvbTogMSVcblxufVxuLnJlY21vZW5kZWQgcHtcbiAgICBtYXJnaW46IDA7XG4gICAgZm9udC1zaXplOiA1dnc7XG5cbn1cblxuLm1lbnV7XG4gICAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICBtYXJnaW4tdG9wOiAtMTclO1xuICAgIGJhY2tncm91bmQ6ICNmMGYwZjA7XG4gICAgaGVpZ2h0OiA3MnZoO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5tZW51IGRpdiB7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGdyYXk7XG59XG4ubWVudSAubWFpbk1lbnV7XG4gICAgZm9udC1zaXplOiAzcmVtO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIG1hcmdpbi10b3A6IDUwJTtcbn1cbi5wcm9kdWN0c3tcbiAgICBoZWlnaHQ6IDUydmg7XG4gICAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuLnByb2R1Y3RzIGltZyB7XG4gICAgaGVpZ2h0OiAxNTBweDtcbn1cblxuLmlmQ2xpY2t7XG4gICAgaGVpZ2h0OjE5dmggIWltcG9ydGFudDtcbn1cblxuLnJlY21vZW5kZWQgaW9uLWJ1dHRvbntcbiAgIC0tYmFja2dyb3VuZDogI0UxRTFFMTtcbiAgIGZvbnQtc2l6ZTogNXZ3O1xuICAgaGVpZ2h0OiBhdXRvOztcbiAgIFxufVxuLk1vZGZpcmVze1xuIGRpc3BsYXk6IGZsZXg7XG4ganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuXG59XG5cbi5Nb2RmaXJlcyBoMSB7XG4gICAgbWFyZ2luLXRvcDogOHB4O1xuICAgIHBhZGRpbmctbGVmdDogNXB4O1xuICAgIGZvbnQtc2l6ZTogN3Z3O1xufVxuLmNvbmZpcm1PckNhbmNlbCBpb24tYnV0dG9ue1xuICAgIGZvbnQtc2l6ZTogNHZ3O1xuICAgIGhlaWdodDogMTEycHg7XG59XG4ubmV4dCB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJvdHRvbTogMjQlO1xuICAgIGhlaWdodDogMTAwcHggIWltcG9ydGFudDtcbiAgICBsZWZ0OiAxNHB4O1xuICAgIC0tYmFja2dyb3VuZDogcmdiKDI1MiwgMTgwLCAwKSFpbXBvcnRhbnQ7XG4gICAgY29sb3I6ICMwMDBcbn1cbi8vIC5uZXh0TW9kZmlyZSB7XG4vLyAgICAgaGVpZ2h0OiAxMDBweDtcbi8vIH1cbi8vIC5uZXh0TW9kZmlyZSBpb24tYnV0dG9ue1xuLy8gICAgIC0tYmFja2dyb3VuZDogI2MyYzJjMjtcbi8vICAgICBoZWlnaHQ6IDEwMCU7XG4vLyB9XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDo3NjhweCl7XG4gICAgLmltZ1Byb2R1Y3R7XG4gICAgICAgIGhlaWdodDogNzFweDtcbiAgICB9XG4gICAgLm1lbnUge1xuICAgICAgICBoZWlnaHQ6IDY3dmg7XG4gICAgICAgIG1hcmdpbi10b3A6IC0xOSU7XG4gICAgfVxuICAgIC5tZW51SXRlbXtcbiAgICAgICAgcGFkZGluZzogMTJweCAwO1xuICAgIH1cbiAgICAubWVudUl0ZW0gaW1nIHtcbiAgICAgICAgaGVpZ2h0OiA1MHB4O1xuICAgICAgICB3aWR0aDogYXV0b1xuICAgIH1cbiAgICAuYmFjayBpb24tYnV0dG9ue1xuICAgICAgICBoZWlnaHQ6IDM2cHg7XG4gICAgfVxuICAgIC5tZW51IC5tYWluTWVudXtcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgIH1cbiAgICAucHJvZHVjdHMgaW1ne1xuICAgICAgICB3aWR0aDogYXV0bztcbiAgICAgICAgaGVpZ2h0OiA5MHB4O1xuICAgICAgICBcbiAgICB9XG4gICAgLmNvbmZpcm1PckNhbmNlbCBpb24tYnV0dG9ue1xuICAgICAgaGVpZ2h0OiA0NHB4O1xuICAgIH1cbiAgICAuaWZDbGlja3tcbiAgICAgICAgaGVpZ2h0OjEwdmggIWltcG9ydGFudDtcbiAgICB9XG4gICAgLmNvdmVyMntcbiAgICAgICAgaGVpZ2h0OjIzdmg7XG4gICAgfVxuICAgIC5uZXh0IHtcbiAgICAgICAgaGVpZ2h0OiAzNnB4ICFpbXBvcnRhbnQ7XG4gICAgfVxuICAgIC5iYWNrIGlvbi1idXR0b24gLCAuYmFja0lmUmlnaHQgaW9uLWJ1dHRvbntcbiAgICAgICAgaGVpZ2h0OiA0MXB4O1xuICAgICAgfVxuICAgICAgLm5leHQgIHtcbiAgICAgICAgYm90dG9tOiAyNSU7XG4gICAgICAgIGxlZnQ6IDVweDtcbiAgICB9XG4gIH0iXX0= */";

/***/ }),

/***/ 1395:
/*!****************************************************************!*\
  !*** ./src/app/pages/categoris/categoris.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <div>\n    <img class=\"imgProduct\" src=\"assets/images/panner.jpeg\">\n  </div>\n  <div class=\"cover\">\n    <h1>{{nameOfCat}}</h1>\n  </div>\n</ion-header> -->\n<div class=\"header\">\n    <img class=\"imgProduct \" src=\"assets/images/bingo.png\">\n  </div>\n\n<ion-content [dir]=\"dir\">\n  <div class=\"\">\n      <div class=\"back\"  [ngClass]=\"{'back':dir == 'ltr', 'backIfRight':dir == 'rtl'}\">\n          <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n        </div>\n    <ion-grid style=\"padding: 0\">\n      <ion-row>\n        <ion-col class=\"menu\" [ngClass]=\"{'ifClick':showModfire}\" size=\"3\">\n            <p class=\"mainMenu\"> {{Menu}} </p>\n            <!-- <div  class=\"menuItem\">\n              <img src=\"assets/images/mostSelling.png\">\n              <p>{{bestSelling}}</p>\n            </div> -->\n            <div class=\"menuItem\" (click)=\"gotToDetails('Discount')\">\n              <img src=\"assets/images/discount.png\">\n              <p>{{discount}}</p>\n            </div>\n            <div  class=\"menuItem\" routerLink=\"/promtions\">\n              <img src=\"assets/images/promotion.png\">\n              <p>{{promotions}}</p>\n            </div>\n          <div>\n            <div *ngFor=\"let item of categoris\" class=\"menuItem\" (click)=\"ChoseCategori(item)\">\n              <img src=\"{{item.Image}}\">\n              <p>{{item.Name}}</p>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col>\n          <div class=\"products\" [ngClass]=\"{'ifClick':showModfire}\">\n            <ion-grid>\n              <ion-row>\n                <!--  [ngClass]=\"{'colOne':item.status == false}\" -->\n                <ion-col size=\"6\" class=\"rowOne colOne\" (click)=\"GetModifiresbyProductId(item,item.Id)\"\n                  *ngFor=\"let item of items ; let i = index\">\n\n                  <div class=\"price_name\" *ngIf=\"langId == 1\">\n                    <span style=\"color: red\" *ngIf=\"item.NewPrice != 0\"><s>{{item.Price | number : '1.2-2'}} {{LE}}</s></span>\n                    <span *ngIf=\"item.NewPrice == 0\">{{item.Price | number : '1.2-2'}} {{LE}}</span>\n                    <span *ngIf=\"item.NewPrice != 0\">{{item.NewPrice | number : '1.2-2'}} {{LE}}</span>\n                  </div>\n                  <div class=\"price_name\" *ngIf=\"langId != 1\"> \n                    <span style=\"color: red\" *ngIf=\"item.NewPrice != 0\"><s>{{LE}} {{item.Price | number : '1.2-2'}}</s></span>\n                    <span *ngIf=\"item.NewPrice == 0\">{{LE}} {{item.Price | number : '1.2-2'}}</span>\n                    <span *ngIf=\"item.NewPrice != 0\">{{LE}} {{item.NewPrice | number : '1.2-2'}}</span>\n                  </div>\n                  <img src=\"{{item.Image}}\">\n                  <p class=\"price_name\">{{item.Name}}</p>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <div [ngClass]=\"{'cover2':showModfire}\"></div>\n  </div>\n  \n\n  <section class=\"recmoended\" *ngIf=\"showModfire\">\n    <div class=\"Modfires\">\n      <h1>{{Modfires}}</h1>\n      <ion-button (click)=\"close()\">{{Back}}</ion-button>\n    </div>\n\n    <ion-grid>\n      <ion-row>\n        <ion-col (click)=\"gotToDetails(item)\" *ngFor=\"let item of ModifiresbyProductId ; let i = index\" size=\"3\">\n          <p class=\"price\">LE {{item.Price}}</p>\n          <img src=\"{{item.Image}}\">\n          <p class=\"name\">{{item.Name}}</p>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <ion-button class=\"next\" (click)=\"gotToDetails('normal')\">{{Next}}</ion-button>\n  </section>\n\n  <section class=\"footer\">\n    <div class=\"myOrder\">\n      <h4>{{MyOrder}}</h4>\n    </div>\n    <div class=\"foter\">\n      <p>{{arrOfModLength}}</p>\n      <div class=\"confirmOrCancel\" dir=\"ltr\">\n          <ion-button [disabled]=\"arrOfModLength\" (click)=\"cancelOrder()\">{{Cancel}}</ion-button>\n        <ion-button [disabled]=\"arrOfModLength\" (click)=\"Done()\">{{OrderDone}}</ion-button>\n      </div>\n    </div>\n  </section>\n\n\n\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_categoris_categoris_module_ts.js.map