"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_home_home_module_ts"],{

/***/ 2003:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 2267);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], HomePageRoutingModule);



/***/ }),

/***/ 3467:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 2267);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-routing.module */ 2003);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomePageRoutingModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 2267:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page.html?ngResource */ 3853);
/* harmony import */ var _home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss?ngResource */ 1020);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../rest.service */ 1881);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);







let HomePage = class HomePage {
    constructor(rest, route, navCtr) {
        this.rest = rest;
        this.route = route;
        this.navCtr = navCtr;
        this.lang = '2';
    }
    ngOnInit() {
        if (!localStorage.getItem('lang')) {
            localStorage.setItem("lang", this.lang);
            this.ifLang('2');
        }
        else {
            this.lang = localStorage.getItem('lang');
            this.ifLang(this.lang);
        }
    }
    gotToShop() {
        this.route.navigateByUrl('/main_menu');
    }
    changeLang(lang) {
        this.lang = lang;
        localStorage.setItem("lang", this.lang);
        this.ifLang(this.lang);
    }
    ifLang(langId) {
        if (langId == '2') {
            this.title = "What will you choose today";
            this.takeOut = "Take Out";
            this.inShop = "In Shop";
        }
        else {
            this.title = "ماذا ستختار اليوم";
            this.takeOut = "في الخارج";
            this.inShop = "في المتجر";
        }
    }
};
HomePage.ctorParameters = () => [
    { type: _rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController }
];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-home',
        template: _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 1020:
/*!************************************************!*\
  !*** ./src/app/home/home.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background:#010100;\n}\n\nion-button {\n  --color: black;\n  text-transform: none;\n}\n\n.back {\n  text-align: right;\n  text-transform: none;\n}\n\n.logo {\n  display: flex;\n  justify-content: center;\n  margin-top: 13%;\n}\n\n.logo .logoImage {\n  width: 50%;\n  border-radius: 10px;\n}\n\n.title {\n  text-align: center;\n}\n\n.title h1 {\n  font-size: 5vw;\n  color: #fff;\n  margin-top: 0;\n}\n\n.ion_col {\n  margin-right: 15px;\n}\n\n.product {\n  border: 25px solid #fff;\n  flex-direction: column;\n  display: flex;\n  justify-content: space-between;\n  height: 30vh;\n  border-radius: 5px;\n}\n\n.product .imgProduct {\n  margin: 30px auto 0 auto;\n  margin-top: 25%;\n  width: 54%;\n  height: 45% !important;\n}\n\n.product .button {\n  --background: #fcef50;\n  text-transform: none;\n  font-size: 5vw;\n  height: 19%;\n  --border-radius:5px ;\n}\n\n.product .button .button-native {\n  padding: 20px;\n}\n\n.footer {\n  margin-top: 10%;\n  justify-content: space-evenly;\n  display: flex;\n}\n\n.footer .button {\n  width: 34%;\n  font-size: 5vw;\n  border-radius: 5px;\n  background: #fff;\n  color: #3c3c3b;\n  height: 100%;\n  height: 115px;\n  padding-top: 20px;\n}\n\n.footer .lang {\n  font-weight: bold;\n}\n\n.changeLang {\n  background: #fcef50 !important;\n}\n\n.languish {\n  display: flex;\n  justify-content: space-evenly;\n  height: 100%;\n}\n\n.languish p {\n  margin: 0;\n}\n\n.changeLangEnglis {\n  margin-left: 2%;\n}\n\n@media only screen and (max-width: 768px) {\n  .product {\n    height: 29vh;\n    border: 10px solid #fff;\n  }\n\n  .changeLangEnglis {\n    margin-left: 5%;\n  }\n\n  .footer .button {\n    font-size: 4vw;\n    height: 44px;\n    padding-top: 4%;\n  }\n\n  .english {\n    margin-top: 16%;\n  }\n\n  .arabic {\n    margin-top: 14%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usb0JBQUE7QUFDRjs7QUFDQTtFQUNFLGNBQUE7RUFDQSxvQkFBQTtBQUVGOztBQUFBO0VBQ0UsaUJBQUE7RUFDQSxvQkFBQTtBQUdGOztBQUFBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtBQUdGOztBQURBO0VBQ0csVUFBQTtFQUNELG1CQUFBO0FBSUY7O0FBREE7RUFDRSxrQkFBQTtBQUlGOztBQUZBO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0FBS0Y7O0FBRkE7RUFDRSxrQkFBQTtBQUtGOztBQUhBO0VBQ0UsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFlBQUE7RUFFQSxrQkFBQTtBQUtGOztBQUhBO0VBQ0Usd0JBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtFQUNBLHNCQUFBO0FBTUY7O0FBSkE7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtBQU9GOztBQUxBO0VBQ0UsYUFBQTtBQVFGOztBQUxBO0VBQ0ssZUFBQTtFQUNBLDZCQUFBO0VBQ0EsYUFBQTtBQVFMOztBQU5BO0VBQ0UsVUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7QUFTRjs7QUFOQTtFQUVFLGlCQUFBO0FBUUY7O0FBTEE7RUFDRSw4QkFBQTtBQVFGOztBQUxBO0VBQ0UsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsWUFBQTtBQVFGOztBQU5BO0VBQ0UsU0FBQTtBQVNGOztBQVBBO0VBQ0UsZUFBQTtBQVVGOztBQVJBO0VBQ0U7SUFDRSxZQUFBO0lBQ0EsdUJBQUE7RUFXRjs7RUFUQTtJQUNFLGVBQUE7RUFZRjs7RUFWQTtJQUNFLGNBQUE7SUFDQSxZQUFBO0lBQ0EsZUFBQTtFQWFGOztFQVhBO0lBQ0UsZUFBQTtFQWNGOztFQVpBO0lBQ0UsZUFBQTtFQWVGO0FBQ0YiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcbiAgLS1iYWNrZ3JvdW5kOiMwMTAxMDA7XG59XG5pb24tYnV0dG9uIHtcbiAgLS1jb2xvcjogYmxhY2s7IFxuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbn1cbi5iYWNrIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lXG59XG5cbi5sb2dve1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogMTMlO1xufVxuLmxvZ28gLmxvZ29JbWFnZSB7XG4gICB3aWR0aDogNTAlO1xuICBib3JkZXItcmFkaXVzOiAxMHB4XG59XG5cbi50aXRsZXtcbiAgdGV4dC1hbGlnbjogY2VudGVyXG59XG4udGl0bGUgaDEge1xuICBmb250LXNpemU6IDV2dztcbiAgY29sb3I6ICNmZmY7XG4gIG1hcmdpbi10b3A6IDBcbn1cblxuLmlvbl9jb2x7XG4gIG1hcmdpbi1yaWdodDogMTVweFxufVxuLnByb2R1Y3R7XG4gIGJvcmRlcjoyNXB4IHNvbGlkICNmZmY7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgaGVpZ2h0OjMwdmg7XG4gLy8gYmFja2dyb3VuZDogYmxhY2s7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbn1cbi5wcm9kdWN0IC5pbWdQcm9kdWN0e1xuICBtYXJnaW46IDMwcHggYXV0byAwIGF1dG87XG4gIG1hcmdpbi10b3A6IDI1JTtcbiAgd2lkdGg6IDU0JTtcbiAgaGVpZ2h0OiA0NSUgIWltcG9ydGFudDtcbn1cbi5wcm9kdWN0IC5idXR0b257XG4gIC0tYmFja2dyb3VuZDogI2ZjZWY1MDsgXG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICBmb250LXNpemU6IDV2dztcbiAgaGVpZ2h0OiAxOSU7XG4gIC0tYm9yZGVyLXJhZGl1czo1cHhcbn1cbi5wcm9kdWN0IC5idXR0b24gLmJ1dHRvbi1uYXRpdmV7XG4gIHBhZGRpbmc6IDIwcHhcbn1cblxuLmZvb3RlcntcbiAgICAgbWFyZ2luLXRvcDogMTAlO1xuICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcbiAgICAgZGlzcGxheTogZmxleDtcbn1cbi5mb290ZXIgLmJ1dHRvbntcbiAgd2lkdGg6IDM0JTtcbiAgZm9udC1zaXplOiA1dnc7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgY29sb3I6IHJnYig2MCwgNjAsIDU5KTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBoZWlnaHQ6IDExNXB4O1xuICBwYWRkaW5nLXRvcDogMjBweFxuXG59XG4uZm9vdGVyIC5sYW5ne1xuICAvLyBiYWNrZ3JvdW5kOiAjY2NjY2NjO1xuICBmb250LXdlaWdodDogYm9sZFxufVxuXG4uY2hhbmdlTGFuZ3tcbiAgYmFja2dyb3VuZDogI2ZjZWY1MCAhaW1wb3J0YW50O1xufVxuXG4ubGFuZ3Vpc2h7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICBoZWlnaHQ6IDEwMCU7XG59XG4ubGFuZ3Vpc2ggcCB7XG4gIG1hcmdpbjogMFxufVxuLmNoYW5nZUxhbmdFbmdsaXN7XG4gIG1hcmdpbi1sZWZ0OiAyJVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjc2OHB4KXtcbiAgLnByb2R1Y3R7XG4gICAgaGVpZ2h0OiAyOXZoO1xuICAgIGJvcmRlcjogMTBweCBzb2xpZCAjZmZmO1xuICB9XG4gIC5jaGFuZ2VMYW5nRW5nbGlze1xuICAgIG1hcmdpbi1sZWZ0OiA1JTtcbiAgfVxuICAuZm9vdGVyIC5idXR0b257IFxuICAgIGZvbnQtc2l6ZTogNHZ3O1xuICAgIGhlaWdodDogNDRweDtcbiAgICBwYWRkaW5nLXRvcDogNCU7XG4gIH1cbiAgLmVuZ2xpc2h7XG4gICAgbWFyZ2luLXRvcDogMTYlO1xuICB9XG4gIC5hcmFiaWMge1xuICAgIG1hcmdpbi10b3A6IDE0JTtcbiAgfVxufSJdfQ== */";

/***/ }),

/***/ 3853:
/*!************************************************!*\
  !*** ./src/app/home/home.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header [translucent]=\"true\">\n  <div class=\"back\">\n      <ion-button>Back</ion-button>\n  </div>\n</ion-header> -->\n\n<ion-content [fullscreen]=\"true\">\n  <div class=\"logo\">\n    <ion-img class=\"logoImage\" src=\"assets/images/bingo.png\"></ion-img>\n  </div>\n  <div class=\"title\">\n    <h1>{{title}}</h1>\n  </div>\n\n  <div style=\"margin-top: 5%;\">\n    <ion-grid>\n      <ion-row>\n        <ion-col offset=\"1\" class=\"ion_col\" size=\"5\" (click)=\"gotToShop()\">\n          <div class=\"product\">\n            <img class=\"imgProduct\"  src=\"assets/images/coffeeInShop.png\">\n            <ion-button class=\"button\">{{inShop}}</ion-button>\n          </div>\n        </ion-col>\n        <ion-col size=\"5\" (click)=\"gotToShop()\">\n            <div class=\"product\">\n              <img class=\"imgProduct\"src=\"assets/images/takeOut.png\">\n              <ion-button class=\"button\">{{takeOut}}</ion-button>\n            </div>\n          </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n  <div class=\"footer\">\n      <div (click)=\"changeLang('2')\"  class=\"button changeLangEnglis\"  [ngClass]=\"{'changeLang' : lang == '2'}\">\n        <div class=\"languish\">\n            <p class=\"lang\">EN</p>\n            <p class=\"english\">English</p> \n        </div>\n      </div>\n      <div (click)=\"changeLang('1')\"  class=\"button\" [ngClass]=\"{'changeLang' : lang == '1'}\">\n        <div class=\"languish\">\n            <p class=\"lang\">AR</p>\n            <p style=\"margin-top: -1%\" class=\"arabic\">عربي</p>\n        </div>\n      </div>\n  </div>\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map