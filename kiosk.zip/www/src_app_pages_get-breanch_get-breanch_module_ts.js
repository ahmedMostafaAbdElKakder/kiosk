"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_get-breanch_get-breanch_module_ts"],{

/***/ 5961:
/*!*****************************************************************!*\
  !*** ./src/app/pages/get-breanch/get-breanch-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetBreanchPageRoutingModule": () => (/* binding */ GetBreanchPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _get_breanch_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./get-breanch.page */ 1950);




const routes = [
    {
        path: '',
        component: _get_breanch_page__WEBPACK_IMPORTED_MODULE_0__.GetBreanchPage
    }
];
let GetBreanchPageRoutingModule = class GetBreanchPageRoutingModule {
};
GetBreanchPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], GetBreanchPageRoutingModule);



/***/ }),

/***/ 4311:
/*!*********************************************************!*\
  !*** ./src/app/pages/get-breanch/get-breanch.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetBreanchPageModule": () => (/* binding */ GetBreanchPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _get_breanch_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./get-breanch-routing.module */ 5961);
/* harmony import */ var _get_breanch_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./get-breanch.page */ 1950);







let GetBreanchPageModule = class GetBreanchPageModule {
};
GetBreanchPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _get_breanch_routing_module__WEBPACK_IMPORTED_MODULE_0__.GetBreanchPageRoutingModule
        ],
        declarations: [_get_breanch_page__WEBPACK_IMPORTED_MODULE_1__.GetBreanchPage]
    })
], GetBreanchPageModule);



/***/ }),

/***/ 1950:
/*!*******************************************************!*\
  !*** ./src/app/pages/get-breanch/get-breanch.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetBreanchPage": () => (/* binding */ GetBreanchPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _get_breanch_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./get-breanch.page.html?ngResource */ 6388);
/* harmony import */ var _get_breanch_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./get-breanch.page.scss?ngResource */ 7326);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);






let GetBreanchPage = class GetBreanchPage {
    constructor(rest, route) {
        this.rest = rest;
        this.route = route;
        this.showContent = true;
        this.showSkip = false;
        this.erorrMasg = "Check Your Email";
        this.expression = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
        this.showErorrMasg = false;
    }
    ngOnInit() {
        this.idOfBranch = localStorage.getItem('idOfBranch');
        if (this.idOfBranch) {
            this.showSkip = true;
        }
        else {
            this.showSkip = false;
        }
    }
    getEmail(e) {
        this.Email = e.target.value;
        this.result = this.expression.test(this.Email);
    }
    getData() {
        this.subscription = this.rest.getStatusOfbranch().subscribe(res => {
            if (res == "5") {
                this.erorrMasg = "license expired";
            }
            else {
                this.erorrMasg = "account rejected";
            }
        });
        if (this.result == true) {
            this.showErorrMasg = false;
            this.rest.getClientBranch(this.Email).subscribe((res) => {
                console.log(res);
                if (res != null) {
                    if (res.StatusId == 3) {
                        this.showErorrMasg = false;
                        if (res.ClientBranches.Branches.length != 0) {
                            localStorage.setItem('arrayOfBranch', JSON.stringify(res.ClientBranches.Branches));
                            this.route.navigateByUrl('/chose-branch');
                        }
                    }
                    else if (res.StatusId == 5) {
                        this.showErorrMasg = true;
                        this.erorrMasg = "license expired";
                    }
                    else if (res.StatusId == 4) {
                        this.showErorrMasg = true;
                        this.erorrMasg = "account rejected";
                    }
                }
                else {
                    this.showErorrMasg = true;
                    this.erorrMasg = "Check Your Email";
                }
            });
        }
        else {
            this.showErorrMasg = true;
            this.erorrMasg = "Check Your Email";
        }
    }
};
GetBreanchPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
GetBreanchPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-get-breanch',
        template: _get_breanch_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_get_breanch_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], GetBreanchPage);



/***/ }),

/***/ 7326:
/*!********************************************************************!*\
  !*** ./src/app/pages/get-breanch/get-breanch.page.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background:#010100;\n  text-align: center;\n}\n\n.container {\n  margin: 0 5%;\n}\n\nion-img {\n  margin-top: 20%;\n}\n\nion-item {\n  --background: #fff;\n  color: #000;\n  font-size: 3rem;\n  margin-bottom: 14px;\n  border-radius: 6px;\n}\n\nion-button {\n  font-size: 3rem;\n  height: 100px;\n  width: 76%;\n  --background: #fcef50;\n  color: #000000;\n  margin-top: 5%;\n}\n\n@media only screen and (max-width: 768px) {\n  .container {\n    margin: 0 20;\n  }\n\n  ion-item {\n    --background: #fff;\n    color: #000;\n    font-size: 1rem;\n    margin-bottom: 14px;\n    border-radius: 6px;\n  }\n\n  ion-button {\n    font-size: 1rem;\n    height: 50px;\n    width: 60%;\n    --background: #fcef50;\n    color: #000000;\n    margin-top: 1%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdldC1icmVhbmNoLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG9CQUFBO0VBQ0Esa0JBQUE7QUFDSjs7QUFDRTtFQUNFLFlBQUE7QUFFSjs7QUFBQTtFQUNJLGVBQUE7QUFHSjs7QUFEQTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBSUo7O0FBRkE7RUFDSSxlQUFBO0VBQ0EsYUFBQTtFQUNBLFVBQUE7RUFDQSxxQkFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0FBS0o7O0FBRkE7RUFDSTtJQUNJLFlBQUE7RUFLTjs7RUFIRTtJQUNJLGtCQUFBO0lBQ0EsV0FBQTtJQUNBLGVBQUE7SUFDQSxtQkFBQTtJQUNBLGtCQUFBO0VBTU47O0VBSkU7SUFDSSxlQUFBO0lBQ0EsWUFBQTtJQUNBLFVBQUE7SUFDQSxxQkFBQTtJQUNBLGNBQUE7SUFDQSxjQUFBO0VBT047QUFDRiIsImZpbGUiOiJnZXQtYnJlYW5jaC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcbiAgICAtLWJhY2tncm91bmQ6IzAxMDEwMDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbiAgLmNvbnRhaW5lcntcbiAgICBtYXJnaW46IDAgNSU7XG59XG5pb24taW1ne1xuICAgIG1hcmdpbi10b3A6IDIwJTtcbn1cbmlvbi1pdGVte1xuICAgIC0tYmFja2dyb3VuZDogI2ZmZjtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmb250LXNpemU6IDNyZW07XG4gICAgbWFyZ2luLWJvdHRvbTogMTRweDtcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XG59XG5pb24tYnV0dG9ue1xuICAgIGZvbnQtc2l6ZTogM3JlbTtcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICAgIHdpZHRoOiA3NiU7XG4gICAgLS1iYWNrZ3JvdW5kOiAjZmNlZjUwO1xuICAgIGNvbG9yOiMwMDAwMDA7XG4gICAgbWFyZ2luLXRvcDogNSU7XG59XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDo3NjhweCl7XG4gICAgLmNvbnRhaW5lcntcbiAgICAgICAgbWFyZ2luOiAwIDIwO1xuICAgIH1cbiAgICBpb24taXRlbXtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xuICAgICAgICBjb2xvcjogIzAwMDtcbiAgICAgICAgZm9udC1zaXplOiAxcmVtO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAxNHB4O1xuICAgICAgICBib3JkZXItcmFkaXVzOiA2cHg7XG4gICAgfVxuICAgIGlvbi1idXR0b257XG4gICAgICAgIGZvbnQtc2l6ZTogMXJlbTtcbiAgICAgICAgaGVpZ2h0OiA1MHB4O1xuICAgICAgICB3aWR0aDo2MCU7XG4gICAgICAgIC0tYmFja2dyb3VuZDogI2ZjZWY1MDtcbiAgICAgICAgY29sb3I6IzAwMDAwMDtcbiAgICAgICAgbWFyZ2luLXRvcDogMSU7XG4gICAgfVxufSJdfQ== */";

/***/ }),

/***/ 6388:
/*!********************************************************************!*\
  !*** ./src/app/pages/get-breanch/get-breanch.page.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <ion-img class=\"logoImage\" src=\"assets/images/bingo.png\"></ion-img>\n\n  <div class=\"container\">\n\n    <form>\n      <ion-item>\n        <ion-label position=\"stacked\">Your Email</ion-label>\n        <ion-input type=\"email\" (input)=\"getEmail($event)\"\n         placeholder=\"Enter Your Email\"></ion-input>\n      </ion-item>\n      <p *ngIf=\"showErorrMasg\" style=\"    font-size: 14px;\n      margin: 0 0 5px 10px;\n      text-align: left;\n      color: red;\">{{erorrMasg}}</p>\n      <ion-button class=\"btn\" (click)=\"getData()\">Login</ion-button><br>\n      <ion-button class=\"btn\" *ngIf=\"showSkip\" routerLink=\"/order-here\">Skip</ion-button>\n    </form>\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_get-breanch_get-breanch_module_ts.js.map