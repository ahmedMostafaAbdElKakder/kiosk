"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_review_review_module_ts"],{

/***/ 5799:
/*!*******************************************************!*\
  !*** ./src/app/pages/review/review-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewPageRoutingModule": () => (/* binding */ ReviewPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _review_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./review.page */ 4784);




const routes = [
    {
        path: '',
        component: _review_page__WEBPACK_IMPORTED_MODULE_0__.ReviewPage
    }
];
let ReviewPageRoutingModule = class ReviewPageRoutingModule {
};
ReviewPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ReviewPageRoutingModule);



/***/ }),

/***/ 1559:
/*!***********************************************!*\
  !*** ./src/app/pages/review/review.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewPageModule": () => (/* binding */ ReviewPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _review_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./review-routing.module */ 5799);
/* harmony import */ var _review_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./review.page */ 4784);







let ReviewPageModule = class ReviewPageModule {
};
ReviewPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _review_routing_module__WEBPACK_IMPORTED_MODULE_0__.ReviewPageRoutingModule
        ],
        declarations: [_review_page__WEBPACK_IMPORTED_MODULE_1__.ReviewPage]
    })
], ReviewPageModule);



/***/ }),

/***/ 4784:
/*!*********************************************!*\
  !*** ./src/app/pages/review/review.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewPage": () => (/* binding */ ReviewPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _review_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./review.page.html?ngResource */ 249);
/* harmony import */ var _review_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./review.page.scss?ngResource */ 2057);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);







let ReviewPage = class ReviewPage {
    constructor(navCtr, loadingCtrl, route, rest) {
        this.navCtr = navCtr;
        this.loadingCtrl = loadingCtrl;
        this.route = route;
        this.rest = rest;
        this.priceOfProdct = 0;
        this.count = 1;
        this.souceCount = 0;
        this.soucePrice = 0;
        this.modfirePrice = 0;
        this.totalPrice = 0;
        this.showOrHideMod = false;
        this.listOfPromtion = [];
        this.arrOfPromo1 = [];
        this.VatValue = 0;
        this.block = true;
        this.totalPriceAfterSerial = 0;
        this.oldtotlaBeforDiscount = 0;
        this.service = 0;
        this.shwoProced = true;
        // serial number
        this.serialNumber = '';
        this.giftCardCount = 0;
        this.showIsValid = false;
        this.showStatusValid = false;
        this.showStatusValidFalse = false;
        this.serialNumberIsUsed = '';
        this.status = false;
    }
    ngOnInit() {
        this.langId = localStorage.getItem("lang");
        if (this.langId == '1') {
            this.Discount = "خصم";
            this.placeHolder = "رقم كارت الهدايا";
            this.Suggestions = "الاقتراحات";
            this.Back = "رجوع";
            this.Cancel = "إلغاء";
            this.CheckOut = "استكمال عملية الدفع";
            this.Total = "الأجمالي";
            this.reviewMyOrder = "مراجعة طلبي";
            this.Edit = "تعديل";
            this.Remove = "إلغاء";
            this.dir = "rtl";
            this.LE = "جنيه";
            this.serialVaild = "تحقق من الرمز";
            this.upto = "بحد اقصي";
            this.Vat = "ضريبة القيمة المضافه";
            this.serviceName = "خدمة";
        }
        else {
            this.placeHolder = "gift card number";
            this.Suggestions = 'Suggestions';
            this.Back = "Back";
            this.Cancel = "Cancel";
            this.CheckOut = "Proceed to check out";
            this.Total = "Total";
            this.reviewMyOrder = "Review my order";
            this.Edit = "Edit";
            this.Remove = "Remove";
            this.dir = "ltr";
            this.serialVaild = "valid Serial";
            this.LE = "LE";
            this.upto = "up to";
            this.Discount = 'Discount';
            this.Vat = 'Vat';
            this.serviceName = "Services";
        }
        this.getPromtionsList();
        this.getVat();
    }
    getVat() {
        this.rest.getVat().subscribe((res) => {
            console.log("vat", res);
            if (res.BranchDetails.TaxGroup == "0%") {
                this.TaxGroup = 0;
            }
            else {
                this.TaxGroup = res.BranchDetails.TaxGroup;
                this.TaxGroup = this.TaxGroup.slice(0, 2);
                this.TaxGroup = +this.TaxGroup;
            }
            console.log(this.TaxGroup);
        });
    }
    getPromtionsList() {
        this.item = JSON.parse(sessionStorage.getItem('arrOfModfire'));
        this.rest.allPromtion(this.langId).subscribe((res) => {
            this.listOfPromtion = res;
            console.log("in promo", res);
            for (let i = 0; i < this.item.length; i++) {
                for (let j = 0; j < this.listOfPromtion.length; j++) {
                    for (let q = 0; q < this.listOfPromtion[j].Products.length; q++) {
                        if (this.item[i].Prdoucts[0].Id == this.listOfPromtion[j].Products[q].Id) {
                            this.item[i].MaxDiscountAmount = this.listOfPromtion[j].MaxDiscountAmount;
                            this.item[i].discount = this.listOfPromtion[j].DiscountAmount;
                            this.item[i].DiscountType = this.listOfPromtion[j].DiscountType;
                        }
                    }
                }
            }
            this.rest.gitDiscount(this.langId).subscribe((res) => {
                console.log("in discount", res);
                for (let i = 0; i < this.item.length; i++) {
                    for (let j = 0; j < res.length; j++) {
                        if (this.item[i].Prdoucts[0].Id == res[j].Id) {
                            this.item[i].discount = res[j].DiscountAmount;
                            this.item[i].MaxDiscountAmount = res[j].MaxDiscountAmount;
                            this.item[i].DiscountType = res[j].DiscountType;
                        }
                    }
                }
                this.getData();
            });
        });
    }
    getData() {
        console.log("in data", this.item);
        let BeforeTax = localStorage.getItem('BeforeTax');
        let serviceTax = +localStorage.getItem('ServiceTax');
        this.serviceVat = serviceTax;
        console.log("serviceTax", serviceTax);
        for (let i = 0; i < this.item.length; i++) {
            this.soucePrice = 0;
            this.priceOfProdct = 0;
            this.modfirePrice = 0;
            if (this.item[i].ingridtArr.length != 0) {
                for (let j = 0; j < this.item[i].ingridtArr.length; j++) {
                    this.item[i].ingridtArr[j].oldCount = this.item[i].ingridtArr[j].count;
                    this.soucePrice = this.soucePrice + (this.item[i].ingridtArr[j].Price * this.item[i].ingridtArr[j].count);
                }
            }
            else {
                this.soucePrice = this.soucePrice + 0;
            }
            for (let q = 0; q < this.item[i].Prdoucts.length; q++) {
                this.priceOfProdct = this.priceOfProdct + (this.item[i].Prdoucts[q].Price * this.item[i].Prdoucts[q].count);
            }
            if (this.item[i].modfire.length != 0) {
                for (let j = 0; j < this.item[i].modfire.length; j++) {
                    this.item[i].modfire[j].oldCount = this.item[i].modfire[j].count;
                    this.modfirePrice = this.modfirePrice + (this.item[i].modfire[j].Price * this.item[i].modfire[j].count);
                }
            }
            else {
                this.modfirePrice = this.modfirePrice + 0;
            }
            this.oldtotlaBeforDiscount = this.oldtotlaBeforDiscount + this.soucePrice + this.modfirePrice + this.priceOfProdct;
            console.log("oldtotlaBeforDiscount", this.oldtotlaBeforDiscount);
            if (this.item[i].discount) {
                console.log("BeforeTax", BeforeTax);
                if (BeforeTax == 'false') {
                    if (this.item[i].DiscountType == 1) {
                        this.item[i].total = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                        this.item[i].oldTotal = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                        let valueOfDiscount = this.item[i].total * ((this.item[i].discount) / 100);
                        console.log("valueOfDiscount", valueOfDiscount);
                        if (valueOfDiscount > this.item[i].MaxDiscountAmount) {
                            this.discountvalueOfPrint = this.item[i].MaxDiscountAmount;
                            this.item[i].total = this.item[i].total - this.item[i].MaxDiscountAmount;
                        }
                        else {
                            this.discountvalueOfPrint = valueOfDiscount;
                            this.item[i].total = this.item[i].total * ((100 - this.item[i].discount) / 100);
                        }
                    }
                    else {
                        this.item[i].total = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                        this.item[i].oldTotal = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                        this.item[i].total = this.item[i].total - (this.item[i].discount * this.item[i].Prdoucts[0].count);
                        console.log("you are here", this.soucePrice, this.modfirePrice, this.priceOfProdct);
                    }
                }
                else {
                    // befortax
                    if (this.item[i].DiscountType == 1) {
                        this.item[i].total = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                        this.item[i].oldTotal = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                        // this.VatValue = this.item[i].total * (this.TaxGroup / 100)
                        // this.item[i].total = this.item[i].total + this.VatValue
                        let valueOfDiscount = this.item[i].total * ((this.item[i].discount) / 100);
                        console.log("valueOfDiscount", valueOfDiscount);
                        if (valueOfDiscount > this.item[i].MaxDiscountAmount) {
                            this.discountvalueOfPrint = this.item[i].MaxDiscountAmount;
                            this.item[i].total = this.item[i].total - this.item[i].MaxDiscountAmount;
                        }
                        else {
                            this.discountvalueOfPrint = valueOfDiscount;
                            this.item[i].total = this.item[i].total * ((100 - this.item[i].discount) / 100);
                        }
                    }
                    else {
                        this.item[i].total = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                        this.item[i].oldTotal = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                        this.VatValue = this.item[i].total * (this.TaxGroup / 100);
                        this.item[i].total = this.item[i].total;
                        this.item[i].total = this.item[i].total - (this.item[i].discount * this.item[i].Prdoucts[0].count);
                        console.log(this.soucePrice, this.modfirePrice, this.priceOfProdct);
                    }
                }
            }
            else {
                this.item[i].oldTotal = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                this.item[i].total = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                //  this.VatValue = this.item[i].total * (this.TaxGroup / 100)
                // this.item[i].total =this.item[i].total + this.VatValue
            }
            this.totalPrice = this.totalPrice + this.item[i].total;
        }
        if (BeforeTax == 'false') {
            setTimeout(() => {
                this.totalPriceAfterSerial = this.totalPrice;
                this.service = this.totalPrice * (serviceTax / 100);
                this.totalPrice = this.totalPrice + this.service;
                this.VatValue = this.totalPrice * (this.TaxGroup / 100);
                this.totalPrice = this.totalPrice + this.VatValue;
                console.log(this.totalPrice, this.VatValue);
                this.block = false;
            }, 2000);
        }
        else {
            setTimeout(() => {
                this.totalPriceAfterSerial = this.totalPrice;
                console.log(this.totalPriceAfterSerial);
                this.service = this.totalPrice * (serviceTax / 100);
                this.VatValue = (this.oldtotlaBeforDiscount + this.service) * (this.TaxGroup / 100);
                this.totalPrice = this.totalPrice + this.service + this.VatValue;
                console.log("BeforeTax == 'true'", this.totalPrice, this.VatValue);
                this.block = false;
            }, 2000);
        }
    }
    minus(item) {
        let BeforeTax = localStorage.getItem('BeforeTax');
        console.log(this.priceOfProdct);
        if (item.Prdoucts[0].count > 1) {
            this.totalPrice = 0;
            this.soucePrice = 0;
            this.modfirePrice = 0;
            this.priceOfProdct = 0;
            item.count = item.count - 1;
            if (item.modfire.length != 0) {
                for (let i = 0; i < item.modfire.length; i++) {
                    let count = item.modfire[i].count / item.Prdoucts[0].count;
                    item.modfire[i].count = item.modfire[i].count - count;
                    this.modfirePrice = this.modfirePrice + (item.modfire[i].Price * item.modfire[i].count);
                    console.log(this.modfirePrice);
                }
            }
            if (item.ingridtArr.length != 0) {
                for (let i = 0; i < item.ingridtArr.length; i++) {
                    let count = item.ingridtArr[i].count / item.Prdoucts[0].count;
                    item.ingridtArr[i].count = item.ingridtArr[i].count - count;
                    this.soucePrice = this.soucePrice + (item.ingridtArr[i].Price * item.ingridtArr[i].count);
                    console.log(this.soucePrice);
                }
            }
            for (let i = 0; i < item.Prdoucts.length; i++) {
                item.Prdoucts[i].count = item.Prdoucts[i].count - 1;
                this.priceOfProdct = this.priceOfProdct + (item.Prdoucts[i].Price * item.Prdoucts[i].count);
            }
            let totalPrice = this.soucePrice + this.modfirePrice + this.priceOfProdct;
            console.log(this.soucePrice, this.modfirePrice, this.priceOfProdct);
            item.oldTotal = totalPrice;
            console.log(totalPrice);
            this.oldtotlaBeforDiscount = totalPrice;
            if (BeforeTax == 'false') {
                if (item.discount) {
                    if (item.DiscountType == 1) {
                        console.log("discountType", item.DiscountType);
                        let value = totalPrice * (item.discount / 100);
                        if (value > item.MaxDiscountAmount) {
                            this.discountvalueOfPrint = item.MaxDiscountAmount;
                            item.total = totalPrice - item.MaxDiscountAmount;
                        }
                        else {
                            this.discountvalueOfPrint = value;
                            item.total = item.oldTotal * ((100 - item.discount) / 100);
                            console.log("item.total", item.total);
                        }
                    }
                    else {
                        console.log("discountType", item.DiscountType);
                        this.discountvalueOfPrint = item.discount;
                        item.total = totalPrice - (item.discount * item.Prdoucts[0].count);
                    }
                }
                else {
                    this.discountvalueOfPrint = 0;
                    item.total = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                }
                for (let i = 0; i < this.item.length; i++) {
                    this.totalPrice = this.totalPrice + this.item[i].total;
                }
                console.log("this.totalPrice", this.totalPrice);
                this.totalPriceAfterSerial = this.totalPrice;
                this.service = this.totalPrice * (this.serviceVat / 100);
                this.totalPrice = this.totalPrice + this.service;
                this.VatValue = this.totalPrice * (this.TaxGroup / 100);
                this.totalPrice = this.totalPrice + this.VatValue;
                console.log("this.totalPrice", this.totalPrice);
                this.totalPrice = this.totalPrice - this.giftCardCount;
                if (this.totalPrice < 0) {
                    this.totalPrice = 0;
                    this.VatValue = 0;
                    this.service = 0;
                }
            }
            else {
                if (item.discount) {
                    if (item.DiscountType == 1) {
                        // this.VatValue = totalPrice * (this.TaxGroup / 100)
                        // totalPrice = totalPrice + this.VatValue
                        let value = totalPrice * (item.discount / 100);
                        // let value = totalPrice * (item.discount / 100)
                        if (value > item.MaxDiscountAmount) {
                            this.discountvalueOfPrint = item.MaxDiscountAmount;
                            item.total = totalPrice - item.MaxDiscountAmount;
                        }
                        else {
                            this.discountvalueOfPrint = value;
                            item.total = totalPrice * ((100 - item.discount) / 100);
                        }
                    }
                    else {
                        this.discountvalueOfPrint = item.discount;
                        item.total = totalPrice - (item.discount * item.Prdoucts[0].count);
                    }
                }
                else {
                    this.discountvalueOfPrint = 0;
                    item.total = this.soucePrice + this.modfirePrice + this.priceOfProdct;
                }
                this.VatValue = 0;
                let oldPrice = 0;
                for (let i = 0; i < this.item.length; i++) {
                    oldPrice = oldPrice + this.item[i].oldTotal;
                    this.totalPrice = this.totalPrice + this.item[i].total;
                }
                // this.VatValue = this.totalPrice * (this.TaxGroup / 100)
                this.totalPriceAfterSerial = this.totalPrice;
                this.service = this.totalPrice * (this.serviceVat / 100);
                this.VatValue = (oldPrice + this.service) * (this.TaxGroup / 100);
                // this.totalPrice = this.totalPrice + (this.totalPrice * (this.TaxGroup / 100))
                this.totalPrice = this.totalPrice + this.service + this.VatValue;
                this.totalPrice = this.totalPrice - this.giftCardCount;
                if (this.totalPrice < 0) {
                    this.totalPrice = 0;
                    this.VatValue = 0;
                    this.service = 0;
                }
            }
        }
        sessionStorage.setItem('arrOfModfire', JSON.stringify(this.item));
    }
    plus(item) {
        let BeforeTax = localStorage.getItem('BeforeTax');
        console.log(item);
        this.soucePrice = 0;
        this.totalPrice = 0;
        this.modfirePrice = 0;
        this.priceOfProdct = 0;
        if (item.modfire.length != 0) {
            for (let i = 0; i < item.modfire.length; i++) {
                let count = item.modfire[i].count / item.Prdoucts[0].count;
                item.modfire[i].count = item.modfire[i].count + count;
                this.modfirePrice = this.modfirePrice + (item.modfire[i].Price * item.modfire[i].count);
            }
            console.log(this.modfirePrice);
        }
        if (item.ingridtArr.length != 0) {
            console.log(this.soucePrice);
            for (let i = 0; i < item.ingridtArr.length; i++) {
                let count = item.ingridtArr[i].count / item.Prdoucts[0].count;
                item.ingridtArr[i].count = item.ingridtArr[i].count + count;
                this.soucePrice = this.soucePrice + (item.ingridtArr[i].Price * item.ingridtArr[i].count);
                console.log(this.soucePrice);
            }
        }
        for (let i = 0; i < item.Prdoucts.length; i++) {
            item.Prdoucts[i].count = item.Prdoucts[i].count + 1;
            this.priceOfProdct = this.priceOfProdct + (item.Prdoucts[i].Price * item.Prdoucts[i].count);
        }
        let totalPrice = this.soucePrice + this.modfirePrice + this.priceOfProdct;
        console.log("is the final price", totalPrice);
        item.oldTotal = totalPrice;
        this.oldtotlaBeforDiscount = totalPrice;
        if (BeforeTax == 'false') {
            if (item.discount) {
                if (item.DiscountType == 1) {
                    let value = totalPrice * (item.discount / 100);
                    console.log(value);
                    if (value > item.MaxDiscountAmount) {
                        this.discountvalueOfPrint = item.MaxDiscountAmount;
                        item.total = totalPrice - item.MaxDiscountAmount;
                    }
                    else {
                        this.discountvalueOfPrint = value;
                        item.total = item.oldTotal * ((100 - item.discount) / 100);
                    }
                }
                else {
                    console.log(item);
                    // item.discount = (item.discount * item.Prdoucts[0].count)
                    this.discountvalueOfPrint = item.discount;
                    item.total = totalPrice - (item.discount * item.Prdoucts[0].count);
                }
            }
            else {
                this.discountvalueOfPrint = 0;
                item.total = this.soucePrice + this.modfirePrice + this.priceOfProdct;
            }
            for (let i = 0; i < this.item.length; i++) {
                this.totalPrice = this.totalPrice + this.item[i].total;
            }
            this.totalPriceAfterSerial = this.totalPrice;
            this.service = this.totalPrice * (this.serviceVat / 100);
            this.totalPrice = this.totalPrice + this.service;
            this.VatValue = this.totalPrice * (this.TaxGroup / 100);
            this.totalPrice = this.totalPrice + this.VatValue;
            this.totalPrice = this.totalPrice - this.giftCardCount;
            if (this.totalPrice < 0) {
                this.totalPrice = 0;
                this.VatValue = 0;
                this.service = 0;
            }
        }
        else {
            if (item.discount) {
                if (item.DiscountType == 1) {
                    let value = totalPrice * (item.discount / 100);
                    console.log(value);
                    if (value > item.MaxDiscountAmount) {
                        this.discountvalueOfPrint = item.MaxDiscountAmount;
                        item.total = totalPrice - item.MaxDiscountAmount;
                    }
                    else {
                        this.discountvalueOfPrint = value;
                        item.total = totalPrice * ((100 - item.discount) / 100);
                    }
                }
                else {
                    this.discountvalueOfPrint = item.discount;
                    item.total = totalPrice - (item.discount * item.Prdoucts[0].count);
                }
            }
            else {
                this.discountvalueOfPrint = 0;
                item.total = this.soucePrice + this.modfirePrice + this.priceOfProdct;
            }
            this.VatValue = 0;
            let oldPrice = 0;
            for (let i = 0; i < this.item.length; i++) {
                this.totalPrice = this.totalPrice + this.item[i].total;
                oldPrice = oldPrice + this.item[i].oldTotal;
            }
            console.log("this.totalPriceAfterSerial", this.totalPrice);
            this.totalPriceAfterSerial = this.totalPrice;
            this.service = this.totalPrice * (this.serviceVat / 100);
            this.totalPrice = this.totalPrice + this.service;
            this.VatValue = (oldPrice + this.service) * (this.TaxGroup / 100);
            this.totalPrice = this.totalPrice + this.VatValue;
            this.totalPrice = this.totalPrice - this.giftCardCount;
            if (this.totalPrice < 0) {
                this.totalPrice = 0;
                this.VatValue = 0;
                this.service = 0;
            }
        }
        console.log(this.item);
        sessionStorage.setItem('arrOfModfire', JSON.stringify(this.item));
        console.log(this.totalPrice);
    }
    goBack() {
        this.rest.sendObsData('true');
        this.route.navigateByUrl('/main_menu');
    }
    cancel() {
        this.route.navigateByUrl('/home');
        sessionStorage.clear();
        this.rest.sendObsData('true');
    }
    goToCheckOut() {
        let customerNumber = sessionStorage.getItem('mobileNumber');
        let ingrdtion = [];
        let modfiersArr = [];
        let prodArrOfCombo = [];
        let arradumy = [];
        let productArrofItem = [];
        let oldPrice = 0;
        let newPrice = 0;
        let DiscountAmount = 0;
        for (let i = 0; i < this.item.length; i++) {
            arradumy.push(this.item[i]);
        }
        console.log(arradumy);
        let arrofPrint = [];
        for (let i = 0; i < arradumy.length; i++) {
            ingrdtion = [];
            modfiersArr = [];
            let arr = [];
            oldPrice = oldPrice + arradumy[i].oldTotal;
            newPrice = newPrice + arradumy[i].total;
            if (arradumy[i].Prdoucts.length > 1) {
                for (let j = 0; j < arradumy[i].Prdoucts.length; j++) {
                    let obj = {
                        "Id": arradumy[i].Prdoucts[j].Id,
                        "Price": arradumy[i].Prdoucts[j].Price * arradumy[i].Prdoucts[j].count,
                        "Count": arradumy[i].Prdoucts[j].count,
                        'name': arradumy[i].Prdoucts[j].Name,
                        "sizeId": arradumy[i].Prdoucts[j].sizeId,
                        "compoName": arradumy[i].Prdoucts[j].compoName,
                        "parentCombo": arradumy[i].Prdoucts[j].parentCombo,
                        "sizeName": arradumy[i].Prdoucts[j].sizeName
                    };
                    arr.push(obj);
                    productArrofItem.push({
                        _mainData: obj,
                        Modifires: [],
                        Ingredients: []
                    });
                }
                arrofPrint.push({
                    mainData: arr
                });
            }
            else {
                let obj = {
                    "Id": arradumy[i].Prdoucts[0].Id,
                    "Price": arradumy[i].Prdoucts[0].Price * arradumy[i].Prdoucts[0].count,
                    "Count": arradumy[i].Prdoucts[0].count,
                    'name': arradumy[i].Prdoucts[0].Name
                };
                if (arradumy[i].modfire.length != 0) {
                    for (let j = 0; j < arradumy[i].modfire.length; j++) {
                        modfiersArr.push({
                            "Id": arradumy[i].modfire[j].Id,
                            "Price": arradumy[i].modfire[j].Price * arradumy[i].modfire[j].count,
                            "Count": arradumy[i].modfire[j].count,
                            "name": arradumy[i].modfire[j].Name
                        });
                    }
                }
                else {
                    modfiersArr = [];
                }
                if (arradumy[i].ingridtArr.length != 0) {
                    for (let j = 0; j < arradumy[i].ingridtArr.length; j++) {
                        ingrdtion.push({
                            "Id": arradumy[i].ingridtArr[j].Id,
                            "Price": arradumy[i].ingridtArr[j].Price * arradumy[i].ingridtArr[j].count,
                            "Count": arradumy[i].ingridtArr[j].count,
                            "name": arradumy[i].ingridtArr[j].Name
                        });
                    }
                }
                else {
                    ingrdtion = [];
                }
                productArrofItem.push({
                    _mainData: obj,
                    Modifires: modfiersArr,
                    Ingredients: ingrdtion
                });
                arr.push({
                    _mainData: obj,
                    Modifires: modfiersArr,
                    Ingredients: ingrdtion
                });
                arrofPrint.push({
                    mainData: arr
                });
            }
        }
        DiscountAmount = oldPrice - newPrice;
        let idOfBranch = localStorage.getItem("idOfBranch");
        let obj = {
            'BranchId': idOfBranch,
            "PaymentTypeId": 2,
            "totalPrice": this.totalPrice,
            'Products': productArrofItem,
            'CustomerPhone': customerNumber,
            'DiscountAmount': DiscountAmount,
            'oldPrice': this.totalPriceAfterSerial,
            "giftCardCount": this.giftCardCount,
            "discountvalueOfPrint": this.discountvalueOfPrint,
            "priceBeforDiscount": this.oldtotlaBeforDiscount,
            "vat": this.VatValue,
            "service": this.service,
            "serviceVat": this.serviceVat,
            "taxVat": this.TaxGroup
        };
        console.log(obj);
        sessionStorage.setItem('finalObj', JSON.stringify(obj));
        sessionStorage.setItem('finalObjOfPrint', JSON.stringify(arrofPrint));
        this.route.navigateByUrl('/payment');
    }
    removeItem(i, product) {
        let PrdouctVat;
        let PrdouctService;
        let BeforeTax = localStorage.getItem('BeforeTax');
        this.item.splice(i, 1);
        sessionStorage.setItem('arrOfModfire', JSON.stringify(this.item));
        console.log(product);
        if (product.discount) {
            if (BeforeTax == "true") {
                PrdouctService = product.total * (this.serviceVat / 100);
                PrdouctVat = (product.oldTotal + PrdouctService) * (this.TaxGroup / 100);
            }
            else {
                PrdouctService = product.total * (this.serviceVat / 100);
                PrdouctVat = (product.total + PrdouctService) * (this.TaxGroup / 100);
            }
        }
        else {
            PrdouctService = product.total * (this.serviceVat / 100);
            PrdouctVat = (product.total + PrdouctService) * (this.TaxGroup / 100);
        }
        this.totalPriceAfterSerial = this.totalPriceAfterSerial - product.total;
        this.totalPrice = this.totalPriceAfterSerial - this.giftCardCount;
        this.VatValue = this.VatValue - PrdouctVat;
        this.service = this.service - PrdouctService;
        this.totalPrice = this.totalPrice + this.VatValue;
        this.totalPrice = this.totalPrice + this.service;
        // if (this.totalPrice < 0) {
        //   this.totalPrice = 0
        //   this.VatValue = 0
        // }
        console.log(this.totalPrice, this.totalPriceAfterSerial);
        if (this.item.length == 0) {
            this.shwoProced = false;
            sessionStorage.clear();
            this.route.navigateByUrl('/home');
            this.rest.sendObsData('true');
        }
        else {
            this.shwoProced = true;
        }
    }
    edit(idOfEdit) {
        // sessionStorage.setItem('idOfEdit',idOfEdit)
        this.route.navigateByUrl('/add-souce');
    }
    validSerial() {
        console.log(this.giftCardCount);
        if (this.serialNumber != this.serialNumberIsUsed) {
            this.block = true;
            this.rest.sendValidSerial(this.serialNumber).subscribe((res) => {
                console.log(res);
                this.showIsValid = true;
                if (res.Status == "Valid") {
                    this.serialNumberIsUsed = this.serialNumber;
                    this.block = false;
                    this.showStatusValid = true;
                    this.showStatusValidFalse = false;
                    this.giftCardCount = res.Price;
                    if (this.langId == '1') {
                        this.giftCardISVaild = " كارت الهدايا صالح";
                    }
                    else {
                        this.giftCardISVaild = "Gift Card  is valid";
                    }
                    sessionStorage.setItem("idOfSerial", res.Id);
                    this.totalPriceAfterSerial = this.totalPrice;
                    this.totalPrice = this.totalPrice - res.Price;
                    if (this.totalPrice < 0) {
                        this.totalPrice = 0;
                        // this.VatValue = 0
                    }
                }
                else if (res.Status == "Not Valid") {
                    console.log(this.giftCardCount);
                    this.totalPrice = this.totalPrice + this.giftCardCount;
                    this.totalPriceAfterSerial = this.totalPrice;
                    this.giftCardCount = 0;
                    this.serialNumberIsUsed = "";
                    if (this.langId == '1') {
                        this.giftCardISVaild = " كارت الهدايا غير صالح";
                    }
                    else {
                        this.giftCardISVaild = "Gift Card Number Not Valid";
                    }
                    this.showStatusValid = false;
                    this.showStatusValidFalse = true;
                    this.block = false;
                }
                else if (res.Status == "Expired") {
                    this.serialNumberIsUsed = "";
                    this.totalPrice = this.totalPrice + this.giftCardCount;
                    this.totalPriceAfterSerial = this.totalPrice;
                    this.giftCardCount = 0;
                    if (this.langId == '1') {
                        this.giftCardISVaild = " كارت الهدايا منتهي ";
                    }
                    else {
                        this.giftCardISVaild = "Gift Card Number Expired";
                    }
                    this.showStatusValid = false;
                    this.showStatusValidFalse = true;
                    this.block = false;
                }
                else {
                    this.serialNumberIsUsed = "";
                    this.totalPrice = this.totalPrice + this.giftCardCount;
                    this.totalPriceAfterSerial = this.totalPrice;
                    this.giftCardCount = 0;
                    if (this.langId == '1') {
                        this.giftCardISVaild = " كارت الهدايا تم استخدامه ";
                    }
                    else {
                        this.giftCardISVaild = "Gift Card Number Used";
                    }
                    this.showStatusValid = false;
                    this.showStatusValidFalse = true;
                    this.block = false;
                }
            });
            console.log(this.serialNumber);
        }
    }
    inputChange(event) {
        this.showStatusValid = false;
        this.showStatusValidFalse = false;
        // this.serialNumberIsUsed = event.target.value
        if (event.target.value == "") {
            this.totalPrice = this.totalPrice + this.giftCardCount;
            this.totalPriceAfterSerial = this.totalPrice;
            this.giftCardCount = 0;
            this.serialNumberIsUsed = "";
        }
        // this.showStatusValid = !this.showStatusValid
    }
};
ReviewPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.LoadingController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService }
];
ReviewPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-review',
        template: _review_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_review_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReviewPage);



/***/ }),

/***/ 2057:
/*!**********************************************************!*\
  !*** ./src/app/pages/review/review.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background: #010100 ;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: #fff;\n  text-transform: none;\n}\n\nion-spinner {\n  position: absolute;\n  top: 8%;\n  left: 43%;\n  transform: scale(4.5);\n}\n\n.header-md::after {\n  background: none !important;\n}\n\n.back {\n  text-transform: none;\n  display: flex;\n  justify-content: space-between;\n}\n\n.back ion-img {\n  width: 240px;\n}\n\n.back ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 5%;\n  font-size: 5vw;\n  height: 84px;\n  margin-bottom: 3%;\n  color: #000;\n}\n\n.logo {\n  margin-top: 0;\n  display: flex;\n  justify-content: center;\n}\n\n.logo .logoImage {\n  width: 50%;\n  border-radius: 10px;\n}\n\n.title {\n  text-align: center;\n}\n\n.title p {\n  margin-top: 0;\n}\n\nhr {\n  background: #9c9c9c;\n  margin: 0;\n}\n\n.right {\n  font-size: 3rem;\n}\n\n.containerOfShaping {\n  background: #e2dcdc;\n  margin: 2%;\n  padding: 3%;\n  border-radius: 5px;\n  color: #000;\n}\n\n.nameAndPrice, .editOrRemove {\n  display: flex;\n  justify-content: space-between;\n}\n\n.nameAndPrice p {\n  font-size: 5vw;\n}\n\n.editOrRemove {\n  margin-top: 12px;\n}\n\n.editOrRemove ion-button {\n  --background: #000000;\n  color: #fff;\n  height: 112px;\n  font-size: 4vw;\n}\n\n.plusAndMuins {\n  display: flex;\n}\n\n.plusAndMuins .countProduct {\n  --background: #b4b1b1;\n  margin: 4px;\n}\n\n.plusAndMuins ion-button {\n  --background: #fcef50;\n  color: #000;\n  height: 95px;\n}\n\n.fotter {\n  position: absolute;\n  bottom: 0;\n  text-align: right;\n  width: 100%;\n  padding: 0 2% 2% 2%;\n  background: #010100;\n}\n\n.fotter div {\n  display: flex;\n  justify-content: space-between;\n}\n\n.containerPrdouct {\n  height: 50vh;\n  overflow-y: scroll;\n}\n\n.ion-foter ion-button {\n  font-size: 3vw;\n  height: 111px;\n  color: #000;\n}\n\n.block {\n  width: 100%;\n  height: 100vh;\n  position: absolute;\n  top: 0;\n  z-index: 100000000;\n  background: gray;\n}\n\n.serial {\n  display: flex;\n  justify-content: space-around;\n}\n\n.serial ion-button {\n  color: #000;\n  height: 100px;\n  width: 31%;\n  font-size: 3rem;\n}\n\n.serial input {\n  font-size: 3rem;\n  width: 50%;\n  height: 100px;\n}\n\n.giftCard {\n  margin: 0;\n  font-size: 3rem;\n  text-align: center;\n}\n\n@media only screen and (max-width: 768px) {\n  .right {\n    font-size: 17px;\n  }\n\n  .back ion-img {\n    width: 84px;\n  }\n\n  .back ion-button {\n    margin-bottom: 0;\n    height: 36px;\n    margin-top: 0;\n  }\n\n  .editOrRemove ion-button {\n    height: 45px;\n  }\n\n  .plusAndMuins ion-button {\n    height: 43px;\n  }\n\n  .plusAndMuins p {\n    height: 45px;\n  }\n\n  .ion-foter ion-button {\n    height: 45px;\n    width: 148px;\n  }\n\n  .containerPrdouct {\n    height: 47vh;\n  }\n\n  .serial ion-button {\n    height: 37px;\n    width: 31%;\n    font-size: 1rem;\n  }\n\n  .serial input {\n    font-size: 1rem;\n    width: 50%;\n    height: 40px;\n  }\n\n  .giftCard {\n    margin: 0;\n    font-size: 14px;\n    text-align: center;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJldmlldy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxzQkFBQTtBQUNGOztBQUNBO0VBQ0UscUJBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7QUFFRjs7QUFBQTtFQUNFLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFNBQUE7RUFDQSxxQkFBQTtBQUdGOztBQURBO0VBQ0UsMkJBQUE7QUFJRjs7QUFGQTtFQUNFLG9CQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0FBS0Y7O0FBSEE7RUFDRSxZQUFBO0FBTUY7O0FBSkU7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7QUFPSjs7QUFMRTtFQUNFLGFBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7QUFRSjs7QUFORTtFQUNFLFVBQUE7RUFDQSxtQkFBQTtBQVNKOztBQVBFO0VBQ0Usa0JBQUE7QUFVSjs7QUFSRTtFQUNFLGFBQUE7QUFXSjs7QUFURTtFQUNFLG1CQUFBO0VBQ0EsU0FBQTtBQVlKOztBQVZFO0VBQ0UsZUFBQTtBQWFKOztBQVhFO0VBQ0UsbUJBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQWNKOztBQVpFO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0FBZUo7O0FBYkU7RUFDRSxjQUFBO0FBZ0JKOztBQWRFO0VBQ0UsZ0JBQUE7QUFpQko7O0FBZkU7RUFDSSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtBQWtCTjs7QUFoQkU7RUFDSSxhQUFBO0FBbUJOOztBQWpCRTtFQUNFLHFCQUFBO0VBQ0EsV0FBQTtBQW9CSjs7QUFsQkU7RUFDRSxxQkFBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBcUJOOztBQWpCRTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUFvQk47O0FBbEJFO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0FBcUJOOztBQWxCRTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQXFCRjs7QUFuQkU7RUFDRSxjQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7QUFzQko7O0FBcEJFO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBdUJKOztBQXJCRTtFQUNFLGFBQUE7RUFDQSw2QkFBQTtBQXdCSjs7QUF0QkU7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFVBQUE7RUFDQSxlQUFBO0FBeUJKOztBQXZCRTtFQUNFLGVBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtBQTBCSjs7QUF4QkU7RUFDRSxTQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBMkJKOztBQXpCRTtFQUNFO0lBQ0UsZUFBQTtFQTRCSjs7RUExQkU7SUFDRSxXQUFBO0VBNkJKOztFQTNCRTtJQUNFLGdCQUFBO0lBQ0EsWUFBQTtJQUNBLGFBQUE7RUE4Qko7O0VBNUJFO0lBQ0UsWUFBQTtFQStCSjs7RUE3QkU7SUFDRSxZQUFBO0VBZ0NKOztFQTlCRTtJQUNFLFlBQUE7RUFpQ0o7O0VBL0JFO0lBQ0UsWUFBQTtJQUNBLFlBQUE7RUFrQ0o7O0VBaENFO0lBQ0UsWUFBQTtFQW1DSjs7RUFqQ0U7SUFDRSxZQUFBO0lBQ0EsVUFBQTtJQUNBLGVBQUE7RUFvQ0o7O0VBbENFO0lBQ0UsZUFBQTtJQUNBLFVBQUE7SUFDQSxZQUFBO0VBcUNKOztFQW5DRTtJQUNFLFNBQUE7SUFDQSxlQUFBO0lBQ0Esa0JBQUE7RUFzQ0o7QUFDRiIsImZpbGUiOiJyZXZpZXcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XG4gIC0tYmFja2dyb3VuZDogIzAxMDEwMFxufVxuaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogI0UxRTFFMTtcbiAgLS1jb2xvcjogI2ZmZjsgXG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xufVxuaW9uLXNwaW5uZXJ7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA4JTtcbiAgbGVmdDogNDMlO1xuICB0cmFuc2Zvcm06IHNjYWxlKDQuNSk7XG59XG4uaGVhZGVyLW1kOjphZnRlcntcbiAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50XG59XG4uYmFjayB7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG59XG4uYmFjayBpb24taW1nIHtcbiAgd2lkdGg6IDI0MHB4O1xufVxuICAuYmFjayBpb24tYnV0dG9ue1xuICAgIC0tcGFkZGluZy1zdGFydDogMmVtO1xuICAgIC0tcGFkZGluZy1lbmQ6IDJlbTtcbiAgICAtLWJvcmRlci1yYWRpdXM6NXB4O1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICAgIGZvbnQtc2l6ZTogNXZ3O1xuICAgIGhlaWdodDogODRweDtcbiAgICBtYXJnaW4tYm90dG9tOjMlO1xuICAgIGNvbG9yOiAjMDAwXG4gIH1cbiAgLmxvZ297XG4gICAgbWFyZ2luLXRvcDowO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXJcbiAgfVxuICAubG9nbyAubG9nb0ltYWdlIHtcbiAgICB3aWR0aDogNTAlO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHhcbiAgfVxuICAudGl0bGV7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB9XG4gIC50aXRsZSBwIHtcbiAgICBtYXJnaW4tdG9wOiAwXG4gIH1cbiAgaHIge1xuICAgIGJhY2tncm91bmQ6ICM5YzljOWM7XG4gICAgbWFyZ2luOiAwO1xuICB9XG4gIC5yaWdodCB7XG4gICAgZm9udC1zaXplOiAzcmVtO1xuICB9XG4gIC5jb250YWluZXJPZlNoYXBpbmd7XG4gICAgYmFja2dyb3VuZDogI2UyZGNkYztcbiAgICBtYXJnaW46IDIlO1xuICAgIHBhZGRpbmc6MyU7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIGNvbG9yOiAjMDAwO1xuICB9XG4gIC5uYW1lQW5kUHJpY2UgLCAuZWRpdE9yUmVtb3Zle1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICB9XG4gIC5uYW1lQW5kUHJpY2UgcCB7XG4gICAgZm9udC1zaXplOiA1dndcbiAgfVxuICAuZWRpdE9yUmVtb3Zle1xuICAgIG1hcmdpbi10b3A6IDEycHg7XG4gIH1cbiAgLmVkaXRPclJlbW92ZSBpb24tYnV0dG9ue1xuICAgICAgLS1iYWNrZ3JvdW5kOiAjMDAwMDAwO1xuICAgICAgY29sb3I6ICNmZmY7XG4gICAgICBoZWlnaHQ6IDExMnB4O1xuICAgICAgZm9udC1zaXplOiA0dnc7XG4gIH1cbiAgLnBsdXNBbmRNdWlucyB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICB9XG4gIC5wbHVzQW5kTXVpbnMgLmNvdW50UHJvZHVjdCB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjYjRiMWIxO1xuICAgIG1hcmdpbjogNHB4IDtcbiAgfVxuICAucGx1c0FuZE11aW5zIGlvbi1idXR0b257XG4gICAgLS1iYWNrZ3JvdW5kOiAjZmNlZjUwO1xuICAgICAgY29sb3I6ICMwMDA7XG4gICAgICBoZWlnaHQ6IDk1cHg7XG4gIH1cblxuXG4gIC5mb3R0ZXJ7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICBib3R0b206IDA7XG4gICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgcGFkZGluZzogMCAyJSAyJSAyJTtcbiAgICAgIGJhY2tncm91bmQ6ICMwMTAxMDA7XG4gICAgfVxuICAuZm90dGVyIGRpdiB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuXG4gIH1cblxuICAuY29udGFpbmVyUHJkb3VjdHtcbiAgaGVpZ2h0OiA1MHZoO1xuICBvdmVyZmxvdy15OiBzY3JvbGw7XG4gIH1cbiAgLmlvbi1mb3RlciBpb24tYnV0dG9ue1xuICAgIGZvbnQtc2l6ZTogM3Z3O1xuICAgIGhlaWdodDogMTExcHg7XG4gICAgY29sb3I6ICMwMDBcbiAgfVxuICAuYmxvY2t7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDB2aDtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAwO1xuICAgIHotaW5kZXg6IDEwMDAwMDAwMDtcbiAgICBiYWNrZ3JvdW5kOiBncmF5O1xuICB9XG4gIC5zZXJpYWwge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG4gIH1cbiAgLnNlcmlhbCBpb24tYnV0dG9uIHtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICAgIHdpZHRoOiAzMSU7XG4gICAgZm9udC1zaXplOiAzcmVtO1xuICB9XG4gIC5zZXJpYWwgaW5wdXQge1xuICAgIGZvbnQtc2l6ZTogM3JlbTtcbiAgICB3aWR0aDogNTAlO1xuICAgIGhlaWdodDogMTAwcHg7XG4gIH1cbiAgLmdpZnRDYXJke1xuICAgIG1hcmdpbjogMDtcbiAgICBmb250LXNpemU6M3JlbTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbiAgQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjc2OHB4KXtcbiAgICAucmlnaHR7XG4gICAgICBmb250LXNpemU6IDE3cHg7XG4gICAgfVxuICAgIC5iYWNrIGlvbi1pbWd7XG4gICAgICB3aWR0aDogODRweDtcbiAgICB9XG4gICAgLmJhY2sgaW9uLWJ1dHRvbntcbiAgICAgIG1hcmdpbi1ib3R0b206IDA7XG4gICAgICBoZWlnaHQ6IDM2cHg7XG4gICAgICBtYXJnaW4tdG9wOiAwO1xuICAgIH1cbiAgICAuZWRpdE9yUmVtb3ZlIGlvbi1idXR0b257XG4gICAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgfVxuICAgIC5wbHVzQW5kTXVpbnMgaW9uLWJ1dHRvbntcbiAgICAgIGhlaWdodDogNDNweDtcbiAgICB9XG4gICAgLnBsdXNBbmRNdWlucyBwIHtcbiAgICAgIGhlaWdodDogNDVweDtcbiAgICB9XG4gICAgLmlvbi1mb3RlciBpb24tYnV0dG9ue1xuICAgICAgaGVpZ2h0OiA0NXB4O1xuICAgICAgd2lkdGg6IDE0OHB4O1xuICAgIH1cbiAgICAuY29udGFpbmVyUHJkb3VjdHtcbiAgICAgIGhlaWdodDogNDd2aDtcbiAgICB9XG4gICAgLnNlcmlhbCBpb24tYnV0dG9uIHtcbiAgICAgIGhlaWdodDogMzdweDtcbiAgICAgIHdpZHRoOiAzMSU7XG4gICAgICBmb250LXNpemU6IDFyZW07XG4gICAgfVxuICAgIC5zZXJpYWwgaW5wdXQge1xuICAgICAgZm9udC1zaXplOiAxcmVtO1xuICAgICAgd2lkdGg6IDUwJTtcbiAgICAgIGhlaWdodDogNDBweDtcbiAgICB9XG4gICAgLmdpZnRDYXJke1xuICAgICAgbWFyZ2luOiAwO1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIH1cbiAgfSJdfQ== */";

/***/ }),

/***/ 249:
/*!**********************************************************!*\
  !*** ./src/app/pages/review/review.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<!-- <div class=\"block\" *ngIf=\"block\"></div> -->\n<ion-header>\n  <div class=\"back\" style=\"background: #010100\">\n    <ion-img class=\"logoImage\" src=\"assets/images/bingo.png\"></ion-img>\n    <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n  </div>\n</ion-header>\n\n<ion-content [dir]=\"dir\">\n  <ion-spinner dir=\"ltr\" *ngIf=\"block\" name=\"circles\"></ion-spinner>\n  <div class=\"title\">\n    <p style=\"color: #fff ; font-size: 5vw\">{{reviewMyOrder}}</p>\n  </div>\n  <div class=\"form-group serial\" [dir]=\"dir\" *ngIf=\"!block\">\n    <input (input)=\"inputChange($event)\" [(ngModel)]=\"serialNumber\" [placeholder]=\"placeHolder\" class=\"btn btn-primary\"\n      type=\"text\">\n    <ion-button [disabled]=\"serialNumber == ''\" style=\"color: #000\" (click)=\"validSerial()\">{{serialVaild}}</ion-button>\n  </div>\n  <p *ngIf=\"showStatusValid\" style=\"color: green\" class=\"giftCard\">{{giftCardISVaild}} {{giftCardCount}} {{LE}}</p>\n  <p *ngIf=\"showStatusValidFalse && serialNumber != ''\" style=\"color: red\" class=\"giftCard\">{{giftCardISVaild}}</p>\n\n  <div class=\"containerPrdouct\" [dir]=\"dir\" *ngIf=\"!block\">\n    <div class=\"containerOfShaping\" style=\"margin-top: 5%;\" *ngFor=\"let product of item ; let i = index\">\n      <p *ngIf=\"product.Prdoucts[0].compoName\">{{product.Prdoucts[0].compoName}} - {{product.Prdoucts[0].parentCombo}} - {{product.Prdoucts[0].sizeName}}</p>\n      <div class=\"nameAndPrice\" *ngFor=\"let item of product.Prdoucts\">\n        <p>{{item.count}}x {{item.Name}}</p>\n        <p *ngIf=\"!product.Prdoucts[0].sizeName\">{{item.Price * item.count | number : '1.2-2'}} {{LE}} </p>\n      </div>\n      <hr>\n      <div *ngIf=\"product.ingridtArr.length \">\n        <div class=\"nameAndPrice\" *ngFor=\"let item of product.ingridtArr\">\n          <p> {{item.count}}x {{item.Name}}</p>\n          <p>{{item.Price * item.count | number : '1.2-2'}} {{LE}}</p>\n        </div>\n      </div>\n      <hr>\n      <div *ngIf=\"product.modfire.length \">\n        <div class=\"nameAndPrice\" *ngFor=\"let item of product.modfire\">\n          <p> {{item.count}}x {{item.Name}}</p>\n          <p>{{item.Price * item.count | number : '1.2-2'}} {{LE}}</p>\n        </div>\n      </div>\n      <hr>\n      <div>\n        <p *ngIf=\"product.discount && product.DiscountType == 1 && langId != 1\" class=\"right\">{{Total}} <s\n            style=\"color: red\">{{LE}}.{{product.oldTotal | number : '1.2-2'}}</s> <br>\n          ({{product.discount * product.Prdoucts[0].count}}%) {{upto}} {{product.MaxDiscountAmount}} </p>\n\n        <p *ngIf=\"product.discount && product.DiscountType == 2 && langId != 1\" class=\"right\">{{Total}} <s\n            style=\"color: red\">{{LE}}.{{product.oldTotal | number : '1.2-2'}}</s> <br>\n          (-{{product.discount * product.Prdoucts[0].count}}) {{Discount}} </p>\n\n        <p *ngIf=\"product.discount && product.DiscountType == 1 && langId == 1\" class=\"right\">{{Total}} <s\n            style=\"color: red\">{{product.oldTotal | number : '1.2-2'}} {{LE}}</s> <br>\n          ({{product.discount * product.Prdoucts[0].count}}%) {{upto}} {{product.MaxDiscountAmount}} </p>\n\n        <p *ngIf=\"product.discount && product.DiscountType == 2 && langId == 1\" class=\"right\">{{Total}} <s\n            style=\"color: red\">{{product.oldTotal | number : '1.2-2'}} {{LE}}</s> <br>\n          (-{{product.discount * product.Prdoucts[0].count}}) {{Discount}} </p>\n\n        <p *ngIf=\"product.discount\" class=\"right\"> {{product.total | number : '1.2-2'}} {{LE}}</p>\n        <p *ngIf=\"!product.discount\" class=\"right\"><span>{{Total}} </span> {{product.total | number : '1.2-2'}} {{LE}}\n        </p>\n      </div>\n      <div class=\"editOrRemove\">\n        <ion-button (click)=\"removeItem(i,product)\">{{Remove}}</ion-button>\n        <div class=\"plusAndMuins\" [dir]=\"dir\">\n          <ion-button (click)=\"plus(product)\">+</ion-button>\n          <ion-button class=\"countProduct\">{{product.Prdoucts[0].count}}</ion-button>\n          <ion-button (click)=\"minus(product)\">-</ion-button>\n        </div>\n        <!-- <ion-button (click)=\"edit(product.Id)\">{{Edit}}</ion-button> -->\n      </div>\n\n    </div>\n  </div>\n\n\n\n\n  <div class=\"fotter\" *ngIf=\"!block\">\n    <!-- <p style=\"color: #fff ; font-size: 4vw ; font-weight: bold\">( {{serviceName}} {{serviceVat}}% ) {{service | number : '1.2-2'}} {{LE}}</p> -->\n    <p style=\"color: #fff ; font-size: 4vw ; font-weight: bold\">( {{Vat}} {{TaxGroup}}% ) {{VatValue | number : '1.2-2'}} {{LE}}</p>\n    <p style=\"color: #fff ; font-size: 4vw ; font-weight: bold\">{{Total}}\n      {{totalPrice | number : '1.2-2'}} {{LE}}</p>\n    <div class=\"ion-foter\" dir=\"ltr\">\n      <ion-button [disabled]=\"block\" (click)=\"cancel()\">{{Cancel}}</ion-button>\n      <ion-button [disabled]=\"block\" (click)=\"goToCheckOut()\">{{CheckOut}}</ion-button>\n    </div>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_review_review_module_ts.js.map