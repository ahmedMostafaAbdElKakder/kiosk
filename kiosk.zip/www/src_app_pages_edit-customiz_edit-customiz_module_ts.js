"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_edit-customiz_edit-customiz_module_ts"],{

/***/ 5947:
/*!*********************************************************************!*\
  !*** ./src/app/pages/edit-customiz/edit-customiz-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditCustomizPageRoutingModule": () => (/* binding */ EditCustomizPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _edit_customiz_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-customiz.page */ 2548);




const routes = [
    {
        path: '',
        component: _edit_customiz_page__WEBPACK_IMPORTED_MODULE_0__.EditCustomizPage
    }
];
let EditCustomizPageRoutingModule = class EditCustomizPageRoutingModule {
};
EditCustomizPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EditCustomizPageRoutingModule);



/***/ }),

/***/ 5154:
/*!*************************************************************!*\
  !*** ./src/app/pages/edit-customiz/edit-customiz.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditCustomizPageModule": () => (/* binding */ EditCustomizPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _edit_customiz_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-customiz-routing.module */ 5947);
/* harmony import */ var _edit_customiz_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-customiz.page */ 2548);







let EditCustomizPageModule = class EditCustomizPageModule {
};
EditCustomizPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _edit_customiz_routing_module__WEBPACK_IMPORTED_MODULE_0__.EditCustomizPageRoutingModule
        ],
        declarations: [_edit_customiz_page__WEBPACK_IMPORTED_MODULE_1__.EditCustomizPage]
    })
], EditCustomizPageModule);



/***/ }),

/***/ 2548:
/*!***********************************************************!*\
  !*** ./src/app/pages/edit-customiz/edit-customiz.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditCustomizPage": () => (/* binding */ EditCustomizPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _edit_customiz_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-customiz.page.html?ngResource */ 4116);
/* harmony import */ var _edit_customiz_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-customiz.page.scss?ngResource */ 6081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);






let EditCustomizPage = class EditCustomizPage {
    constructor(route, rest) {
        this.route = route;
        this.rest = rest;
    }
    ngOnInit() {
        this.ingrdArr = JSON.parse(sessionStorage.getItem('IngrdDub'));
        this.modfiresArr = JSON.parse(sessionStorage.getItem('modfiresArr'));
        this.itemOfChnage = JSON.parse(sessionStorage.getItem('itemISChange'));
        console.log(this.itemOfChnage);
        if (this.itemOfChnage.ingridtArr.length != 0) {
            for (let j = 0; j < this.ingrdArr.length; j++) {
                this.ingrdArr[j].count = 0;
            }
            for (let i = 0; i < this.itemOfChnage.ingridtArr.length; i++) {
                for (let j = 0; j < this.ingrdArr.length; j++) {
                    if (this.itemOfChnage.ingridtArr[i].Id == this.ingrdArr[j].Id) {
                        this.ingrdArr[j].count = this.itemOfChnage.ingridtArr[i].count;
                    }
                }
            }
        }
        else {
            for (let j = 0; j < this.ingrdArr.length; j++) {
                this.ingrdArr[j].count = 0;
            }
        }
        if (this.itemOfChnage.modfire.length != 0) {
            for (let j = 0; j < this.modfiresArr.length; j++) {
                this.modfiresArr[j].count = 0;
            }
            for (let i = 0; i < this.itemOfChnage.modfire.length; i++) {
                for (let j = 0; j < this.modfiresArr.length; j++) {
                    if (this.itemOfChnage.modfire[i].Id == this.modfiresArr[j].Id) {
                        this.modfiresArr[j].count = this.itemOfChnage.modfire[i].count;
                    }
                }
            }
        }
        else {
            for (let j = 0; j < this.modfiresArr.length; j++) {
                this.modfiresArr[j].count = 0;
            }
        }
        this.langId = localStorage.getItem("lang");
        if (this.langId == '1') {
            this.dir = 'rtl';
            this.Back = "رجوع";
            this.addChange = "حفظ";
            this.Cancel = "إلغاء";
            this.Ingredients = "المكونات";
            this.Modfires = "الاضافات";
        }
        else {
            this.dir = 'ltr';
            this.Back = "Back";
            this.addChange = "Save";
            this.Cancel = "Cancel";
            this.Ingredients = "Ingredients";
            this.Modfires = "Modifiers";
        }
    }
    plus(value) {
        value.count = value.count + 1;
    }
    minus(value) {
        if (value.count >= 1) {
            value.count = value.count - 1;
        }
    }
    save() {
        let arr = [];
        arr = JSON.parse(sessionStorage.getItem('myArrOfItems'));
        for (let i = 0; i < this.ingrdArr.length; i++) {
            if (this.ingrdArr[i].count == 0) {
                this.ingrdArr.splice(i, 1);
            }
        }
        for (let i = 0; i < this.modfiresArr.length; i++) {
            if (this.modfiresArr[i].count == 0) {
                this.modfiresArr.splice(i, 1);
            }
        }
        this.itemOfChnage.ingridtArr = this.ingrdArr;
        this.itemOfChnage.modfire = this.modfiresArr;
        for (let i = 0; i < arr.length; i++) {
            if (arr[i].id == this.itemOfChnage.id) {
                arr.splice(i, 1);
            }
        }
        arr.push(this.itemOfChnage);
        arr.reverse();
        sessionStorage.setItem('myArrOfItems', JSON.stringify(arr));
        this.route.navigateByUrl("/customize");
        this.rest.sendDataOfDub('true');
    }
    goBack() {
        this.route.navigateByUrl('/customize');
    }
};
EditCustomizPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService }
];
EditCustomizPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-edit-customiz',
        template: _edit_customiz_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_edit_customiz_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EditCustomizPage);



/***/ }),

/***/ 6081:
/*!************************************************************************!*\
  !*** ./src/app/pages/edit-customiz/edit-customiz.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcef50;\n}\n\nh5 {\n  font-size: 3rem;\n  margin: 10px;\n}\n\nion-content {\n  --background:#fff ;\n  --color: black ;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: #000;\n  text-transform: none;\n}\n\n.back, .backIfRight {\n  text-transform: none;\n  margin-top: 5px;\n}\n\n.back ion-button, .backIfRight ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 5%;\n  font-size: 5vw;\n  height: 84px;\n  margin-bottom: 3%;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.addSouce {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 10px;\n}\n\n.addSouce ion-button {\n  --background: rgb(252, 239, 80);\n  color: #000;\n  height: 135px;\n  font-size: 5vw;\n}\n\n.count {\n  background: gainsboro;\n  height: 135px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-radius: 6px;\n  margin-top: 3px;\n  font-size: 5vw;\n}\n\n.count p {\n  margin: 0;\n}\n\n.extra {\n  margin-top: 6px;\n  font-size: 5vw;\n}\n\n.extra span {\n  font-size: 4vw;\n  color: gray;\n}\n\n.footer {\n  position: absolute;\n  bottom: 1%;\n  width: 100%;\n}\n\n.footer div {\n  display: flex;\n  justify-content: space-around;\n}\n\n.footer ion-button {\n  width: 35%;\n  font-size: 4vw;\n  height: 120px;\n}\n\n@media only screen and (max-width: 768px) {\n  .imgProduct {\n    width: 82px;\n  }\n\n  .back ion-button, .backIfRight ion-button {\n    height: 41px;\n  }\n\n  h5 {\n    font-size: 1rem;\n  }\n\n  .addSouce ion-button {\n    height: 38px;\n  }\n\n  .count {\n    height: 42px;\n  }\n\n  .footer ion-button {\n    height: 42px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVkaXQtY3VzdG9taXoucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxtQkFBQTtBQUNKOztBQUNFO0VBQ0UsZUFBQTtFQUNBLFlBQUE7QUFFSjs7QUFBRTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtBQUdKOztBQURFO0VBQ0UscUJBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7QUFJSjs7QUFGRTtFQUNFLG9CQUFBO0VBQ0EsZUFBQTtBQUtKOztBQUhFO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFNSjs7QUFKRTtFQUNFLGlCQUFBO0FBT0o7O0FBTEU7RUFDRSxnQkFBQTtBQVFKOztBQUxFO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUFRSjs7QUFMQTtFQUNJLCtCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0FBUUo7O0FBTkE7RUFDRSxxQkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFTRjs7QUFQQTtFQUNJLFNBQUE7QUFVSjs7QUFSQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBV0Y7O0FBVEE7RUFDRSxjQUFBO0VBQ0EsV0FBQTtBQVlGOztBQVRBO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtBQVlGOztBQVZBO0VBQ0UsYUFBQTtFQUNBLDZCQUFBO0FBYUY7O0FBWEE7RUFDRSxVQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7QUFjRjs7QUFURTtFQUNFO0lBQ0ksV0FBQTtFQVlOOztFQVZJO0lBQ0UsWUFBQTtFQWFOOztFQVhJO0lBQ0UsZUFBQTtFQWNOOztFQVpJO0lBQ0UsWUFBQTtFQWVOOztFQWJJO0lBQ0UsWUFBQTtFQWdCTjs7RUFkSTtJQUNFLFlBQUE7RUFpQk47QUFDRiIsImZpbGUiOiJlZGl0LWN1c3RvbWl6LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGJhY2tncm91bmQ6ICNmY2VmNTBcbiAgfVxuICBoNXtcbiAgICBmb250LXNpemU6IDNyZW07XG4gICAgbWFyZ2luOiAxMHB4XG4gIH1cbiAgaW9uLWNvbnRlbnR7XG4gICAgLS1iYWNrZ3JvdW5kOiNmZmYgO1xuICAgIC0tY29sb3I6IGJsYWNrXG4gIH1cbiAgaW9uLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjRTFFMUUxO1xuICAgIC0tY29sb3I6ICMwMDA7IFxuICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICB9XG4gIC5iYWNrICwuYmFja0lmUmlnaHR7XG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gICAgbWFyZ2luLXRvcDogNXB4O1xuICB9XG4gIC5iYWNrIGlvbi1idXR0b24gLCAuYmFja0lmUmlnaHQgaW9uLWJ1dHRvbntcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDJlbTtcbiAgICAtLXBhZGRpbmctZW5kOiAyZW07XG4gICAgLS1ib3JkZXItcmFkaXVzOjVweDtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICBmb250LXNpemU6IDV2dztcbiAgICBoZWlnaHQ6IDg0cHg7XG4gICAgbWFyZ2luLWJvdHRvbTozJVxuICB9XG4gIC5iYWNrIHtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgfVxuICAuYmFja0lmUmlnaHR7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgfVxuXG4gIC5hZGRTb3VjZSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweFxufVxuXG4uYWRkU291Y2UgaW9uLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiByZ2IoMjUyLCAyMzksIDgwKTtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBoZWlnaHQ6IDEzNXB4O1xuICAgIGZvbnQtc2l6ZTogNXZ3XG59XG4uY291bnQge1xuICBiYWNrZ3JvdW5kOiBnYWluc2Jvcm87XG4gIGhlaWdodDogMTM1cHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG4gIG1hcmdpbi10b3A6IDNweDtcbiAgZm9udC1zaXplOiA1dnc7XG59XG4uY291bnQgcCB7XG4gICAgbWFyZ2luOiAwO1xufVxuLmV4dHJhe1xuICBtYXJnaW4tdG9wOiA2cHg7XG4gIGZvbnQtc2l6ZTo1dnc7XG59XG4uZXh0cmEgc3BhbiB7XG4gIGZvbnQtc2l6ZTogNHZ3O1xuICBjb2xvcjogZ3JheTtcbn1cblxuLmZvb3RlciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAxJTtcbiAgd2lkdGg6IDEwMCVcbn1cbi5mb290ZXIgZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmRcbn1cbi5mb290ZXIgaW9uLWJ1dHRvbntcbiAgd2lkdGg6IDM1JTtcbiAgZm9udC1zaXplOiA0dnc7XG4gIGhlaWdodDogMTIwcHg7XG4gIFxuXG59XG5cbiAgQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjc2OHB4KXtcbiAgICAuaW1nUHJvZHVjdHtcbiAgICAgICAgd2lkdGg6IDgycHg7XG4gICAgICB9XG4gICAgICAuYmFjayBpb24tYnV0dG9uICwgLmJhY2tJZlJpZ2h0IGlvbi1idXR0b257XG4gICAgICAgIGhlaWdodDogNDFweDtcbiAgICAgIH1cbiAgICAgIGg1e1xuICAgICAgICBmb250LXNpemU6IDFyZW1cbiAgICAgIH1cbiAgICAgIC5hZGRTb3VjZSBpb24tYnV0dG9ue1xuICAgICAgICBoZWlnaHQ6IDM4cHg7XG4gICAgICB9XG4gICAgICAuY291bnQge1xuICAgICAgICBoZWlnaHQ6IDQycHg7XG4gICAgICB9XG4gICAgICAuZm9vdGVyIGlvbi1idXR0b257XG4gICAgICAgIGhlaWdodDogNDJweDtcbiAgICAgIH1cbiAgfSJdfQ== */";

/***/ }),

/***/ 4116:
/*!************************************************************************!*\
  !*** ./src/app/pages/edit-customiz/edit-customiz.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"header\">\n  <img class=\"imgProduct \" src=\"assets/images/bingo.png\">\n</div>\n\n<ion-content>\n  <div [ngClass]=\"{'back':dir == 'ltr','backIfRight':dir == 'rtl'}\">\n    <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n  </div>\n\n\n  <h5> {{Ingredients}}</h5>\n  <ion-grid>\n    <ion-row class=\"addSouce\" *ngFor=\"let item of ingrdArr\">\n      <ion-col size=\"2\">\n        <ion-button (click)=\"plus(item)\">+</ion-button>\n      </ion-col>\n\n      <ion-col size=\"2\">\n        <ion-button (click)=\"minus(item)\">-</ion-button>\n      </ion-col>\n\n      <ion-col size=\"2\">\n        <div class=\"count\">\n          <p>{{item.count}}</p>\n        </div>\n      </ion-col>\n      <ion-col size=\"4\">\n        <p class=\"extra\">{{item.Name}}<br>\n          <span *ngIf=\"langId != 1\">{{LE}} {{item.Price}}</span>\n          <span *ngIf=\"langId == 1\">{{item.Price}} {{LE}}</span>\n        </p>\n      </ion-col>\n      <ion-col size=\"2\">\n        <img src=\"{{item.Image}}\">\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <h5>{{Modfires}}</h5>\n  <ion-grid>\n    <ion-row class=\"addSouce\" *ngFor=\"let item of modfiresArr\">\n      <ion-col size=\"2\">\n        <ion-button (click)=\"plus(item)\">+</ion-button>\n      </ion-col>\n\n      <ion-col size=\"2\">\n        <ion-button (click)=\"minus(item)\">-</ion-button>\n      </ion-col>\n\n      <ion-col size=\"2\">\n        <div class=\"count\">\n          <p>{{item.count}}</p>\n        </div>\n      </ion-col>\n      <ion-col size=\"4\">\n        <p class=\"extra\">{{item.Name}}<br>\n          <span *ngIf=\"langId != 1\">{{LE}} {{item.Price}}</span>\n          <span *ngIf=\"langId == 1\">{{item.Price}} {{LE}}</span>\n        </p>\n      </ion-col>\n      <ion-col size=\"2\">\n        <img src=\"{{item.Image}}\">\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n  <div class=\"footer\" dir=\"ltr\">\n    <div>\n      <ion-button (click)=\"goBack()\">{{Cancel}}</ion-button>\n      <ion-button (click)=\"save()\">{{addChange}}</ion-button>\n    </div>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_edit-customiz_edit-customiz_module_ts.js.map