"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_suggestions_suggestions_module_ts"],{

/***/ 5676:
/*!*****************************************************************!*\
  !*** ./src/app/pages/suggestions/suggestions-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SuggestionsPageRoutingModule": () => (/* binding */ SuggestionsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _suggestions_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./suggestions.page */ 2473);




const routes = [
    {
        path: '',
        component: _suggestions_page__WEBPACK_IMPORTED_MODULE_0__.SuggestionsPage
    }
];
let SuggestionsPageRoutingModule = class SuggestionsPageRoutingModule {
};
SuggestionsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SuggestionsPageRoutingModule);



/***/ }),

/***/ 426:
/*!*********************************************************!*\
  !*** ./src/app/pages/suggestions/suggestions.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SuggestionsPageModule": () => (/* binding */ SuggestionsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _suggestions_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./suggestions-routing.module */ 5676);
/* harmony import */ var _suggestions_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./suggestions.page */ 2473);







let SuggestionsPageModule = class SuggestionsPageModule {
};
SuggestionsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _suggestions_routing_module__WEBPACK_IMPORTED_MODULE_0__.SuggestionsPageRoutingModule
        ],
        declarations: [_suggestions_page__WEBPACK_IMPORTED_MODULE_1__.SuggestionsPage]
    })
], SuggestionsPageModule);



/***/ }),

/***/ 2473:
/*!*******************************************************!*\
  !*** ./src/app/pages/suggestions/suggestions.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SuggestionsPage": () => (/* binding */ SuggestionsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _suggestions_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./suggestions.page.html?ngResource */ 8718);
/* harmony import */ var _suggestions_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./suggestions.page.scss?ngResource */ 6637);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);







let SuggestionsPage = class SuggestionsPage {
    constructor(rest, route, navCtr) {
        this.rest = rest;
        this.route = route;
        this.navCtr = navCtr;
        this.mostSellingArr = [];
    }
    ngOnInit() {
        this.langId = sessionStorage.getItem("lang");
        if (this.langId == '1') {
            this.Suggestions = "الاقتراحات";
            this.Back = "رجوع";
            this.Thanks = "شكرا";
        }
        else {
            this.Suggestions = 'Suggestions';
            this.Back = "Back";
            this.Thanks = "No Thanks";
        }
        this.getMostSelling();
    }
    getMostSelling() {
        this.rest.mostSelling(this.langId).subscribe((res) => {
            console.log(res);
            this.mostSellingArr = res;
            for (let i = 0; i < this.mostSellingArr.length; i++) {
                if (i == 2 || i == 5 || i == 8 || i == 11) {
                    this.mostSellingArr[i].status = true;
                }
                else {
                    this.mostSellingArr[i].status = false;
                }
            }
        });
    }
    goBack() {
        this.route.navigateByUrl('/home');
    }
    noThanks() {
        this.route.navigateByUrl("/main_menu");
    }
    goToOeder(item) {
        this.route.navigateByUrl("/main_menu");
    }
};
SuggestionsPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController }
];
SuggestionsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-suggestions',
        template: _suggestions_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_suggestions_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SuggestionsPage);



/***/ }),

/***/ 6637:
/*!********************************************************************!*\
  !*** ./src/app/pages/suggestions/suggestions.page.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background:#fff ;\n  --color: black ;\n}\n\nion-button {\n  --background: #e1e1e1;\n  --color: black;\n  text-transform: none;\n}\n\n.imgProduct {\n  width: 100%;\n}\n\n.cover {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  top: 0;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #000;\n}\n\n.cover h1 {\n  font-weight: bold;\n  margin-top: 10%;\n}\n\n.back {\n  text-align: right;\n  text-transform: none;\n  margin-top: 5px;\n}\n\n.back ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  height: 30px;\n  --border-radius:5px;\n}\n\n.products {\n  height: 60vh;\n  overflow-y: scroll;\n  text-align: center;\n  padding: 0 10%;\n}\n\n.products img {\n  width: 50px;\n}\n\n.products .price {\n  text-align: left;\n  font-size: 11px;\n}\n\n.products .name {\n  font-size: 14px;\n}\n\n.products .rowOne {\n  border-bottom: 1px solid #d9d9d9;\n}\n\n.colOne {\n  border-right: 1px solid #d9d9d9;\n}\n\n.noThanks {\n  text-align: center;\n  position: absolute;\n  bottom: 5px;\n  left: 31%;\n}\n\n.noThanks ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  height: 40px;\n  --border-radius:5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1Z2dlc3Rpb25zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtBQUNKOztBQUNBO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0VBQ0Esb0JBQUE7QUFFRjs7QUFDRTtFQUNFLFdBQUE7QUFFSjs7QUFDRTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxNQUFBO0VBQ0EscUNBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUFFSjs7QUFBRTtFQUNJLGlCQUFBO0VBQ0EsZUFBQTtBQUdOOztBQURFO0VBQ0UsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLGVBQUE7QUFJSjs7QUFGRTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFLSjs7QUFGRTtFQUNFLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQUtKOztBQUhFO0VBQ0ksV0FBQTtBQU1OOztBQUpFO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0FBT047O0FBTEU7RUFDSSxlQUFBO0FBUU47O0FBTkU7RUFDSSxnQ0FBQTtBQVNOOztBQVBFO0VBQ0ksK0JBQUE7QUFVTjs7QUFQRTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtBQVVKOztBQVBFO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQVVKIiwiZmlsZSI6InN1Z2dlc3Rpb25zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xuICAgIC0tYmFja2dyb3VuZDojZmZmIDtcbiAgICAtLWNvbG9yOiBibGFja1xufVxuaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogI2UxZTFlMTtcbiAgLS1jb2xvcjogYmxhY2s7IFxuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbn1cblxuICAuaW1nUHJvZHVjdHtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxuXG4gIC5jb3ZlciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICB0b3A6IDA7XG4gICAgYmFja2dyb3VuZDogcmdiKDI1NSAyNTUgMjU1IC8gNzklKTs7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwXG4gIH1cbiAgLmNvdmVyIGgxIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgbWFyZ2luLXRvcDogMTAlXG4gIH1cbiAgLmJhY2sge1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICAgIG1hcmdpbi10b3A6IDVweDtcbiAgfVxuICAuYmFjayBpb24tYnV0dG9ue1xuICAgIC0tcGFkZGluZy1zdGFydDogMmVtO1xuICAgIC0tcGFkZGluZy1lbmQ6IDJlbTtcbiAgICBoZWlnaHQ6IDMwcHg7XG4gICAgLS1ib3JkZXItcmFkaXVzOjVweDtcbiAgfVxuXG4gIC5wcm9kdWN0c3tcbiAgICBoZWlnaHQ6IDYwdmg7XG4gICAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwYWRkaW5nOiAwIDEwJVxuICB9XG4gIC5wcm9kdWN0cyBpbWcge1xuICAgICAgd2lkdGg6IDUwcHhcbiAgfVxuICAucHJvZHVjdHMgLnByaWNle1xuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICAgIGZvbnQtc2l6ZTogMTFweFxuICB9XG4gIC5wcm9kdWN0cyAubmFtZXtcbiAgICAgIGZvbnQtc2l6ZTogMTRweFxuICB9XG4gIC5wcm9kdWN0cyAucm93T25le1xuICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkOWQ5ZDk7XG4gIH1cbiAgLmNvbE9uZXtcbiAgICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNkOWQ5ZDk7XG4gIH1cblxuICAubm9UaGFua3N7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBib3R0b206NXB4O1xuICAgIGxlZnQ6IDMxJTtcblxuICB9XG4gIC5ub1RoYW5rcyBpb24tYnV0dG9ue1xuICAgIC0tcGFkZGluZy1zdGFydDogMmVtO1xuICAgIC0tcGFkZGluZy1lbmQ6IDJlbTtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgLS1ib3JkZXItcmFkaXVzOjVweDtcbiAgfSJdfQ== */";

/***/ }),

/***/ 8718:
/*!********************************************************************!*\
  !*** ./src/app/pages/suggestions/suggestions.page.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <div>\n    <img class=\"imgProduct\" src=\"assets/images/panner.jpeg\">\n  </div>\n  <div class=\"cover\">\n    <h1>{{Suggestions}}</h1>\n  </div>\n</ion-header>\n\n<ion-content class=\"ion-padding-start ion-padding-end\">\n  <div (click)=\"goBack()\" class=\"back\">\n    <ion-button>{{Back}}</ion-button>\n  </div>\n\n  <div class=\"products\">\n    <ion-grid>\n      <ion-row >\n        <ion-col size=\"4\" class=\"rowOne\" (click)=\"goToOeder(item)\"\n        [ngClass]=\"{'colOne':item.status == false}\"\n         *ngFor=\"let item of mostSellingArr ; let i = index\">\n          <p class=\"price\">LE {{item.Price}}</p>\n          <img src=\"{{item.Image}}\">\n          <p class=\"name\">{{item.Name}}</p>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n  <div class=\"noThanks\" (click)=\"noThanks()\">\n    <ion-button>{{Thanks}}</ion-button>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_suggestions_suggestions_module_ts.js.map