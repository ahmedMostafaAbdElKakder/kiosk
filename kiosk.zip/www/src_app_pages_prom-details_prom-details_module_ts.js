"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_prom-details_prom-details_module_ts"],{

/***/ 2591:
/*!*******************************************************************!*\
  !*** ./src/app/pages/prom-details/prom-details-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PromDetailsPageRoutingModule": () => (/* binding */ PromDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _prom_details_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./prom-details.page */ 3396);




const routes = [
    {
        path: '',
        component: _prom_details_page__WEBPACK_IMPORTED_MODULE_0__.PromDetailsPage
    }
];
let PromDetailsPageRoutingModule = class PromDetailsPageRoutingModule {
};
PromDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PromDetailsPageRoutingModule);



/***/ }),

/***/ 126:
/*!***********************************************************!*\
  !*** ./src/app/pages/prom-details/prom-details.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PromDetailsPageModule": () => (/* binding */ PromDetailsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _prom_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./prom-details-routing.module */ 2591);
/* harmony import */ var _prom_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./prom-details.page */ 3396);







let PromDetailsPageModule = class PromDetailsPageModule {
};
PromDetailsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _prom_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.PromDetailsPageRoutingModule
        ],
        declarations: [_prom_details_page__WEBPACK_IMPORTED_MODULE_1__.PromDetailsPage]
    })
], PromDetailsPageModule);



/***/ }),

/***/ 3396:
/*!*********************************************************!*\
  !*** ./src/app/pages/prom-details/prom-details.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PromDetailsPage": () => (/* binding */ PromDetailsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _prom_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./prom-details.page.html?ngResource */ 6141);
/* harmony import */ var _prom_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./prom-details.page.scss?ngResource */ 6306);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);






let PromDetailsPage = class PromDetailsPage {
    constructor(rest, route) {
        this.rest = rest;
        this.route = route;
        this.items = [];
        this.showModfire = false;
        this.ModifiresbyProductId = [];
        this.disalbedButton = true;
        this.categoris = [];
    }
    ngOnInit() {
        this.langId = localStorage.getItem('lang');
        if (this.langId == '1') {
            this.dir = "rtl";
            this.Menu = "قائمة الطلبات";
            this.Back = "رجوع";
            this.Cancel = "إلغاء الطلب";
            this.OrderDone = "دفع";
            this.MyOrder = "طلباتي - في المتجر";
            this.Modfires = "الاضافات";
            this.Next = "التالي";
            this.bestSelling = "افضل المنتجات";
            this.discount = "الخصومات";
            this.promotions = "العروض";
            this.LE = "جنيه";
        }
        else {
            this.dir = "ltr";
            this.Menu = "Main Menu";
            this.Back = "Back";
            this.Cancel = "Cancel Order";
            this.OrderDone = "Done";
            this.MyOrder = "My Order - In Shop";
            this.Modfires = "Modfires";
            this.Next = "Next";
            this.bestSelling = "Best Selling";
            this.discount = "Discount";
            this.promotions = "Promotion";
            this.LE = "LE";
        }
        this.getData();
        this.getCategoris();
        this.ifArrOfModfier();
    }
    getData() {
        this.categoriObj = JSON.parse(sessionStorage.getItem('promotions'));
        console.log(this.categoriObj);
        this.nameOfCat = this.categoriObj.PromotionName;
        this.items = this.categoriObj.Products;
        for (let i = 0; i < this.items.length; i++) {
            if (i == 2 || i == 5 || i == 8 || i == 11) {
                this.items[i].status = true;
            }
            else {
                this.items[i].status = false;
            }
        }
    }
    getCategoris() {
        this.rest.getCategoriWithProduct(this.langId).subscribe((res) => {
            console.log(res);
            this.categoris = res.categoriesProducts;
            for (let i = 0; i < this.categoris.length; i++) {
                if (i == 2 || i == 5 || i == 8 || i == 11) {
                    this.categoris[i].status = true;
                }
                else {
                    this.categoris[i].status = false;
                }
            }
        });
    }
    GetModifiresbyProductId(item, id) {
        this.idOfIngrdtiont = id;
        sessionStorage.setItem('ProductOfChose', JSON.stringify(item));
        this.price = item.Price;
        this.rest.GetModifiresbyProductId(id, this.langId).subscribe((res) => {
            console.log(res);
            if (res.length == 0) {
                let arr = [];
                sessionStorage.setItem('modfiresArr', JSON.stringify(arr));
                // this.route.navigateByUrl('/add-modfires')
            }
            else {
                sessionStorage.setItem('modfiresArr', JSON.stringify(res));
            }
            this.rest.GetItemsbyProductId(this.langId, id).subscribe((res) => {
                let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
                if (res.length == 0) {
                    console.log("hamdaaaa");
                    let item = {};
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('IngrdDub', JSON.stringify([]));
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    let item = {};
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('IngrdDub', JSON.stringify(res));
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                    // this.gotToDetails('normal')
                }
            });
        });
    }
    close() {
        this.showModfire = false;
    }
    ifArrOfModfier() {
        let arrOfMod = JSON.parse(sessionStorage.getItem('arrOfModfire'));
        if (arrOfMod) {
            this.disalbedButton = false;
            if (this.langId == '1') {
                this.arrOfModLength = "إجمالي المنتجات" + " " + `(${arrOfMod.length})`;
            }
            else {
                this.arrOfModLength = "Total Items" + " " + `(${arrOfMod.length})`;
            }
        }
        else {
            this.disalbedButton = true;
            if (this.langId == '1') {
                this.arrOfModLength = "لا يوجد طلبات";
            }
            else {
                this.arrOfModLength = "You Order is Empty";
            }
        }
    }
    gotToItems(item) {
        if (item == 'Discount') {
            this.rest.gitDiscount(this.langId).subscribe((res) => {
                console.log(res);
                let obj = {
                    Name: 'Discount',
                    Products: res
                };
                sessionStorage.setItem('obj', JSON.stringify(obj));
                this.route.navigateByUrl('/discount');
            });
        }
        else {
            sessionStorage.setItem('obj', JSON.stringify(item));
            this.route.navigateByUrl('/categoris');
        }
    }
    // gotToDetails(item) {
    //   if(item == "normal"){
    //     this.route.navigateByUrl('/add-souce')
    //     let empty = {}
    //     sessionStorage.setItem('ModfireOfChose', JSON.stringify(empty))
    //     sessionStorage.setItem("ifModFire",'false')
    //   }else {
    //     sessionStorage.setItem('ModfireOfChose', JSON.stringify(item))
    //     this.route.navigateByUrl('/add-souce')
    //   }
    // }
    gotToDetails(item) {
        if (item == "normal") {
            let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
            this.rest.GetItemsbyProductId(this.langId, this.idOfIngrdtiont).subscribe((res) => {
                if (res.length == 0) {
                    let item = {};
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    let item = {};
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/add-souce');
                }
            });
            sessionStorage.setItem("ifModFire", 'false');
        }
        else if (item == 'Discount') {
            this.rest.gitDiscount(this.langId).subscribe((res) => {
                console.log(res);
                let obj = {
                    Name: 'Discount',
                    Products: res
                };
                sessionStorage.setItem('obj', JSON.stringify(obj));
                this.route.navigateByUrl('/discount');
            });
        }
        else {
            console.log("asdasdsa", item);
            this.rest.GetItemsbyProductId(this.langId, this.idOfIngrdtiont).subscribe((res) => {
                if (res.length == 0) {
                    let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/add-souce');
                }
            });
        }
    }
    ChoseCategori(item) {
        sessionStorage.setItem("obj", JSON.stringify(item));
        this.route.navigateByUrl('/categoris');
    }
    goBack() {
        this.route.navigateByUrl('/promtions');
    }
    cancelOrder() {
        sessionStorage.clear();
        this.route.navigateByUrl('/suggestions');
    }
    Done() {
        this.route.navigateByUrl('/review');
    }
};
PromDetailsPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
PromDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-prom-details',
        template: _prom_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_prom_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PromDetailsPage);



/***/ }),

/***/ 6306:
/*!**********************************************************************!*\
  !*** ./src/app/pages/prom-details/prom-details.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcef50;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: #000;\n  text-transform: none;\n  width: 250px;\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius: 5px;\n  font-size: 5vw;\n  height: 100px;\n}\n\n.nameOfPrdocuct {\n  font-size: 3rem;\n}\n\nion-content {\n  --background:#fff ;\n  --color: black ;\n}\n\n.cover {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  left: 0%;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #fff;\n  top: 0;\n}\n\n.cover2 {\n  position: absolute;\n  width: 100%;\n  height: 27vh;\n  top: 0;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #000;\n}\n\n.cover h1 {\n  font-weight: bold;\n  margin-top: 12%;\n  font-size: 5vw;\n  color: black;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.back p {\n  font-weight: bold;\n  font-size: 5vw;\n}\n\n.back ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 2%;\n  font-size: 5vw;\n  height: auto;\n  margin-bottom: 5%;\n  height: 100px;\n}\n\n.products {\n  text-align: center;\n}\n\n.products .price {\n  text-align: left;\n  font-size: 11px;\n  margin: 0;\n}\n\n.products .name {\n  font-size: 0.8rem;\n  margin-bottom: 5px;\n  margin-top: 0;\n  font-weight: bold;\n}\n\n.products .rowOne {\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.colOne {\n  border-right: 1px solid #c2c2c2;\n}\n\n.menuItem {\n  padding: 30px 0;\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.menuItem p {\n  margin: 0;\n  font-size: 0.5rem;\n  text-align: center;\n  font-weight: bold;\n  font-size: 3vw;\n}\n\n.menuItem img {\n  height: 150px;\n}\n\n.price_name {\n  display: flex;\n  justify-content: space-between;\n  font-size: 10px;\n  margin-top: 10px;\n  font-size: 3vw;\n}\n\n.myOrder {\n  background: #E1E1E1;\n  padding: 5px 10px;\n}\n\n.myOrder h4 {\n  margin: 0;\n  font-size: 5vw;\n  color: black;\n}\n\n.confirmOrCancel {\n  display: flex;\n  justify-content: space-around;\n}\n\n.confirmOrCancel ion-button {\n  width: 33%;\n}\n\n.foter p {\n  text-align: center;\n  font-size: 5vw;\n}\n\n.footer {\n  position: absolute;\n  width: 100%;\n  bottom: 8px;\n}\n\n.recmoended p {\n  margin: 0;\n  font-size: 5vw;\n}\n\n.menu {\n  overflow-y: scroll;\n  border-radius: 5px;\n  margin-top: -17%;\n  background: #f0f0f0;\n  height: 72vh;\n  text-align: center;\n}\n\n.menu div {\n  border-bottom: 1px solid gray;\n}\n\n.menu .mainMenu {\n  font-size: 3rem;\n  font-weight: bold;\n  margin-top: 50%;\n}\n\n.products {\n  height: 52vh;\n  overflow-y: scroll;\n  padding-bottom: 10px;\n}\n\n.products img {\n  height: 150px;\n}\n\n.ifClick {\n  height: 19vh !important;\n}\n\n.recmoended ion-button {\n  --background: #E1E1E1;\n  font-size: 5vw;\n  height: auto;\n}\n\n.Modfires {\n  display: flex;\n  justify-content: space-between;\n}\n\n.Modfires h1 {\n  margin-top: 8px;\n  padding-left: 5px;\n  font-size: 7vw;\n}\n\n.confirmOrCancel ion-button {\n  font-size: 4vw;\n  height: 112px;\n}\n\n.next {\n  position: absolute;\n  bottom: 29%;\n  height: 100px !important;\n  left: 14px;\n  --background: rgb(252, 180, 0)!important;\n  color: #000;\n}\n\n@media only screen and (max-width: 768px) {\n  ion-button {\n    font-size: 1rem;\n    height: 50px;\n    width: auto;\n    margin-top: 1%;\n  }\n\n  .nameOfPrdocuct {\n    font-size: 1rem;\n  }\n\n  .imgProduct {\n    height: 71px;\n  }\n\n  .menu {\n    height: 67vh;\n    margin-top: -19%;\n  }\n\n  .menuItem {\n    padding: 12px 0;\n  }\n\n  .menuItem img {\n    height: 50px;\n    width: auto;\n  }\n\n  .back ion-button {\n    height: 36px;\n  }\n\n  .menu .mainMenu {\n    font-size: 13px;\n  }\n\n  .products img {\n    width: auto;\n    height: 90px;\n  }\n\n  .confirmOrCancel ion-button {\n    height: 44px;\n  }\n\n  .ifClick {\n    height: 10vh !important;\n  }\n\n  .cover2 {\n    height: 30vh;\n  }\n\n  .next {\n    height: 36px !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb20tZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0FBQUo7O0FBRUE7RUFDSSxxQkFBQTtFQUNBLGFBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQUNKOztBQUNFO0VBQ0ksZUFBQTtBQUVOOztBQUFFO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0FBR0o7O0FBQUU7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsUUFBQTtFQUNBLHFDQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsTUFBQTtBQUdKOztBQURFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLE1BQUE7RUFDQSxxQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQUlKOztBQUZFO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFLTjs7QUFIRTtFQUNFLGlCQUFBO0FBTUo7O0FBSkU7RUFDRSxnQkFBQTtBQU9KOztBQUxFO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0FBUU47O0FBTkU7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7QUFTSjs7QUFQRTtFQUNFLGtCQUFBO0FBVUo7O0FBUkE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxTQUFBO0FBV0o7O0FBVEE7RUFDSSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0FBWUo7O0FBVkE7RUFDSSxnQ0FBQTtBQWFKOztBQVhBO0VBQ0ksK0JBQUE7QUFjSjs7QUFaQTtFQUNJLGVBQUE7RUFDQSxnQ0FBQTtBQWVKOztBQVpBO0VBQ0ksU0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFlSjs7QUFaQTtFQUNJLGFBQUE7QUFlSjs7QUFiQTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFnQko7O0FBZEE7RUFDSSxtQkFBQTtFQUNBLGlCQUFBO0FBaUJKOztBQWZBO0VBQ0ksU0FBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FBa0JKOztBQWZBO0VBQ0ksYUFBQTtFQUNBLDZCQUFBO0FBa0JKOztBQWhCQTtFQUNJLFVBQUE7QUFtQko7O0FBakJBO0VBQ0ksa0JBQUE7RUFDQSxjQUFBO0FBb0JKOztBQWpCQTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7QUFvQko7O0FBbEJBO0VBQ0ksU0FBQTtFQUNBLGNBQUE7QUFxQko7O0FBakJBO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFvQko7O0FBbEJBO0VBQ0ksNkJBQUE7QUFxQko7O0FBbkJBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQXNCSjs7QUFwQkE7RUFDSSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQkFBQTtBQXVCSjs7QUFyQkE7RUFDSSxhQUFBO0FBd0JKOztBQXJCQTtFQUNJLHVCQUFBO0FBd0JKOztBQXJCQTtFQUNHLHFCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUF3Qkg7O0FBckJBO0VBQ0MsYUFBQTtFQUNBLDhCQUFBO0FBd0JEOztBQXJCQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUF3Qko7O0FBdEJBO0VBQ0ksY0FBQTtFQUNBLGFBQUE7QUF5Qko7O0FBdkJBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0Esd0JBQUE7RUFDQSxVQUFBO0VBQ0Esd0NBQUE7RUFDQSxXQUFBO0FBMEJKOztBQWhCQTtFQUNJO0lBQ0ksZUFBQTtJQUNBLFlBQUE7SUFDQSxXQUFBO0lBQ0EsY0FBQTtFQW1CTjs7RUFqQkU7SUFDSSxlQUFBO0VBb0JOOztFQWxCRTtJQUNJLFlBQUE7RUFxQk47O0VBbkJFO0lBQ0ksWUFBQTtJQUNBLGdCQUFBO0VBc0JOOztFQXBCRTtJQUNJLGVBQUE7RUF1Qk47O0VBckJFO0lBQ0ksWUFBQTtJQUNBLFdBQUE7RUF3Qk47O0VBdEJFO0lBQ0ksWUFBQTtFQXlCTjs7RUF2QkU7SUFDSSxlQUFBO0VBMEJOOztFQXhCRTtJQUNJLFdBQUE7SUFDQSxZQUFBO0VBMkJOOztFQXhCRTtJQUNFLFlBQUE7RUEyQko7O0VBekJFO0lBQ0ksdUJBQUE7RUE0Qk47O0VBMUJFO0lBQ0ksWUFBQTtFQTZCTjs7RUEzQkU7SUFDSSx1QkFBQTtFQThCTjtBQUNGIiwiZmlsZSI6InByb20tZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi5oZWFkZXJ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGJhY2tncm91bmQ6ICNmY2VmNTBcbn1cbmlvbi1idXR0b24ge1xuICAgIC0tYmFja2dyb3VuZDogI0UxRTFFMTtcbiAgICAtLWNvbG9yOiAjMDAwO1xuICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICAgIHdpZHRoOiAyNTBweDtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDJlbTtcbiAgICAtLXBhZGRpbmctZW5kOiAyZW07XG4gICAgLS1ib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgZm9udC1zaXplOiA1dnc7XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgfVxuICAubmFtZU9mUHJkb2N1Y3R7XG4gICAgICBmb250LXNpemU6IDNyZW1cbiAgfVxuICBpb24tY29udGVudHtcbiAgICAtLWJhY2tncm91bmQ6I2ZmZiA7XG4gICAgLS1jb2xvcjogYmxhY2tcbn1cblxuICAuY292ZXIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbGVmdDogMCU7XG4gICAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjc5KTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgdG9wOiAwXG4gIH1cbiAgLmNvdmVyMiB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDoyN3ZoO1xuICAgIHRvcDogMDtcbiAgICBiYWNrZ3JvdW5kOiByZ2IoMjU1IDI1NSAyNTUgLyA3OSUpOztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDBcbiAgfVxuICAuY292ZXIgaDEge1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICBtYXJnaW4tdG9wOiAxMiU7XG4gICAgICBmb250LXNpemU6IDV2dztcbiAgICAgIGNvbG9yOiBibGFja1xuICB9XG4gIC5iYWNrIHtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgfVxuICAuYmFja0lmUmlnaHR7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgfVxuICAuYmFjayBwIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgZm9udC1zaXplOiA1dnc7XG4gIH1cbiAgLmJhY2sgaW9uLWJ1dHRvbntcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDJlbTtcbiAgICAtLXBhZGRpbmctZW5kOiAyZW07XG4gICAgLS1ib3JkZXItcmFkaXVzOjVweDtcbiAgICBtYXJnaW4tdG9wOiAyJTtcbiAgICBmb250LXNpemU6IDV2dztcbiAgICBoZWlnaHQ6IGF1dG87XG4gICAgbWFyZ2luLWJvdHRvbTogNSU7XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgfVxuICAucHJvZHVjdHN7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLnByb2R1Y3RzIC5wcmljZXtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtc2l6ZTogMTFweDtcbiAgICBtYXJnaW46IDBcbn1cbi5wcm9kdWN0cyAubmFtZXtcbiAgICBmb250LXNpemU6IC44cmVtO1xuICAgIG1hcmdpbi1ib3R0b206NXB4O1xuICAgIG1hcmdpbi10b3A6IDA7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGRcbn1cbi5wcm9kdWN0cyAucm93T25le1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjYzJjMmMyO1xufVxuLmNvbE9uZXtcbiAgICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjYzJjMmMyO1xufVxuLm1lbnVJdGVte1xuICAgIHBhZGRpbmc6IDMwcHggMDtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2MyYzJjMjtcblxufVxuLm1lbnVJdGVtIHB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGZvbnQtc2l6ZTogLjVyZW07XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc2l6ZTogM3Z3O1xuXG59XG4ubWVudUl0ZW0gaW1nIHtcbiAgICBoZWlnaHQ6IDE1MHB4O1xufVxuLnByaWNlX25hbWV7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgZm9udC1zaXplOiAxMHB4O1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgZm9udC1zaXplOiAzdndcbn1cbi5teU9yZGVye1xuICAgIGJhY2tncm91bmQ6ICNFMUUxRTE7XG4gICAgcGFkZGluZyA6NXB4IDEwcHhcbn1cbi5teU9yZGVyIGg0IHtcbiAgICBtYXJnaW46IDA7XG4gICAgZm9udC1zaXplOiA1dnc7XG4gICAgY29sb3I6IGJsYWNrXG59XG5cbi5jb25maXJtT3JDYW5jZWx7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbn1cbi5jb25maXJtT3JDYW5jZWwgaW9uLWJ1dHRvbntcbiAgICB3aWR0aDogMzMlO1xufVxuLmZvdGVyIHAge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDV2dztcbn1cblxuLmZvb3RlciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJvdHRvbTo4cHg7XG59XG4ucmVjbW9lbmRlZCBwe1xuICAgIG1hcmdpbjogMDtcbiAgICBmb250LXNpemU6IDV2dztcblxufVxuXG4ubWVudXtcbiAgICBvdmVyZmxvdy15OiBzY3JvbGw7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIG1hcmdpbi10b3A6IC0xNyU7XG4gICAgYmFja2dyb3VuZDogI2YwZjBmMDtcbiAgICBoZWlnaHQ6IDcydmg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLm1lbnUgZGl2IHtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgZ3JheTtcbn1cbi5tZW51IC5tYWluTWVudXtcbiAgICBmb250LXNpemU6IDNyZW07XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgbWFyZ2luLXRvcDogNTAlO1xufVxuLnByb2R1Y3Rze1xuICAgIGhlaWdodDogNTJ2aDtcbiAgICBvdmVyZmxvdy15OiBzY3JvbGw7XG4gICAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG4ucHJvZHVjdHMgaW1nIHtcbiAgICBoZWlnaHQ6IDE1MHB4O1xufVxuXG4uaWZDbGlja3tcbiAgICBoZWlnaHQ6MTl2aCAhaW1wb3J0YW50O1xufVxuXG4ucmVjbW9lbmRlZCBpb24tYnV0dG9ue1xuICAgLS1iYWNrZ3JvdW5kOiAjRTFFMUUxO1xuICAgZm9udC1zaXplOiA1dnc7XG4gICBoZWlnaHQ6IGF1dG87O1xuICAgXG59XG4uTW9kZmlyZXN7XG4gZGlzcGxheTogZmxleDtcbiBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW5cbn1cblxuLk1vZGZpcmVzIGgxIHtcbiAgICBtYXJnaW4tdG9wOiA4cHg7XG4gICAgcGFkZGluZy1sZWZ0OiA1cHg7XG4gICAgZm9udC1zaXplOiA3dnc7XG59XG4uY29uZmlybU9yQ2FuY2VsIGlvbi1idXR0b257XG4gICAgZm9udC1zaXplOiA0dnc7XG4gICAgaGVpZ2h0OiAxMTJweDtcbn1cbi5uZXh0IHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgYm90dG9tOiAyOSU7XG4gICAgaGVpZ2h0OiAxMDBweCAhaW1wb3J0YW50O1xuICAgIGxlZnQ6IDE0cHg7XG4gICAgLS1iYWNrZ3JvdW5kOiByZ2IoMjUyLCAxODAsIDApIWltcG9ydGFudDtcbiAgICBjb2xvcjogIzAwMFxufVxuLy8gLm5leHRNb2RmaXJlIHtcbi8vICAgICBoZWlnaHQ6IDEwMHB4O1xuLy8gfVxuLy8gLm5leHRNb2RmaXJlIGlvbi1idXR0b257XG4vLyAgICAgLS1iYWNrZ3JvdW5kOiAjYzJjMmMyO1xuLy8gICAgIGhlaWdodDogMTAwJTtcbi8vIH1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjc2OHB4KXtcbiAgICBpb24tYnV0dG9ue1xuICAgICAgICBmb250LXNpemU6IDFyZW07XG4gICAgICAgIGhlaWdodDogNTBweDtcbiAgICAgICAgd2lkdGg6IGF1dG87XG4gICAgICAgIG1hcmdpbi10b3A6IDElO1xuICAgIH1cbiAgICAubmFtZU9mUHJkb2N1Y3Qge1xuICAgICAgICBmb250LXNpemU6IDFyZW07XG4gICAgfVxuICAgIC5pbWdQcm9kdWN0e1xuICAgICAgICBoZWlnaHQ6IDcxcHg7XG4gICAgfVxuICAgIC5tZW51IHtcbiAgICAgICAgaGVpZ2h0OiA2N3ZoO1xuICAgICAgICBtYXJnaW4tdG9wOiAtMTklO1xuICAgIH1cbiAgICAubWVudUl0ZW17XG4gICAgICAgIHBhZGRpbmc6IDEycHggMDtcbiAgICB9XG4gICAgLm1lbnVJdGVtIGltZyB7XG4gICAgICAgIGhlaWdodDogNTBweDtcbiAgICAgICAgd2lkdGg6IGF1dG9cbiAgICB9XG4gICAgLmJhY2sgaW9uLWJ1dHRvbntcbiAgICAgICAgaGVpZ2h0OiAzNnB4O1xuICAgIH1cbiAgICAubWVudSAubWFpbk1lbnV7XG4gICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICB9XG4gICAgLnByb2R1Y3RzIGltZ3tcbiAgICAgICAgd2lkdGg6IGF1dG87XG4gICAgICAgIGhlaWdodDogOTBweDtcbiAgICAgICAgXG4gICAgfVxuICAgIC5jb25maXJtT3JDYW5jZWwgaW9uLWJ1dHRvbntcbiAgICAgIGhlaWdodDogNDRweDtcbiAgICB9XG4gICAgLmlmQ2xpY2t7XG4gICAgICAgIGhlaWdodDoxMHZoICFpbXBvcnRhbnQ7XG4gICAgfVxuICAgIC5jb3ZlcjJ7XG4gICAgICAgIGhlaWdodDogMzB2aDtcbiAgICB9XG4gICAgLm5leHQge1xuICAgICAgICBoZWlnaHQ6IDM2cHggIWltcG9ydGFudDtcbiAgICB9XG4gIH0iXX0= */";

/***/ }),

/***/ 6141:
/*!**********************************************************************!*\
  !*** ./src/app/pages/prom-details/prom-details.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <div>\n    <img class=\"imgProduct\" src=\"assets/images/panner.jpeg\">\n  </div>\n  <div class=\"cover\">\n    <h1>{{nameOfCat}}</h1>\n  </div>\n</ion-header> -->\n<div class=\"header\">\n  <img class=\"imgProduct \" src=\"assets/images/bingo.png\">\n</div>\n\n<ion-content [dir]=\"dir\">\n  <div class=\"\">\n    <div class=\"back\" [ngClass]=\"{'back':dir == 'ltr', 'backIfRight':dir == 'rtl'}\">\n      <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n    </div>\n\n    <ion-grid class=\"Content\">\n      <ion-row style=\"padding: 0\">\n        <ion-col class=\"menu\" [ngClass]=\"{'ifClick':showModfire}\" size=\"3\">\n          <p class=\"mainMenu\">{{Menu}}</p>\n          <div>\n            <!-- <div class=\"menuItem\">\n              <img src=\"assets/images/mostSelling.png\">\n              <p>{{bestSelling}}</p>\n            </div> -->\n            <div class=\"menuItem\" (click)=\"gotToItems('Discount')\">\n              <img src=\"assets/images/discount.png\">\n              <p>{{discount}}</p>\n            </div>\n            <div class=\"menuItem\" routerLink=\"/promtions\">\n              <img src=\"assets/images/promotion.png\">\n              <p>{{promotions}}</p>\n            </div>\n            <div *ngFor=\"let item of categoris\" class=\"menuItem\" (click)=\"ChoseCategori(item)\">\n              <img src=\"{{item.Image}}\">\n              <p>{{item.Name}}</p>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col>\n          <div class=\"products\" [ngClass]=\"{'ifClick':showModfire}\">\n            <ion-grid>\n              <ion-row>\n                <ion-col size=\"6\" class=\"rowOne colOne\" (click)=\"GetModifiresbyProductId(item,item.Id)\"\n                  *ngFor=\"let item of items ; let i = index\">\n                  <!-- <p class=\"price_name\">\n                    {{LE}} {{item.NewPrice}}\n                  </p> -->\n                  <div class=\"price_name\">\n                    <p class=\"after\" style=\"color: red\">\n                      {{Befor}}\n                      <br>\n                      <span><s>{{LE}} {{item.Price}}</s></span>\n                    </p>\n                    <p class=\"befor\">\n                      {{After}}\n                      <br>\n                      <span>{{LE}} {{item.NewPrice}}</span>\n                    </p>\n                  </div>\n                  <img src=\"{{item.Image}}\">\n                  <p class=\"nameOfPrdocuct\">{{item.Name}}</p>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <div [ngClass]=\"{'cover2':showModfire}\"></div>\n  </div>\n\n\n  <section class=\"recmoended\" *ngIf=\"showModfire\">\n    <div class=\"Modfires\">\n      <h1>{{Modfires}}</h1>\n      <ion-button (click)=\"close()\">{{Back}}</ion-button>\n    </div>\n\n    <ion-grid>\n      <ion-row>\n        <ion-col (click)=\"gotToDetails(item)\" *ngFor=\"let item of ModifiresbyProductId ; let i = index\" size=\"3\">\n          <p class=\"price\">LE {{item.Price}}</p>\n          <img src=\"{{item.Image}}\">\n          <p class=\"name\">{{item.Name}}</p>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <ion-button class=\"next\" (click)=\"gotToDetails('normal')\">{{Next}}</ion-button>\n  </section>\n\n  <section class=\"footer\">\n    <div class=\"myOrder\">\n      <h4>{{MyOrder}}</h4>\n    </div>\n    <div class=\"foter\">\n      <p>{{arrOfModLength}}</p>\n      <div class=\"confirmOrCancel\">\n        <ion-button [disabled]=\"arrOfModLength\" (click)=\"Done()\">{{OrderDone}}</ion-button>\n        <ion-button [disabled]=\"arrOfModLength\" (click)=\"cancelOrder()\">{{Cancel}}</ion-button>\n      </div>\n    </div>\n  </section>\n\n\n\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_prom-details_prom-details_module_ts.js.map