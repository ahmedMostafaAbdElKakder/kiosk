"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_payment_payment_module_ts"],{

/***/ 4018:
/*!*********************************************************!*\
  !*** ./src/app/pages/payment/payment-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentPageRoutingModule": () => (/* binding */ PaymentPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _payment_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment.page */ 8622);




const routes = [
    {
        path: '',
        component: _payment_page__WEBPACK_IMPORTED_MODULE_0__.PaymentPage
    }
];
let PaymentPageRoutingModule = class PaymentPageRoutingModule {
};
PaymentPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PaymentPageRoutingModule);



/***/ }),

/***/ 4923:
/*!*************************************************!*\
  !*** ./src/app/pages/payment/payment.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentPageModule": () => (/* binding */ PaymentPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _payment_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-routing.module */ 4018);
/* harmony import */ var _payment_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment.page */ 8622);







let PaymentPageModule = class PaymentPageModule {
};
PaymentPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _payment_routing_module__WEBPACK_IMPORTED_MODULE_0__.PaymentPageRoutingModule
        ],
        declarations: [_payment_page__WEBPACK_IMPORTED_MODULE_1__.PaymentPage]
    })
], PaymentPageModule);



/***/ }),

/***/ 8622:
/*!***********************************************!*\
  !*** ./src/app/pages/payment/payment.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentPage": () => (/* binding */ PaymentPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _payment_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment.page.html?ngResource */ 9380);
/* harmony import */ var _payment_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment.page.scss?ngResource */ 2576);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _awesome_cordova_plugins_printer_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/printer/ngx */ 1293);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 8784);









let PaymentPage = class PaymentPage {
    constructor(rest, printer, http, route) {
        this.rest = rest;
        this.printer = printer;
        this.http = http;
        this.route = route;
        this.pipe = new _angular_common__WEBPACK_IMPORTED_MODULE_4__.DatePipe('en-US');
        this.block = false;
    }
    ngOnInit() {
        this.block = true;
        this.branchName = localStorage.getItem("BranchName");
        let objofPrint = JSON.parse(sessionStorage.getItem('finalObjOfPrint'));
        console.log(objofPrint);
        this.http.get('/assets/images/bingoP.jpeg', { responseType: 'blob' })
            .subscribe(res => {
            const reader = new FileReader();
            reader.onloadend = () => {
                var base64data = reader.result;
                this.imageBase64 = base64data;
                this.imageBase64 = this.imageBase64.replace('data:', '').replace(/^.+,/, '');
                this.beforPrint();
            };
            reader.readAsDataURL(res);
        });
        this.products = JSON.parse(sessionStorage.getItem('finalObj'));
        // this.getVat()
        this.vatValue = this.products.vat;
        this.vatValue = this.vatValue.toFixed(2);
        this.productsArr = objofPrint;
        this.totalPrice = this.products.totalPrice;
        this.totalPrice = this.totalPrice.toFixed(2);
        this.priceBeforDiscount = this.products.priceBeforDiscount;
        this.DiscountAmount = this.products.DiscountAmount;
        this.giftCardCount = this.products.giftCardCount;
        this.totalPriceAfterVat = this.products.oldPrice;
        this.date = this.pipe.transform(Date.now(), 'dd/MM/yyyy HH:MM:SS');
        console.log(this.date);
        this.langId = localStorage.getItem("lang");
        this.giftId = sessionStorage.getItem("idOfSerial");
        this.obj = JSON.parse(sessionStorage.getItem('finalObj'));
        this.obj.service = this.obj.service.toFixed(2);
        console.log(this.obj);
        if (this.langId == '1') {
            this.Back = "رجوع";
            this.selectPayment = "من فضلك اختر طريقة الدفع";
            this.Counter = "كاشير";
            this.Here = "هنا";
        }
        else {
            this.Back = "Back";
            this.selectPayment = "Please select payment type";
            this.Counter = "At Counter";
            this.Here = "Here";
        }
    }
    getVat() {
        this.rest.getVat().subscribe((res) => {
            console.log("vat", res);
            this.TaxGroup = res.BranchDetails.TaxGroup;
            this.TaxGroup = this.TaxGroup.slice(0, 2);
            this.TaxGroup = +this.TaxGroup;
            this.vatValue = this.totalPrice - this.totalPriceAfterVat;
            this.vatValue = this.vatValue.toFixed(2);
        });
    }
    pay() {
        // this.base64ToHex(this.imageBase64)
        this.block = true;
        this.rest.checkOut(this.obj).subscribe((res) => {
            console.log(res);
            sessionStorage.setItem("numberOfOrder", res);
            this.route.navigateByUrl('/order-number');
            this.orderNumber = res;
            this.block = false;
            this.print(res);
            this.rest.activeSerial(this.giftId, res).subscribe(res => {
                console.log(res);
            });
            this.route.navigateByUrl('/order-number');
        });
    }
    goBack() {
        this.route.navigateByUrl('/review');
    }
    beforPrint() {
        this.block = false;
        let bindThis = this;
        var printer;
        ThermalPrinter.listPrinters({ type: 'usb' }, function (printers) {
            if (printers.length > 0) {
                for (let i = 0; i < printers.length; i++) {
                    if (printers[i].productName == 'A8 USB Printer') {
                        printer = printers[i];
                    }
                }
                ThermalPrinter.bitmapToHexadecimalString({
                    type: "usb",
                    id: printer.productName,
                    base64: bindThis.imageBase64
                }, function (res) {
                    // alert(JSON.stringify(res))
                    // alert(res)
                    bindThis.imageInTag = res;
                    console.log('Successfully printed!');
                }, function (error) {
                    alert("erorr");
                    console.error('Printing error', error);
                });
            }
            else {
                console.error('No printers found!');
            }
        }, function (error) {
            console.error('Ups, we cant list the printers!', error);
        });
    }
    print(ordernumber) {
        let objofPrint = JSON.parse(sessionStorage.getItem('finalObjOfPrint'));
        let branchName = localStorage.getItem("NameOfBranch");
        console.log(objofPrint);
        var printer;
        var text;
        let arrOfPrint = [];
        text =
            "[C]<img>" + `${this.imageInTag}` + "</img>\n" +
                "[L]\n" +
                "[C]" + `${this.date}` + "\n" +
                "[L]\n" +
                "[C]" + "Branch : " + `${branchName}` + "\n" +
                "[C]" + "<u>" + `<font size='big'>#${ordernumber}</font>` + "</u>" + "\n" +
                "[L]\n";
        for (let i = 0; i < objofPrint.length; i++) {
            for (let j = 0; j < objofPrint[i].mainData.length; j++) {
                if (objofPrint[i].mainData[j]._mainData) {
                    text = text + "[L]" + "<b>" + `X${objofPrint[i].mainData[j]._mainData.Count}${" "}${objofPrint[i].mainData[j]._mainData.name}` + "</b>" + "\n" +
                        "[L]" + "Price : " + `${objofPrint[i].mainData[j]._mainData.Price}` + " " + "LE" + "\n" +
                        "[L]\n";
                    if (objofPrint[i].mainData[j].Modifires.length != 0) {
                        for (let q = 0; q < objofPrint[i].mainData[j].Modifires.length; q++) {
                            text = text + "[L]" + "<b>" + `X${objofPrint[i].mainData[j].Modifires[q].Count}${" "}${objofPrint[i].mainData[j].Modifires[q].name}` + "</b>" + "\n" +
                                "[L]" + "Price : " + `${objofPrint[i].mainData[j].Modifires[q].Price}` + " " + "LE" + "\n" +
                                "[L]\n";
                        }
                    }
                    if (objofPrint[i].mainData[j].Ingredients.length != 0) {
                        for (let q = 0; q < objofPrint[i].mainData[j].Ingredients.length; q++) {
                            text = text + "[L]" + "<b>" +
                                `X${objofPrint[i].mainData[j].Ingredients[q].Count}${" "}${objofPrint[i].mainData[j].Ingredients[q].name}` +
                                "</b>" + "\n" +
                                "[L]" + "Price : " + `${objofPrint[i].mainData[j].Ingredients[q].Price}` + " " + "LE" + "\n" +
                                "[L]\n";
                        }
                    }
                }
                else {
                    if (j == 0) {
                        text = text + "[L]" + `${objofPrint[i].mainData[j].compoName}` + " - " + `${objofPrint[i].mainData[j].parentCombo}` + " - " + `${objofPrint[i].mainData[j].sizeName}` + "\n";
                    }
                    text = text +
                        "[L]" + "<b>" + `X${objofPrint[i].mainData[j].Count}${" "}${objofPrint[i].mainData[j].name}` + "</b>" + "\n" +
                        "[L]" + "Price : " + `${objofPrint[i].mainData[j].Price}` + " " + "LE" + "\n" +
                        "[L]\n";
                }
            }
            text = text + "[C]--------------------------------\n";
        }
        text = text + "[L] PRICE :" + "[R]" + `${this.obj.priceBeforDiscount}` + "\n" +
            "[C]--------------------------------\n";
        if (this.DiscountAmount != 0) {
            text = text +
                // "[L] PRICE BEFORE DISCOUNT :" + "[R]" + `${this.priceBeforDiscount}` + "\n" +
                "[L] DISCOUNT :" + "[R]" + `- ${this.DiscountAmount}` + "\n" +
                "[L] PRICE AFTER DISCOUNT :" + "[R]" + `${this.priceBeforDiscount - this.DiscountAmount}` + "\n" +
                `[L] Tax VAT (${this.obj.taxVat}%) :` + "[R]" + `${this.vatValue}` + "\n" +
                `[L] Service VAT (${this.obj.serviceVat}%)  :` + "[R]" + `${this.obj.service}` + "\n";
        }
        else {
            text = text + `[L] Tax VAT (${this.obj.taxVat}%) :` + "[R]" + `${this.vatValue}` + "\n" +
                `[L] Service VAT (${this.obj.serviceVat}%)  :` + "[R]" + `${this.obj.service}` + "\n";
        }
        if (this.giftCardCount != 0) {
            text = text +
                "[L] PRICE BEFORE GIFT CARD :" + "[R]" + `${this.totalPriceAfterVat}` + "\n" +
                "[L] GIFT CARD :" + "[R]" + `- ${this.giftCardCount}` + "\n";
            if (this.totalPrice == 0) {
                text = text +
                    "[L] PRICE AFTER GIFT CARD :" + "[R]" + `0` + "\n";
            }
            else {
                text = text +
                    "[L] PRICE AFTER GIFT CARD :" + "[R]" + `${this.totalPrice}` + "\n";
            }
        }
        text = text +
            "[C]--------------------------------\n" +
            "[L] TOTAL PRICE :" + "[R]" + `${this.totalPrice}` + "LE" + "\n" +
            "[L]  \n" +
            "[L]\n" +
            "[L]\n" +
            "[L]\n" +
            "[L]\n" +
            "[L]\n" +
            "[L]\n" +
            "[L]\n" +
            "[L]\n";
        console.log(text);
        ThermalPrinter.listPrinters({ type: 'usb' }, function (printers) {
            if (printers.length > 0) {
                for (let i = 0; i < printers.length; i++) {
                    if (printers[i].productName == 'A8 USB Printer') {
                        printer = printers[i];
                    }
                }
                ThermalPrinter.getEncoding({
                    type: 'usb',
                    id: printer.productName
                }, function (succ) {
                    // alert(JSON.stringify(succ))
                }, function () { });
                ThermalPrinter.printFormattedTextAndCut({
                    type: 'usb',
                    id: printer.productName,
                    mmFeedPaper: 0,
                    dotsFeedPaper: 0,
                    text: text
                }, function () {
                    console.log('Successfully printed!');
                }, function (error) {
                    console.error('Printing error', error);
                });
            }
            else {
                console.error('No printers found!');
            }
        }, function (error) {
            console.error('Ups, we cant list the printers!', error);
        });
    }
};
PaymentPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _awesome_cordova_plugins_printer_ngx__WEBPACK_IMPORTED_MODULE_3__.Printer },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router }
];
PaymentPage.propDecorators = {
    screen: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['screen',] }],
    canvas: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['canvas',] }],
    downloadLink: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['downloadLink',] }]
};
PaymentPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-payment',
        template: _payment_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_payment_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PaymentPage);



/***/ }),

/***/ 2576:
/*!************************************************************!*\
  !*** ./src/app/pages/payment/payment.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background:#000000;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: black;\n  text-transform: none;\n}\n\n.header-md::after {\n  background: none !important;\n}\n\n.back {\n  text-align: right;\n  text-transform: none;\n}\n\n.back ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 5%;\n  font-size: 5vw;\n  height: 84px;\n  margin-bottom: 3%;\n}\n\n.logo {\n  display: flex;\n  justify-content: center;\n  margin-top: 20%;\n}\n\n.logo .logoImage {\n  width: 50%;\n  border-radius: 10px;\n}\n\n.title {\n  text-align: center;\n  font-size: 5vw;\n}\n\n.title h1 {\n  font-size: 5vw;\n  color: #fff;\n  margin-top: -5%;\n  margin-bottom: 10%;\n}\n\n.product {\n  border: 10px solid #e6e3e3;\n  flex-direction: column;\n  display: flex;\n  justify-content: space-between;\n  height: 33vh;\n}\n\n.product .imgProduct {\n  width: 100%;\n  height: 50% !important;\n  margin: 30px auto;\n}\n\n.product .button {\n  --background: #fcef50;\n  text-transform: none;\n  height: 112px;\n  font-size: 4vw;\n}\n\n.footer {\n  text-align: center;\n  margin-top: 10%;\n}\n\n.footer .button {\n  margin-right: 20px;\n  margin-left: 10px;\n  text-transform: none;\n  font-size: 15px;\n}\n\n.footer .lang {\n  background: gray;\n  margin-right: 12px;\n}\n\n.block {\n  width: 100% !important;\n  height: 100vh !important;\n  background: gray !important;\n}\n\n#printer hr {\n  background: black;\n}\n\n.d-flex {\n  display: flex;\n  justify-content: space-between;\n}\n\n.d-flex p {\n  margin-top: 0;\n  margin-bottom: 10px;\n}\n\nion-spinner {\n  position: absolute;\n  top: 43%;\n  left: 43%;\n  transform: scale(4.5);\n}\n\n@media only screen and (max-width: 768px) {\n  .back ion-button {\n    margin-bottom: 0;\n    height: 36px;\n    margin-top: 0;\n  }\n\n  .product {\n    height: 35vh;\n  }\n}\n\n@media print {\n  .page, .page-content, html, body, .framework7-root, .views, .view {\n    height: auto !important;\n  }\n\n  html, body, .framework7-root, .views, .view {\n    overflow: visible !important;\n    overflow-x: visible !important;\n  }\n\n  .page.page-previous {\n    display: none;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBheW1lbnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usb0JBQUE7QUFDRjs7QUFDQTtFQUNFLHFCQUFBO0VBQ0EsY0FBQTtFQUNBLG9CQUFBO0FBRUY7O0FBQUE7RUFDRSwyQkFBQTtBQUdGOztBQURFO0VBQ0UsaUJBQUE7RUFDQSxvQkFBQTtBQUlKOztBQUZFO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFLSjs7QUFIRTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7QUFNSjs7QUFKRTtFQUNFLFVBQUE7RUFDQSxtQkFBQTtBQU9KOztBQUpFO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0FBT0o7O0FBTEU7RUFDRSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQVFKOztBQU5FO0VBQ0UsMEJBQUE7RUFDQSxzQkFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFlBQUE7QUFTSjs7QUFORTtFQUNFLFdBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0FBU0o7O0FBUEU7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7QUFVSjs7QUFQRTtFQUNFLGtCQUFBO0VBR0EsZUFBQTtBQVFKOztBQU5FO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0VBQ0EsZUFBQTtBQVNKOztBQUxFO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBQVFKOztBQUxFO0VBQ0Usc0JBQUE7RUFDQSx3QkFBQTtFQUNBLDJCQUFBO0FBUUo7O0FBRUU7RUFDRSxpQkFBQTtBQUNKOztBQUVFO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0FBQ0o7O0FBQ0U7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7QUFFSjs7QUFBRTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxxQkFBQTtBQUdKOztBQURFO0VBQ0U7SUFDRSxnQkFBQTtJQUNBLFlBQUE7SUFDQSxhQUFBO0VBSUo7O0VBRkU7SUFDRSxZQUFBO0VBS0o7QUFDRjs7QUFGRTtFQUNFO0lBQ0ksdUJBQUE7RUFJTjs7RUFERTtJQUNJLDRCQUFBO0lBQ0EsOEJBQUE7RUFJTjs7RUFERTtJQUNJLGFBQUE7RUFJTjtBQUNGIiwiZmlsZSI6InBheW1lbnQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XG4gIC0tYmFja2dyb3VuZDojMDAwMDAwO1xufVxuaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogI0UxRTFFMTtcbiAgLS1jb2xvcjogYmxhY2s7IFxuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbn1cbi5oZWFkZXItbWQ6OmFmdGVye1xuICBiYWNrZ3JvdW5kOiBub25lICFpbXBvcnRhbnRcbn1cbiAgLmJhY2sge1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgIHRleHQtdHJhbnNmb3JtOiBub25lXG4gIH1cbiAgLmJhY2sgaW9uLWJ1dHRvbntcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDJlbTtcbiAgICAtLXBhZGRpbmctZW5kOiAyZW07XG4gICAgLS1ib3JkZXItcmFkaXVzOjVweDtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICBmb250LXNpemU6IDV2dztcbiAgICBoZWlnaHQ6IDg0cHg7XG4gICAgbWFyZ2luLWJvdHRvbTozJVxuICB9XG4gIC5sb2dve1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgbWFyZ2luLXRvcDogMjAlO1xuICB9XG4gIC5sb2dvIC5sb2dvSW1hZ2Uge1xuICAgIHdpZHRoOiA1MCU7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweFxuICB9XG4gIFxuICAudGl0bGV7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogNXZ3XG4gIH1cbiAgLnRpdGxlIGgxIHtcbiAgICBmb250LXNpemU6IDV2dztcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBtYXJnaW4tdG9wOiAtNSU7XG4gICAgbWFyZ2luLWJvdHRvbTogMTAlO1xuICB9XG4gIC5wcm9kdWN0e1xuICAgIGJvcmRlcjogMTBweCBzb2xpZCAjZTZlM2UzO1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgaGVpZ2h0OjMzdmg7XG4gIFxuICB9XG4gIC5wcm9kdWN0IC5pbWdQcm9kdWN0e1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogNTAlICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luOiAzMHB4IGF1dG87XG4gIH1cbiAgLnByb2R1Y3QgLmJ1dHRvbntcbiAgICAtLWJhY2tncm91bmQ6ICNmY2VmNTA7XG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gICAgaGVpZ2h0OiAxMTJweDtcbiAgICBmb250LXNpemU6IDR2dztcbiAgfVxuICBcbiAgLmZvb3RlcntcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgLy8gZGlzcGxheTogZmxleDtcbiAgICAvLyBqdXN0aWZ5LWNvbnRlbnQ6c3BhY2UtYXJvdW5kO1xuICAgIG1hcmdpbi10b3A6IDEwJTtcbiAgfVxuICAuZm9vdGVyIC5idXR0b257XG4gICAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgXG4gICAgLy8gdGV4dC1hbGlnbjogY2VudGVyXG4gIH1cbiAgLmZvb3RlciAubGFuZ3tcbiAgICBiYWNrZ3JvdW5kOiBncmF5O1xuICAgIG1hcmdpbi1yaWdodDogMTJweDtcbiAgfVxuXG4gIC5ibG9ja3tcbiAgICB3aWR0aDoxMDAlICFpbXBvcnRhbnQ7XG4gICAgaGVpZ2h0OiAxMDB2aCAhaW1wb3J0YW50O1xuICAgIGJhY2tncm91bmQ6IGdyYXkgIWltcG9ydGFudFxuICB9XG5cbiAgI3ByaW50ZXIge1xuICAgIC8vIGRpc3BsYXk6IG5vbmVcbiAgfSBcbiAgXG4gIC8vICNwcmludGVyIHtcbiAgLy8gICBmb250LXNpemU6IDUwcHhcbiAgLy8gfVxuICAjcHJpbnRlciBociB7XG4gICAgYmFja2dyb3VuZDogYmxhY2s7XG4gIH1cblxuICAuZC1mbGV4e1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuXG4gIH1cbiAgLmQtZmxleCBwIHtcbiAgICBtYXJnaW4tdG9wOiAwO1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHhcbiAgfVxuICBpb24tc3Bpbm5lcntcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiA0MyU7XG4gICAgbGVmdDogNDMlO1xuICAgIHRyYW5zZm9ybTogc2NhbGUoNC41KTtcbiAgfVxuICBAbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6NzY4cHgpe1xuICAgIC5iYWNrIGlvbi1idXR0b257XG4gICAgICBtYXJnaW4tYm90dG9tOiAwO1xuICAgICAgaGVpZ2h0OiAzNnB4O1xuICAgICAgbWFyZ2luLXRvcDogMDtcbiAgICB9XG4gICAgLnByb2R1Y3R7XG4gICAgICBoZWlnaHQ6IDM1dmg7XG4gICAgfVxuICB9XG5cbiAgQG1lZGlhIHByaW50IHtcbiAgICAucGFnZSwgLnBhZ2UtY29udGVudCwgaHRtbCwgYm9keSwgLmZyYW1ld29yazctcm9vdCwgLnZpZXdzLCAudmlldyB7XG4gICAgICAgIGhlaWdodDogYXV0byAhaW1wb3J0YW50O1xuICAgIH1cbiAgXG4gICAgaHRtbCwgYm9keSwgLmZyYW1ld29yazctcm9vdCwgLnZpZXdzLCAudmlldyB7XG4gICAgICAgIG92ZXJmbG93OiB2aXNpYmxlICFpbXBvcnRhbnQ7XG4gICAgICAgIG92ZXJmbG93LXg6IHZpc2libGUgIWltcG9ydGFudDtcbiAgICB9XG4gIFxuICAgIC5wYWdlLnBhZ2UtcHJldmlvdXMge1xuICAgICAgICBkaXNwbGF5OiBub25lO1xuICAgIH1cbiAgfSJdfQ== */";

/***/ }),

/***/ 9380:
/*!************************************************************!*\
  !*** ./src/app/pages/payment/payment.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header [translucent]=\"true\">\n  <div class=\"back\">\n    <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n  </div>\n</ion-header> -->\n\n<ion-content [fullscreen]=\"true\">\n  <ion-spinner dir=\"ltr\" *ngIf=\"block\" name=\"circles\"></ion-spinner>\n  <div class=\"logo\">\n    <ion-img class=\"logoImage\" src=\"assets/images/bingo.png\"></ion-img>\n  </div>\n  <div class=\"title\" *ngIf=\"!block\">\n    <h1>{{selectPayment}}</h1>\n  </div>\n\n  <div *ngIf=\"!block\">\n    <ion-grid>\n      <ion-row>\n        <ion-col offset=\"1\" size=\"5\">\n          <div class=\"product\" (click)=\"pay()\">\n            <ion-img class=\"imgProduct\" src=\"assets/images/Casher.png\"></ion-img>\n            <ion-button class=\"button\">{{Counter}}</ion-button>\n          </div>\n        </ion-col>\n        <ion-col size=\"5\">\n          <div class=\"product\" (click)=\"pay()\">\n            <ion-img class=\"imgProduct\" src=\"assets/images/pos.png\"></ion-img>\n            <ion-button class=\"button\">{{Here}}</ion-button>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n  <!-- <button style=\"font-size: 3rem ; height:120px;\" (click)=\"print(0)\">Print</button> -->\n\n  <!-- <div #screen id=\"printer\">\n    <img  src=\"assets/images/logoFinal01.png\">\n    <p style=\"font-size: 50px\">{{date}}</p>\n    <p >{{branchName}}</p>\n    <p style=\"font-size: 50px\" id=\"orderNumber\">#{{ordernumber}}</p>\n\n    <div class=\"productPrinter\" *ngFor=\"let item of productsArr\" id=\"productDetails\">\n      <div *ngFor=\"let product of item.mainData ; let i = index\">\n        <div *ngIf=\"product._mainData\">\n          <p>x{{product._mainData.Count}} {{product._mainData.name}}</p>\n          <p>{{product._mainData.Price | number : '1.2-2'}} LE</p>\n\n          <div *ngFor=\"let modfire of product.Modifires\">\n            <p>x{{modfire.Count}} {{modfire.name}}</p>\n            <p>{{modfire.Price | number : '1.2-2'}} LE</p>\n          </div>\n\n          <div *ngFor=\"let ingrd of product.Ingredients\">\n            <p>x{{ingrd.Count}} {{ingrd.name}}</p>\n            <p>{{ingrd.Price | number : '1.2-2'}} LE</p>\n          </div>\n        </div>\n        <div *ngIf=\"!product._mainData\">\n          <p *ngIf=\"i == 0\">{{product.compoName}} - {{product.parentCombo}} - {{product.sizeName}}</p>\n          <p >x{{product.Count}} {{product.name}}</p>\n          <p >{{product.Price | number : '1.2-2'}} LE</p>\n        </div>\n      </div>\n      <hr>\n    </div>\n\n    <div class=\"d-flex\">\n      <p>Price : </p>\n      <p>{{obj.priceBeforDiscount}} LE</p>\n    </div>\n    <div *ngIf=\"DiscountAmount != 0\" >\n      <div class=\"d-flex\">\n          <p> DISCOUNT : </p>\n          <p>-{{DiscountAmount}}</p>\n      </div>\n      <div class=\"d-flex\">\n          <p>PRICE AFTER DISCOUNT : </p>\n          <p>{{priceBeforDiscount - DiscountAmount}} LE</p>\n      </div>\n    </div>\n    <div class=\"d-flex\">\n        <p>Tax Vat ({{obj.taxVat}}%) :</p>\n        <p>{{vatValue | number : '1.2-2'}} LE</p>\n    </div>\n    <div class=\"d-flex\">\n        <p >Service VAT ({{obj.serviceVat}}%)</p>\n        <p>{{obj.service | number : '1.2-2'}} LE</p>\n    </div>\n    <div *ngIf=\"giftCardCount != 0\" class=\"d-flex\">\n      <p>PRICE BEFORE GIFT CARD : {{totalPriceAfterVat}}</p>\n      <p>GIFT CARD : -{{giftCardCount}}</p>\n    </div>\n    <div class=\"d-flex\">\n        <p>Total Price</p>\n        <p>{{totalPrice | number : '1.2-2'}} LE</p>\n    </div>\n\n\n  </div> -->\n\n  <!-- <div id=\"download\" (click)=\"downloadImage()\">\n    <img #canvas>\n    <a #downloadLink>dowen</a>\n  </div> -->\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_payment_payment_module_ts.js.map