"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_chose-branch_chose-branch_module_ts"],{

/***/ 8438:
/*!*******************************************************************!*\
  !*** ./src/app/pages/chose-branch/chose-branch-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChoseBranchPageRoutingModule": () => (/* binding */ ChoseBranchPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _chose_branch_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./chose-branch.page */ 8573);




const routes = [
    {
        path: '',
        component: _chose_branch_page__WEBPACK_IMPORTED_MODULE_0__.ChoseBranchPage
    }
];
let ChoseBranchPageRoutingModule = class ChoseBranchPageRoutingModule {
};
ChoseBranchPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ChoseBranchPageRoutingModule);



/***/ }),

/***/ 2348:
/*!***********************************************************!*\
  !*** ./src/app/pages/chose-branch/chose-branch.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChoseBranchPageModule": () => (/* binding */ ChoseBranchPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _chose_branch_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./chose-branch-routing.module */ 8438);
/* harmony import */ var _chose_branch_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./chose-branch.page */ 8573);







let ChoseBranchPageModule = class ChoseBranchPageModule {
};
ChoseBranchPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _chose_branch_routing_module__WEBPACK_IMPORTED_MODULE_0__.ChoseBranchPageRoutingModule
        ],
        declarations: [_chose_branch_page__WEBPACK_IMPORTED_MODULE_1__.ChoseBranchPage]
    })
], ChoseBranchPageModule);



/***/ }),

/***/ 8573:
/*!*********************************************************!*\
  !*** ./src/app/pages/chose-branch/chose-branch.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChoseBranchPage": () => (/* binding */ ChoseBranchPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _chose_branch_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./chose-branch.page.html?ngResource */ 8883);
/* harmony import */ var _chose_branch_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./chose-branch.page.scss?ngResource */ 6263);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);






let ChoseBranchPage = class ChoseBranchPage {
    constructor(route, rest) {
        this.route = route;
        this.rest = rest;
        this.arrOfBranch = [];
        this.idOfBranch = '';
        this.disabledButton = true;
    }
    ngOnInit() {
        this.arrOfBranch = JSON.parse(localStorage.getItem('arrayOfBranch'));
        console.log(this.arrOfBranch);
    }
    getRadio(e) {
        this.idOfBranch = e.target.value;
        this.disabledButton = false;
    }
    getItem(item) {
        console.log(item);
    }
    goToOrder() {
        if (this.idOfBranch == '') {
            this.disabledButton = true;
        }
        else {
            for (let i = 0; i < this.arrOfBranch.length; i++) {
                if (this.arrOfBranch[i].Id == this.idOfBranch) {
                    localStorage.setItem("NameOfBranch", this.arrOfBranch[i].Name);
                }
            }
            this.rest.getBranchDetails(this.idOfBranch, 1).subscribe((res) => {
                console.log(res);
                localStorage.setItem("BeforeTax", res.BranchDetails.BeforeTax);
                let service = res.BranchDetails.ServiceTax;
                service = +service;
                localStorage.setItem("ServiceTax", service);
                this.disabledButton = false;
                this.route.navigateByUrl('/order-here');
                localStorage.setItem("idOfBranch", this.idOfBranch);
                this.rest.sendDataOfBranch("true");
            });
        }
    }
};
ChoseBranchPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService }
];
ChoseBranchPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-chose-branch',
        template: _chose_branch_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_chose_branch_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ChoseBranchPage);



/***/ }),

/***/ 6263:
/*!**********************************************************************!*\
  !*** ./src/app/pages/chose-branch/chose-branch.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background:rgb(60, 60, 59);\n  text-align: center;\n}\n\n.container {\n  margin: 0 5%;\n}\n\nion-img {\n  width: 50%;\n  margin: 0 auto;\n}\n\nion-list {\n  background: none;\n}\n\nion-item {\n  --background: #fff;\n  color: #000;\n  font-size: 3rem;\n  margin-bottom: 14px;\n  border-radius: 6px;\n}\n\nion-button {\n  font-size: 3rem;\n  height: 100px;\n  width: auto;\n  --background: #f7a525;\n  color: #fff;\n  margin-top: 5%;\n}\n\n@media only screen and (max-width: 768px) {\n  .container {\n    margin: 0 20;\n  }\n\n  ion-item {\n    --background: #fff;\n    color: #000;\n    font-size: 1rem;\n    margin-bottom: 14px;\n    border-radius: 6px;\n  }\n\n  ion-button {\n    font-size: 1rem;\n    height: 50px;\n    width: auto;\n    --background: #f7a525;\n    color: #fff;\n    margin-top: 1%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNob3NlLWJyYW5jaC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSw0QkFBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBQ0U7RUFDRSxZQUFBO0FBRUo7O0FBQ0E7RUFDSSxVQUFBO0VBQ0EsY0FBQTtBQUVKOztBQUFBO0VBQ0ksZ0JBQUE7QUFHSjs7QUFEQTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBSUo7O0FBRkE7RUFDSSxlQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0FBS0o7O0FBRkE7RUFDSTtJQUNJLFlBQUE7RUFLTjs7RUFIRTtJQUNJLGtCQUFBO0lBQ0EsV0FBQTtJQUNBLGVBQUE7SUFDQSxtQkFBQTtJQUNBLGtCQUFBO0VBTU47O0VBSkU7SUFDSSxlQUFBO0lBQ0EsWUFBQTtJQUNBLFdBQUE7SUFDQSxxQkFBQTtJQUNBLFdBQUE7SUFDQSxjQUFBO0VBT047QUFDRiIsImZpbGUiOiJjaG9zZS1icmFuY2gucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XG4gICAgLS1iYWNrZ3JvdW5kOnJnYig2MCwgNjAsIDU5KTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbiAgLmNvbnRhaW5lcntcbiAgICBtYXJnaW46IDAgNSU7XG59XG5cbmlvbi1pbWcge1xuICAgIHdpZHRoOiA1MCU7XG4gICAgbWFyZ2luOiAwIGF1dG87XG59XG5pb24tbGlzdHtcbiAgICBiYWNrZ3JvdW5kOiBub25lXG59XG5pb24taXRlbXtcbiAgICAtLWJhY2tncm91bmQ6ICNmZmY7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgZm9udC1zaXplOiAzcmVtO1xuICAgIG1hcmdpbi1ib3R0b206IDE0cHg7XG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xufVxuaW9uLWJ1dHRvbntcbiAgICBmb250LXNpemU6IDNyZW07XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgICB3aWR0aDogYXV0bztcbiAgICAtLWJhY2tncm91bmQ6ICNmN2E1MjU7XG4gICAgY29sb3I6I2ZmZjtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjc2OHB4KXtcbiAgICAuY29udGFpbmVye1xuICAgICAgICBtYXJnaW46IDAgMjA7XG4gICAgfVxuICAgIGlvbi1pdGVte1xuICAgICAgICAtLWJhY2tncm91bmQ6ICNmZmY7XG4gICAgICAgIGNvbG9yOiAjMDAwO1xuICAgICAgICBmb250LXNpemU6IDFyZW07XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDE0cHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgICB9XG4gICAgaW9uLWJ1dHRvbntcbiAgICAgICAgZm9udC1zaXplOiAxcmVtO1xuICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgIHdpZHRoOiBhdXRvO1xuICAgICAgICAtLWJhY2tncm91bmQ6ICNmN2E1MjU7XG4gICAgICAgIGNvbG9yOiNmZmY7XG4gICAgICAgIG1hcmdpbi10b3A6IDElO1xuICAgIH1cbn0iXX0= */";

/***/ }),

/***/ 8883:
/*!**********************************************************************!*\
  !*** ./src/app/pages/chose-branch/chose-branch.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <ion-img class=\"logoImage\" src=\"assets/images/logoFinal02.png\"></ion-img>\n\n  <div class=\"container\">\n      <ion-list>\n        <ion-radio-group [(ngModel)]=\"selectedValue\" (ionChange)=\"getRadio($event)\">\n          <ion-item *ngFor=\"let item of arrOfBranch\">\n            <ion-label>{{item.Name}}</ion-label>\n            <ion-radio name=\"sdas\" value=\"{{item.Id}}\"></ion-radio>\n          </ion-item>\n        </ion-radio-group>\n      </ion-list>\n      <ion-button [disabled]=\"disabledButton\" class=\"btn\" (click)=\"goToOrder()\">Continue</ion-button>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_chose-branch_chose-branch_module_ts.js.map