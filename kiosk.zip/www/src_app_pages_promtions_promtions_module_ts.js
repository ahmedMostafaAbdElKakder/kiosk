"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_promtions_promtions_module_ts"],{

/***/ 9037:
/*!*************************************************************!*\
  !*** ./src/app/pages/promtions/promtions-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PromtionsPageRoutingModule": () => (/* binding */ PromtionsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _promtions_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./promtions.page */ 3294);




const routes = [
    {
        path: '',
        component: _promtions_page__WEBPACK_IMPORTED_MODULE_0__.PromtionsPage
    }
];
let PromtionsPageRoutingModule = class PromtionsPageRoutingModule {
};
PromtionsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PromtionsPageRoutingModule);



/***/ }),

/***/ 2880:
/*!*****************************************************!*\
  !*** ./src/app/pages/promtions/promtions.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PromtionsPageModule": () => (/* binding */ PromtionsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _promtions_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./promtions-routing.module */ 9037);
/* harmony import */ var _promtions_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./promtions.page */ 3294);







let PromtionsPageModule = class PromtionsPageModule {
};
PromtionsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _promtions_routing_module__WEBPACK_IMPORTED_MODULE_0__.PromtionsPageRoutingModule
        ],
        declarations: [_promtions_page__WEBPACK_IMPORTED_MODULE_1__.PromtionsPage]
    })
], PromtionsPageModule);



/***/ }),

/***/ 3294:
/*!***************************************************!*\
  !*** ./src/app/pages/promtions/promtions.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PromtionsPage": () => (/* binding */ PromtionsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _promtions_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./promtions.page.html?ngResource */ 484);
/* harmony import */ var _promtions_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./promtions.page.scss?ngResource */ 8885);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);






let PromtionsPage = class PromtionsPage {
    constructor(rest, route) {
        this.rest = rest;
        this.route = route;
        this.categoris = [];
        this.showCover = false;
        this.disalbedButton = true;
    }
    ngOnInit() {
        this.langId = localStorage.getItem('lang');
        if (this.langId == '1') {
            this.dir = "rtl";
            this.Menu = "قائمة الطلبات";
            this.Back = "رجوع";
            this.Cancel = "إلغاء الطلب";
            this.OrderDone = "دفع";
            this.MyOrder = "طلباتي - في المتجر";
            this.bestSelling = "افضل المنتجات";
            this.discount = "الخصومات";
            this.promotions = "العروض";
            this.Compo = "كومبو";
        }
        else {
            this.dir = "ltr";
            this.Menu = "Main Menu";
            this.Back = "Back";
            this.Cancel = "Cancel Order";
            this.OrderDone = "Done";
            this.MyOrder = "My Order - In Shop";
            this.bestSelling = "Best Selling";
            this.discount = "Discount";
            this.promotions = "Promotion";
            this.Compo = "Combo";
        }
        this.getCategoris();
        this.ifArrOfModfier();
        this.rest.getPromtion(this.langId).subscribe((res) => {
            console.log(res);
            this.promotionsArr = res;
        });
    }
    gotToDetails(item) {
        console.log(item);
        this.rest.getPromoDetails(this.langId, item.Id).subscribe(res => {
            console.log(res);
            sessionStorage.setItem('promotions', JSON.stringify(res));
            this.route.navigateByUrl('/prom-details');
        });
    }
    getCategoris() {
        this.rest.getCategoriWithProduct(this.langId).subscribe((res) => {
            console.log(res);
            this.categoris = res.categoriesProducts;
            for (let i = 0; i < this.categoris.length; i++) {
                if (i == 1 || i == 4 || i == 7 || i == 10) {
                    this.categoris[i].status = true;
                }
                else {
                    this.categoris[i].status = false;
                }
            }
        });
    }
    gotToSugg() {
        this.route.navigateByUrl('/suggestions');
    }
    ifArrOfModfier() {
        let arrOfMod = JSON.parse(sessionStorage.getItem('arrOfModfire'));
        if (arrOfMod) {
            this.disalbedButton = false;
            if (this.langId == '1') {
                this.arrOfModLength = "إجمالي المنتجات" + " " + `(${arrOfMod.length})`;
            }
            else {
                this.arrOfModLength = "Total Items" + " " + `(${arrOfMod.length})`;
            }
        }
        else {
            this.disalbedButton = true;
            if (this.langId == '1') {
                this.arrOfModLength = "لا يوجد طلبات";
            }
            else {
                this.arrOfModLength = "You Order is Empty";
            }
        }
    }
    goBack() {
        this.route.navigateByUrl('/main_menu');
    }
    cancelOrder() {
        sessionStorage.clear();
        this.route.navigateByUrl('/home');
    }
    Done() {
        this.route.navigateByUrl('/review');
    }
    gotToItems(item) {
        if (item == 'Discount') {
            this.rest.gitDiscount(this.langId).subscribe((res) => {
                console.log(res);
                let obj = {
                    Name: 'Discount',
                    Products: res
                };
                sessionStorage.setItem('obj', JSON.stringify(obj));
                this.route.navigateByUrl('/discount');
            });
        }
        else {
            sessionStorage.setItem('obj', JSON.stringify(item));
            this.route.navigateByUrl('/categoris');
        }
    }
};
PromtionsPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
PromtionsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-promtions',
        template: _promtions_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_promtions_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PromtionsPage);



/***/ }),

/***/ 8885:
/*!****************************************************************!*\
  !*** ./src/app/pages/promtions/promtions.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcef50;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: #000;\n  text-transform: none;\n  width: 250px;\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius: 5px;\n  font-size: 5vw;\n  height: 100px;\n}\n\nion-content {\n  --background:#fff ;\n  --color:black ;\n}\n\n.cover {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  top: 0;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #000;\n}\n\n.cover h1 {\n  font-weight: bold;\n  margin-top: 10%;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.back p, .backIfRight p {\n  font-weight: bold;\n  font-size: 5vw;\n}\n\n.back ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 2%;\n  font-size: 5vw;\n  height: auto;\n  margin-bottom: 5%;\n  height: 100px;\n}\n\n.mainMenu {\n  font-size: 3rem;\n  font-weight: bold;\n  margin-top: 50%;\n}\n\n.imgProduct {\n  width: auto;\n}\n\n.products {\n  text-align: center;\n  height: 52vh;\n  overflow-y: scroll;\n}\n\n.products img {\n  height: 150px;\n}\n\n.products .price {\n  text-align: left;\n  font-size: 11px;\n}\n\n.products .name {\n  font-size: 0.8rem;\n  margin-bottom: 5px;\n  margin-top: 0;\n  font-weight: bold;\n  font-size: 3vw;\n}\n\n.products .rowOne {\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.colOne {\n  border-right: 1px solid #c2c2c2;\n}\n\n.menuItem {\n  padding-bottom: 5px;\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.menuItem p {\n  margin: 0;\n  font-size: 0.5rem;\n  text-align: center;\n  font-weight: bold;\n  font-size: 3vw;\n}\n\n.menuItem img {\n  height: 150px;\n}\n\n.price_name {\n  display: flex;\n  justify-content: space-between;\n  font-size: 10px;\n}\n\n.myOrder {\n  background: #E1E1E1;\n  padding: 5px 10px;\n}\n\n.myOrder h4 {\n  margin: 0;\n  font-size: 5vw;\n  color: #000;\n}\n\n.confirmOrCancel {\n  display: flex;\n  justify-content: space-around;\n}\n\n.confirmOrCancel ion-button {\n  width: 33%;\n}\n\n.foter p {\n  text-align: center;\n  font-size: 5vw;\n}\n\n.footer {\n  position: absolute;\n  width: 100%;\n  bottom: 8px;\n}\n\n.Content .navgation div {\n  border-bottom: 1px solid gray;\n}\n\n.navgation {\n  margin-top: -19%;\n}\n\n.Content .navgation {\n  overflow-y: scroll;\n  border-radius: 5px;\n  margin-top: -17%;\n  background: #f0f0f0;\n  height: 72vh;\n  text-align: center;\n}\n\n.confirmOrCancel ion-button {\n  font-size: 4vw;\n  height: 112px;\n}\n\n@media only screen and (max-width: 768px) {\n  ion-button {\n    font-size: 1rem;\n    height: 50px;\n    width: auto;\n    margin-top: 1%;\n  }\n\n  .imgProduct {\n    width: 81px;\n  }\n\n  .back ion-button {\n    height: 36px;\n  }\n\n  .Content .mainMenu {\n    font-size: 13px;\n  }\n\n  .Content {\n    padding: 0;\n  }\n\n  .navgation {\n    margin-top: -19%;\n  }\n\n  .products img {\n    height: 55px;\n  }\n\n  .menuItem img {\n    height: 50px;\n  }\n\n  .menuItem {\n    padding: 15px 0;\n  }\n\n  .myOrder h4 {\n    padding: 2px 10px;\n  }\n\n  .confirmOrCancel ion-button {\n    height: 44px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb210aW9ucy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0FBQUo7O0FBRUE7RUFDSSxxQkFBQTtFQUNBLGFBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxjQUFBO0VBRUEsYUFBQTtBQUFKOztBQUVFO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0FBQ0o7O0FBQ0U7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsTUFBQTtFQUNBLHFDQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FBRUo7O0FBQUU7RUFDSSxpQkFBQTtFQUNBLGVBQUE7QUFHTjs7QUFERTtFQUNFLGlCQUFBO0FBSUo7O0FBRkU7RUFDRSxnQkFBQTtBQUtKOztBQUhFO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0FBTU47O0FBSkU7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7QUFPSjs7QUFKQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUFPSjs7QUFMRTtFQUNJLFdBQUE7QUFRTjs7QUFORTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBU0o7O0FBUEE7RUFDSSxhQUFBO0FBVUo7O0FBUkE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7QUFXSjs7QUFUQTtFQUNJLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBWUo7O0FBVkE7RUFDSSxnQ0FBQTtBQWFKOztBQVhBO0VBQ0ksK0JBQUE7QUFjSjs7QUFaQTtFQUNJLG1CQUFBO0VBQ0EsZ0NBQUE7QUFlSjs7QUFiQTtFQUNJLFNBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBZ0JKOztBQWRBO0VBQ0ksYUFBQTtBQWlCSjs7QUFmQTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGVBQUE7QUFrQko7O0FBaEJBO0VBQ0ksbUJBQUE7RUFDQSxpQkFBQTtBQW1CSjs7QUFqQkE7RUFDSSxTQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUFvQko7O0FBakJBO0VBQ0ksYUFBQTtFQUNBLDZCQUFBO0FBb0JKOztBQWxCQTtFQUNJLFVBQUE7QUFxQko7O0FBbkJBO0VBQ0ksa0JBQUE7RUFDQSxjQUFBO0FBc0JKOztBQWxCQTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7QUFxQko7O0FBbEJBO0VBQ0ksNkJBQUE7QUFxQko7O0FBbkJBO0VBQ0ksZ0JBQUE7QUFzQko7O0FBcEJBO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUF1Qko7O0FBckJBO0VBQ0ksY0FBQTtFQUNBLGFBQUE7QUF3Qko7O0FBckJBO0VBQ0k7SUFDSSxlQUFBO0lBQ0EsWUFBQTtJQUNBLFdBQUE7SUFDQSxjQUFBO0VBd0JOOztFQXRCRTtJQUNFLFdBQUE7RUF5Qko7O0VBdEJBO0lBQ0ksWUFBQTtFQXlCSjs7RUF2QkE7SUFDSSxlQUFBO0VBMEJKOztFQXhCQTtJQUNJLFVBQUE7RUEyQko7O0VBekJBO0lBQ0ksZ0JBQUE7RUE0Qko7O0VBMUJDO0lBQ0csWUFBQTtFQTZCSjs7RUEzQkU7SUFDRSxZQUFBO0VBOEJKOztFQTVCRTtJQUNFLGVBQUE7RUErQko7O0VBN0JFO0lBQ0UsaUJBQUE7RUFnQ0o7O0VBOUJFO0lBQ0UsWUFBQTtFQWlDSjtBQUNGIiwiZmlsZSI6InByb210aW9ucy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi5oZWFkZXJ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGJhY2tncm91bmQ6ICNmY2VmNTBcbn1cbmlvbi1idXR0b24ge1xuICAgIC0tYmFja2dyb3VuZDogI0UxRTFFMTtcbiAgICAtLWNvbG9yOiAjMDAwO1xuICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICAgIHdpZHRoOiAyNTBweDtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDJlbTtcbiAgICAtLXBhZGRpbmctZW5kOiAyZW07XG4gICAgLS1ib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgZm9udC1zaXplOiA1dnc7XG5cbiAgICBoZWlnaHQ6IDEwMHB4O1xuICB9XG4gIGlvbi1jb250ZW50e1xuICAgIC0tYmFja2dyb3VuZDojZmZmIDtcbiAgICAtLWNvbG9yOmJsYWNrXG59XG4gIC5jb3ZlciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICB0b3A6IDA7XG4gICAgYmFja2dyb3VuZDogcmdiKDI1NSAyNTUgMjU1IC8gNzklKTs7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwXG4gIH1cbiAgLmNvdmVyIGgxIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgbWFyZ2luLXRvcDogMTAlXG4gIH1cbiAgLmJhY2sge1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICB9XG4gIC5iYWNrSWZSaWdodHtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICB9XG4gIC5iYWNrIHAgLC5iYWNrSWZSaWdodCBwIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgZm9udC1zaXplOiA1dnc7XG4gIH1cbiAgLmJhY2sgaW9uLWJ1dHRvbntcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDJlbTtcbiAgICAtLXBhZGRpbmctZW5kOiAyZW07XG4gICAgLS1ib3JkZXItcmFkaXVzOjVweDtcbiAgICBtYXJnaW4tdG9wOiAyJTtcbiAgICBmb250LXNpemU6IDV2dztcbiAgICBoZWlnaHQ6IGF1dG87XG4gICAgbWFyZ2luLWJvdHRvbTogNSU7XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgfVxuXG4ubWFpbk1lbnV7XG4gICAgZm9udC1zaXplOiAzcmVtO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIG1hcmdpbi10b3A6IDUwJTtcbn1cbiAgLmltZ1Byb2R1Y3R7XG4gICAgICB3aWR0aDogYXV0b1xuICB9XG4gIC5wcm9kdWN0c3tcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgaGVpZ2h0OiA1MnZoO1xuICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcbn1cbi5wcm9kdWN0cyBpbWcge1xuICAgIGhlaWdodDogMTUwcHg7XG59XG4ucHJvZHVjdHMgLnByaWNle1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1zaXplOiAxMXB4XG59XG4ucHJvZHVjdHMgLm5hbWV7XG4gICAgZm9udC1zaXplOiAuOHJlbTtcbiAgICBtYXJnaW4tYm90dG9tOjVweDtcbiAgICBtYXJnaW4tdG9wOiAwO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc2l6ZTogM3Z3O1xufVxuLnByb2R1Y3RzIC5yb3dPbmV7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjMmMyYzI7XG59XG4uY29sT25le1xuICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNjMmMyYzI7XG59XG4ubWVudUl0ZW17XG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2MyYzJjMlxufVxuLm1lbnVJdGVtIHB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGZvbnQtc2l6ZTogLjVyZW07XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc2l6ZTogM3Z3O1xufVxuLm1lbnVJdGVtIGltZyB7XG4gICAgaGVpZ2h0OiAxNTBweDtcbn1cbi5wcmljZV9uYW1le1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIGZvbnQtc2l6ZTogMTBweDtcbn1cbi5teU9yZGVye1xuICAgIGJhY2tncm91bmQ6ICNFMUUxRTE7XG4gICAgcGFkZGluZyA6NXB4IDEwcHhcbn1cbi5teU9yZGVyIGg0IHtcbiAgICBtYXJnaW46IDA7XG4gICAgZm9udC1zaXplOiA1dnc7XG4gICAgY29sb3I6ICMwMDBcbn1cblxuLmNvbmZpcm1PckNhbmNlbHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xufVxuLmNvbmZpcm1PckNhbmNlbCBpb24tYnV0dG9ue1xuICAgIHdpZHRoOiAzMyU7XG59XG4uZm90ZXIgcCB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogNXZ3O1xuXG59XG5cbi5mb290ZXIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBib3R0b206IDhweDtcbn1cblxuLkNvbnRlbnQgLm5hdmdhdGlvbiBkaXYge1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBncmF5O1xufVxuLm5hdmdhdGlvbntcbiAgICBtYXJnaW4tdG9wOiAtMTklO1xufVxuLkNvbnRlbnQgLm5hdmdhdGlvbntcbiAgICBvdmVyZmxvdy15OiBzY3JvbGw7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIG1hcmdpbi10b3A6IC0xNyU7XG4gICAgYmFja2dyb3VuZDogI2YwZjBmMDtcbiAgICBoZWlnaHQ6IDcydmg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLmNvbmZpcm1PckNhbmNlbCBpb24tYnV0dG9ue1xuICAgIGZvbnQtc2l6ZTogNHZ3O1xuICAgIGhlaWdodDogMTEycHg7XG59XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDo3NjhweCl7XG4gICAgaW9uLWJ1dHRvbntcbiAgICAgICAgZm9udC1zaXplOiAxcmVtO1xuICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgIHdpZHRoOiBhdXRvO1xuICAgICAgICBtYXJnaW4tdG9wOiAxJTtcbiAgICB9XG4gICAgLmltZ1Byb2R1Y3R7XG4gICAgICB3aWR0aDogODFweDtcbiAgfVxuICBcbiAgLmJhY2sgaW9uLWJ1dHRvbntcbiAgICAgIGhlaWdodDogMzZweDtcbiAgfVxuICAuQ29udGVudCAubWFpbk1lbnV7XG4gICAgICBmb250LXNpemU6IDEzcHg7XG4gIH1cbiAgLkNvbnRlbnR7XG4gICAgICBwYWRkaW5nOiAwXG4gIH1cbiAgLm5hdmdhdGlvbntcbiAgICAgIG1hcmdpbi10b3A6IC0xOSU7XG4gIH1cbiAgIC5wcm9kdWN0cyBpbWd7XG4gICAgICBoZWlnaHQ6IDU1cHg7XG4gICAgfVxuICAgIC5tZW51SXRlbSBpbWd7XG4gICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgfVxuICAgIC5tZW51SXRlbXtcbiAgICAgIHBhZGRpbmc6IDE1cHggMDtcbiAgICB9XG4gICAgLm15T3JkZXIgaDR7XG4gICAgICBwYWRkaW5nOiAycHggMTBweDtcbiAgICB9XG4gICAgLmNvbmZpcm1PckNhbmNlbCBpb24tYnV0dG9ue1xuICAgICAgaGVpZ2h0OiA0NHB4O1xuICAgIH1cbiAgfSJdfQ== */";

/***/ }),

/***/ 484:
/*!****************************************************************!*\
  !*** ./src/app/pages/promtions/promtions.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <div>\n    <img class=\"imgProduct\" src=\"assets/images/panner.jpeg\">\n  </div>\n  <div *ngIf=\"showCover\" class=\"cover\">\n    <h1>coffee</h1>\n  </div>\n</ion-header> -->\n<div class=\"header\">\n    <img class=\"imgProduct \" src=\"assets/images/bingo.png\">\n  </div>\n\n<ion-content [dir]=\"dir\">\n  <div class=\"\">\n\n    <div class=\"back\" [ngClass]=\"{'back':dir == 'ltr', 'backIfRight':dir == 'rtl'}\">\n      <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n    </div>\n\n    <section class=\"Content\">\n      <ion-grid style=\"padding: 0\">\n        <ion-row>\n          <ion-col size=\"3\" class=\"navgation\">\n              <p class=\"mainMenu\">{{Menu}}</p>\n            <div>\n              <div  class=\"menuItem\" routerLink=\"/compo\">\n                <img src=\"assets/images/mostSelling.png\">\n                <p>{{Compo}}</p>\n              </div>\n              <div class=\"menuItem\" (click)=\"gotToItems('Discount')\">\n                <img src=\"assets/images/discount.png\">\n                <p>{{discount}}</p>\n              </div>\n              <div  class=\"menuItem\" >\n                <img src=\"assets/images/promotion.png\">\n                <p>{{promotions}}</p>\n              </div>\n              <div *ngFor=\"let item of categoris\" class=\"menuItem\" (click)=\"gotToItems(item)\">\n                <img src=\"{{item.Image}}\">\n                <p>{{item.Name}}</p>\n              </div>\n            </div>\n          </ion-col>\n          <ion-col>\n            <div class=\"products\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col size=\"4\" class=\"rowOne\" [ngClass]=\"{'colOne':item.status == false}\"\n                    *ngFor=\"let item of promotionsArr ; let i = index\" (click)=\"gotToDetails(item)\">\n                    <!-- <img src=\"{{item.Image}}\"> -->\n                    <img src=\"assets/images/promotion.png\">\n                    <p class=\"name\">{{item.Name}}</p>\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </section>\n  </div>\n\n  <section class=\"footer\">\n    <div class=\"myOrder\">\n      <h4>{{MyOrder}}</h4>\n    </div>\n    <div class=\"foter\">\n      <p>{{arrOfModLength}}</p>\n      <div class=\"confirmOrCancel\">\n        <ion-button (click)=\"cancelOrder()\" [disabled]=\"disalbedButton\">{{Cancel}}</ion-button>\n        <ion-button (click)=\"Done()\" [disabled]='disalbedButton'>{{OrderDone}}</ion-button>\n      </div>\n    </div>\n  </section>\n\n\n\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_promtions_promtions_module_ts.js.map