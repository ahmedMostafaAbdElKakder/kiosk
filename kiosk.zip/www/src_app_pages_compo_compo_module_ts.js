"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_compo_compo_module_ts"],{

/***/ 2604:
/*!*****************************************************!*\
  !*** ./src/app/pages/compo/compo-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompoPageRoutingModule": () => (/* binding */ CompoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _compo_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./compo.page */ 3107);




const routes = [
    {
        path: '',
        component: _compo_page__WEBPACK_IMPORTED_MODULE_0__.CompoPage
    }
];
let CompoPageRoutingModule = class CompoPageRoutingModule {
};
CompoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CompoPageRoutingModule);



/***/ }),

/***/ 6013:
/*!*********************************************!*\
  !*** ./src/app/pages/compo/compo.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompoPageModule": () => (/* binding */ CompoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _compo_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./compo-routing.module */ 2604);
/* harmony import */ var _compo_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./compo.page */ 3107);







let CompoPageModule = class CompoPageModule {
};
CompoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _compo_routing_module__WEBPACK_IMPORTED_MODULE_0__.CompoPageRoutingModule
        ],
        declarations: [_compo_page__WEBPACK_IMPORTED_MODULE_1__.CompoPage]
    })
], CompoPageModule);



/***/ }),

/***/ 3107:
/*!*******************************************!*\
  !*** ./src/app/pages/compo/compo.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompoPage": () => (/* binding */ CompoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _compo_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./compo.page.html?ngResource */ 8893);
/* harmony import */ var _compo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./compo.page.scss?ngResource */ 552);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);







let CompoPage = class CompoPage {
    constructor(rest, route, navCtr) {
        this.rest = rest;
        this.route = route;
        this.navCtr = navCtr;
        this.items = [];
        this.showModfire = false;
        this.ModifiresbyProductId = [];
        this.disalbedButton = true;
    }
    ngOnInit() {
        this.langId = localStorage.getItem('lang');
        if (this.langId == '1') {
            this.dir = "rtl";
            this.Menu = "قائمة الطلبات";
            this.Back = "رجوع";
            this.Cancel = "إلغاء الطلب";
            this.OrderDone = "دفع";
            this.MyOrder = "طلباتي - في المتجر";
            this.Modfires = "الاضافات";
            this.Next = "التالي";
            this.bestSelling = "افضل المنتجات";
            this.discount = "الخصومات";
            this.promotions = "العروض";
            this.LE = "جنيه";
        }
        else {
            this.dir = "ltr";
            this.Menu = "Main Menu";
            this.Back = "Back";
            this.Cancel = "Cancel Order";
            this.OrderDone = "Done";
            this.MyOrder = "My Order - In Shop";
            this.Modfires = "Modifiers";
            this.Next = "Next";
            this.bestSelling = "Best Selling";
            this.discount = "Discount";
            this.promotions = "Promotion";
            this.LE = "LE";
        }
        // this.getData()
        this.getCategoris();
        this.getCommbo();
        this.ifArrOfModfier();
    }
    getCommbo() {
        this.rest.combo(this.langId).subscribe((res) => {
            console.log("combo", res);
            this.items = res;
            for (let i = 0; i < this.items.length; i++) {
                if (this.items[i].Image == "") {
                    this.items[i].Image = "assets/images/kiosk.png";
                }
            }
        });
    }
    getCategoris() {
        this.rest.getCategoriWithProduct(this.langId).subscribe((res) => {
            console.log(res);
            this.categoris = res.categoriesProducts;
            for (let i = 0; i < this.categoris.length; i++) {
                if (i == 2 || i == 5 || i == 8 || i == 11) {
                    this.categoris[i].status = true;
                }
                else {
                    this.categoris[i].status = false;
                }
            }
        });
    }
    getData() {
        this.categoriObj = JSON.parse(sessionStorage.getItem('obj'));
        console.log(this.categoriObj);
        this.nameOfCat = this.categoriObj.Name;
        // this.items = this.categoriObj.Products
        for (let i = 0; i < this.items.length; i++) {
            if (i == 2 || i == 5 || i == 8 || i == 11) {
                this.items[i].status = true;
            }
            else {
                this.items[i].status = false;
            }
        }
    }
    GetModifiresbyProductId(item, id) {
        this.idOfIngrdtiont = id;
        sessionStorage.setItem('ProductOfChose', JSON.stringify(item));
        this.price = item.Price;
        this.rest.GetModifiresbyProductId(id, this.langId).subscribe((res) => {
            console.log(res);
            if (res.length != 0) {
                sessionStorage.setItem('modfiresArr', JSON.stringify(res));
                this.route.navigateByUrl('/add-modfires');
            }
            else {
                this.rest.GetItemsbyProductId(this.langId, id).subscribe((res) => {
                    if (res.length == 0) {
                        let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
                        console.log("hamdaaaa");
                        let item = {};
                        item.ingridtArr = [];
                        item.Prdoucts = [products];
                        item.modfire = [];
                        sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                        this.route.navigateByUrl('/quantity');
                    }
                    else {
                        this.gotToDetails('normal');
                    }
                });
            }
        });
    }
    close() {
        this.showModfire = false;
    }
    ifArrOfModfier() {
        let arrOfMod = JSON.parse(sessionStorage.getItem('arrOfModfire'));
        if (arrOfMod) {
            this.disalbedButton = false;
            if (this.langId == '1') {
                this.arrOfModLength = "إجمالي المنتجات" + " " + `(${arrOfMod.length})`;
            }
            else {
                this.arrOfModLength = "Total Items" + " " + `(${arrOfMod.length})`;
            }
        }
        else {
            this.disalbedButton = true;
            if (this.langId == '1') {
                this.arrOfModLength = "لا يوجد طلبات";
            }
            else {
                this.arrOfModLength = "You Order is Empty";
            }
        }
    }
    gotToDetails(item) {
        if (item == "normal") {
            let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
            this.rest.GetItemsbyProductId(this.langId, this.idOfIngrdtiont).subscribe((res) => {
                if (res.length == 0) {
                    let item = {};
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    let item = {};
                    item.Prdoucts = [products];
                    item.modfire = [];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/add-souce');
                }
            });
            sessionStorage.setItem("ifModFire", 'false');
        }
        else if (item == 'Discount') {
            this.rest.gitDiscount(this.langId).subscribe((res) => {
                console.log(res);
                let obj = {
                    Name: 'Discount',
                    Products: res
                };
                sessionStorage.setItem('obj', JSON.stringify(obj));
                this.route.navigateByUrl('/discount');
            });
        }
        else {
            console.log("asdasdsa", item);
            this.rest.GetItemsbyProductId(this.langId, this.idOfIngrdtiont).subscribe((res) => {
                if (res.length == 0) {
                    let products = JSON.parse(sessionStorage.getItem('ProductOfChose'));
                    item.ingridtArr = [];
                    item.Prdoucts = [products];
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/quantity');
                }
                else {
                    sessionStorage.setItem('ModfireOfChose', JSON.stringify(item));
                    this.route.navigateByUrl('/add-souce');
                }
            });
        }
    }
    ChoseCategori(item) {
        sessionStorage.setItem('obj', JSON.stringify(item));
        this.route.navigateByUrl('/categoris');
    }
    goBack() {
        this.route.navigateByUrl('/main_menu');
    }
    cancelOrder() {
        sessionStorage.clear();
        this.route.navigateByUrl('/suggestions');
    }
    Done() {
        this.route.navigateByUrl('/review');
    }
    goTocomboDetails(item) {
        sessionStorage.setItem("comboId", item.Id);
        sessionStorage.setItem("comboName", item.Name);
        this.route.navigateByUrl("/choose-combo");
    }
};
CompoPage.ctorParameters = () => [
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController }
];
CompoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-compo',
        template: _compo_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_compo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CompoPage);



/***/ }),

/***/ 552:
/*!********************************************************!*\
  !*** ./src/app/pages/compo/compo.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcef50;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: black;\n  text-transform: none;\n}\n\nion-content {\n  --background:#fff ;\n  --color: black ;\n}\n\n.cover {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  left: 0%;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #fff;\n  top: 0;\n}\n\n.cover2 {\n  position: absolute;\n  width: 100%;\n  height: 27vh;\n  top: 0;\n  background: rgba(255, 255, 255, 0.79);\n  text-align: center;\n  color: #000;\n}\n\n.cover h1 {\n  font-weight: bold;\n  margin-top: 12%;\n  font-size: 5vw;\n  color: black;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.back p, .backIfRight P {\n  font-weight: bold;\n  font-size: 5vw;\n}\n\n.back ion-button, .backIfRight ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 2%;\n  font-size: 5vw;\n  height: auto;\n  margin-bottom: 5%;\n  height: 100px;\n}\n\n.products {\n  text-align: center;\n}\n\n.products .price {\n  text-align: left;\n  font-size: 11px;\n  margin: 0;\n}\n\n.products .name {\n  font-size: 0.8rem;\n  margin-bottom: 5px;\n  margin-top: 0;\n  font-weight: bold;\n}\n\n.products .rowOne {\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.colOne {\n  border-right: 1px solid #c2c2c2;\n}\n\n.menuItem {\n  padding: 30px 0;\n  border-bottom: 1px solid #c2c2c2;\n}\n\n.menuItem p {\n  margin: 0;\n  font-size: 0.5rem;\n  text-align: center;\n  font-weight: bold;\n  font-size: 3vw;\n}\n\n.menuItem img {\n  height: 150px;\n}\n\n.price_name {\n  display: flex;\n  justify-content: space-between;\n  font-size: 10px;\n  margin-top: 10px;\n  font-size: 3vw;\n}\n\n.myOrder {\n  background: #E1E1E1;\n  padding: 5px 10px;\n}\n\n.myOrder h4 {\n  margin: 0;\n  font-size: 5vw;\n  color: black;\n}\n\n.confirmOrCancel {\n  display: flex;\n  justify-content: space-around;\n}\n\n.confirmOrCancel ion-button {\n  width: 33%;\n}\n\n.foter p {\n  text-align: center;\n  font-size: 5vw;\n}\n\n.footer {\n  position: absolute;\n  width: 100%;\n  bottom: 1%;\n}\n\n.recmoended p {\n  margin: 0;\n  font-size: 5vw;\n}\n\n.menu {\n  overflow-y: scroll;\n  border-radius: 5px;\n  margin-top: -17%;\n  background: #f0f0f0;\n  height: 72vh;\n  text-align: center;\n}\n\n.menu div {\n  border-bottom: 1px solid gray;\n}\n\n.menu .mainMenu {\n  font-size: 3rem;\n  font-weight: bold;\n  margin-top: 50%;\n}\n\n.products {\n  height: 52vh;\n  overflow-y: scroll;\n  padding-bottom: 10px;\n}\n\n.products img {\n  height: 150px;\n}\n\n.ifClick {\n  height: 19vh !important;\n}\n\n.recmoended ion-button {\n  --background: #E1E1E1;\n  font-size: 5vw;\n  height: auto;\n}\n\n.Modfires {\n  display: flex;\n  justify-content: space-between;\n}\n\n.Modfires h1 {\n  margin-top: 8px;\n  padding-left: 5px;\n  font-size: 7vw;\n}\n\n.confirmOrCancel ion-button {\n  font-size: 4vw;\n  height: 112px;\n}\n\n.next {\n  position: absolute;\n  bottom: 24%;\n  height: 100px !important;\n  left: 14px;\n  --background: rgb(252, 180, 0)!important;\n  color: #000;\n}\n\n@media only screen and (max-width: 768px) {\n  .imgProduct {\n    height: 71px;\n  }\n\n  .menu {\n    height: 67vh;\n    margin-top: -19%;\n  }\n\n  .menuItem {\n    padding: 12px 0;\n  }\n\n  .menuItem img {\n    height: 50px;\n    width: auto;\n  }\n\n  .back ion-button {\n    height: 36px;\n  }\n\n  .menu .mainMenu {\n    font-size: 13px;\n  }\n\n  .products img {\n    width: auto;\n    height: 90px;\n  }\n\n  .confirmOrCancel ion-button {\n    height: 44px;\n  }\n\n  .ifClick {\n    height: 10vh !important;\n  }\n\n  .cover2 {\n    height: 23vh;\n  }\n\n  .next {\n    height: 36px !important;\n  }\n\n  .back ion-button, .backIfRight ion-button {\n    height: 41px;\n  }\n\n  .next {\n    bottom: 25%;\n    left: 5px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXBvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLGtCQUFBO0VBQ0EsbUJBQUE7QUFBSjs7QUFFQTtFQUNJLHFCQUFBO0VBQ0EsY0FBQTtFQUNBLG9CQUFBO0FBQ0o7O0FBQ0U7RUFDRSxrQkFBQTtFQUNBLGVBQUE7QUFFSjs7QUFDRTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxRQUFBO0VBQ0EscUNBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxNQUFBO0FBRUo7O0FBQUU7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsTUFBQTtFQUNBLHFDQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FBR0o7O0FBREU7RUFDSSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQUlOOztBQUZFO0VBQ0UsaUJBQUE7QUFLSjs7QUFIRTtFQUNFLGdCQUFBO0FBTUo7O0FBSkU7RUFDSSxpQkFBQTtFQUNBLGNBQUE7QUFPTjs7QUFMRTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtBQVFKOztBQU5FO0VBQ0Usa0JBQUE7QUFTSjs7QUFQQTtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLFNBQUE7QUFVSjs7QUFSQTtFQUNJLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7QUFXSjs7QUFUQTtFQUNJLGdDQUFBO0FBWUo7O0FBVkE7RUFDSSwrQkFBQTtBQWFKOztBQVhBO0VBQ0ksZUFBQTtFQUNBLGdDQUFBO0FBY0o7O0FBWEE7RUFDSSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQWNKOztBQVhBO0VBQ0ksYUFBQTtBQWNKOztBQVpBO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQWVKOztBQWJBO0VBQ0ksbUJBQUE7RUFDQSxpQkFBQTtBQWdCSjs7QUFkQTtFQUNJLFNBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQWlCSjs7QUFkQTtFQUNJLGFBQUE7RUFDQSw2QkFBQTtBQWlCSjs7QUFmQTtFQUNJLFVBQUE7QUFrQko7O0FBaEJBO0VBQ0ksa0JBQUE7RUFDQSxjQUFBO0FBbUJKOztBQWhCQTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7QUFtQko7O0FBaEJBO0VBQ0ksU0FBQTtFQUNBLGNBQUE7QUFtQko7O0FBZkE7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQWtCSjs7QUFoQkE7RUFDSSw2QkFBQTtBQW1CSjs7QUFqQkE7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FBb0JKOztBQWxCQTtFQUNJLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG9CQUFBO0FBcUJKOztBQW5CQTtFQUNJLGFBQUE7QUFzQko7O0FBbkJBO0VBQ0ksdUJBQUE7QUFzQko7O0FBbkJBO0VBQ0cscUJBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQXNCSDs7QUFuQkE7RUFDQyxhQUFBO0VBQ0EsOEJBQUE7QUFzQkQ7O0FBbkJBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQXNCSjs7QUFwQkE7RUFDSSxjQUFBO0VBQ0EsYUFBQTtBQXVCSjs7QUFyQkE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSx3QkFBQTtFQUNBLFVBQUE7RUFDQSx3Q0FBQTtFQUNBLFdBQUE7QUF3Qko7O0FBZEE7RUFDSTtJQUNJLFlBQUE7RUFpQk47O0VBZkU7SUFDSSxZQUFBO0lBQ0EsZ0JBQUE7RUFrQk47O0VBaEJFO0lBQ0ksZUFBQTtFQW1CTjs7RUFqQkU7SUFDSSxZQUFBO0lBQ0EsV0FBQTtFQW9CTjs7RUFsQkU7SUFDSSxZQUFBO0VBcUJOOztFQW5CRTtJQUNJLGVBQUE7RUFzQk47O0VBcEJFO0lBQ0ksV0FBQTtJQUNBLFlBQUE7RUF1Qk47O0VBcEJFO0lBQ0UsWUFBQTtFQXVCSjs7RUFyQkU7SUFDSSx1QkFBQTtFQXdCTjs7RUF0QkU7SUFDSSxZQUFBO0VBeUJOOztFQXZCRTtJQUNJLHVCQUFBO0VBMEJOOztFQXhCRTtJQUNJLFlBQUE7RUEyQk47O0VBekJJO0lBQ0UsV0FBQTtJQUNBLFNBQUE7RUE0Qk47QUFDRiIsImZpbGUiOiJjb21wby5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi5oZWFkZXJ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGJhY2tncm91bmQ6ICNmY2VmNTBcbn1cbmlvbi1idXR0b24ge1xuICAgIC0tYmFja2dyb3VuZDogI0UxRTFFMTtcbiAgICAtLWNvbG9yOiBibGFjazsgXG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gIH1cbiAgaW9uLWNvbnRlbnR7XG4gICAgLS1iYWNrZ3JvdW5kOiNmZmYgO1xuICAgIC0tY29sb3I6IGJsYWNrXG59XG5cbiAgLmNvdmVyIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIGxlZnQ6IDAlO1xuICAgIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC43OSk7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIHRvcDogMFxuICB9XG4gIC5jb3ZlcjIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6Mjd2aDtcbiAgICB0b3A6IDA7XG4gICAgYmFja2dyb3VuZDogcmdiKDI1NSAyNTUgMjU1IC8gNzklKTs7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwXG4gIH1cbiAgLmNvdmVyIGgxIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgbWFyZ2luLXRvcDogMTIlO1xuICAgICAgZm9udC1zaXplOiA1dnc7XG4gICAgICBjb2xvcjogYmxhY2tcbiAgfVxuICAuYmFjayB7XG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIH1cbiAgLmJhY2tJZlJpZ2h0e1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gIH1cbiAgLmJhY2sgcCAsIC5iYWNrSWZSaWdodCBQe1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICBmb250LXNpemU6IDV2dztcbiAgfVxuICAuYmFjayBpb24tYnV0dG9uICwgLmJhY2tJZlJpZ2h0IGlvbi1idXR0b257XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAyZW07XG4gICAgLS1wYWRkaW5nLWVuZDogMmVtO1xuICAgIC0tYm9yZGVyLXJhZGl1czo1cHg7XG4gICAgbWFyZ2luLXRvcDogMiU7XG4gICAgZm9udC1zaXplOiA1dnc7XG4gICAgaGVpZ2h0OiBhdXRvO1xuICAgIG1hcmdpbi1ib3R0b206IDUlO1xuICAgIGhlaWdodDogMTAwcHg7XG4gIH1cbiAgLnByb2R1Y3Rze1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5wcm9kdWN0cyAucHJpY2V7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBmb250LXNpemU6IDExcHg7XG4gICAgbWFyZ2luOiAwXG59XG4ucHJvZHVjdHMgLm5hbWV7XG4gICAgZm9udC1zaXplOiAuOHJlbTtcbiAgICBtYXJnaW4tYm90dG9tOjVweDtcbiAgICBtYXJnaW4tdG9wOiAwO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkXG59XG4ucHJvZHVjdHMgLnJvd09uZXtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2MyYzJjMjtcbn1cbi5jb2xPbmV7XG4gICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2MyYzJjMjtcbn1cbi5tZW51SXRlbXtcbiAgICBwYWRkaW5nOiAzMHB4IDA7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjMmMyYzI7XG5cbn1cbi5tZW51SXRlbSBwe1xuICAgIG1hcmdpbjogMDtcbiAgICBmb250LXNpemU6IC41cmVtO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXNpemU6IDN2dztcblxufVxuLm1lbnVJdGVtIGltZyB7XG4gICAgaGVpZ2h0OiAxNTBweDtcbn1cbi5wcmljZV9uYW1le1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgIGZvbnQtc2l6ZTogM3Z3XG59XG4ubXlPcmRlcntcbiAgICBiYWNrZ3JvdW5kOiAjRTFFMUUxO1xuICAgIHBhZGRpbmcgOjVweCAxMHB4XG59XG4ubXlPcmRlciBoNCB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGZvbnQtc2l6ZTogNXZ3O1xuICAgIGNvbG9yOiBibGFja1xufVxuXG4uY29uZmlybU9yQ2FuY2Vse1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG59XG4uY29uZmlybU9yQ2FuY2VsIGlvbi1idXR0b257XG4gICAgd2lkdGg6IDMzJTtcbn1cbi5mb3RlciBwIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiA1dnc7XG59XG5cbi5mb290ZXIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBib3R0b206IDElXG5cbn1cbi5yZWNtb2VuZGVkIHB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGZvbnQtc2l6ZTogNXZ3O1xuXG59XG5cbi5tZW51e1xuICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgbWFyZ2luLXRvcDogLTE3JTtcbiAgICBiYWNrZ3JvdW5kOiAjZjBmMGYwO1xuICAgIGhlaWdodDogNzJ2aDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4ubWVudSBkaXYge1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBncmF5O1xufVxuLm1lbnUgLm1haW5NZW51e1xuICAgIGZvbnQtc2l6ZTogM3JlbTtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBtYXJnaW4tdG9wOiA1MCU7XG59XG4ucHJvZHVjdHN7XG4gICAgaGVpZ2h0OiA1MnZoO1xuICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbn1cbi5wcm9kdWN0cyBpbWcge1xuICAgIGhlaWdodDogMTUwcHg7XG59XG5cbi5pZkNsaWNre1xuICAgIGhlaWdodDoxOXZoICFpbXBvcnRhbnQ7XG59XG5cbi5yZWNtb2VuZGVkIGlvbi1idXR0b257XG4gICAtLWJhY2tncm91bmQ6ICNFMUUxRTE7XG4gICBmb250LXNpemU6IDV2dztcbiAgIGhlaWdodDogYXV0bzs7XG4gICBcbn1cbi5Nb2RmaXJlc3tcbiBkaXNwbGF5OiBmbGV4O1xuIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlblxufVxuXG4uTW9kZmlyZXMgaDEge1xuICAgIG1hcmdpbi10b3A6IDhweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDVweDtcbiAgICBmb250LXNpemU6IDd2dztcbn1cbi5jb25maXJtT3JDYW5jZWwgaW9uLWJ1dHRvbntcbiAgICBmb250LXNpemU6IDR2dztcbiAgICBoZWlnaHQ6IDExMnB4O1xufVxuLm5leHQge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBib3R0b206IDI0JTtcbiAgICBoZWlnaHQ6IDEwMHB4ICFpbXBvcnRhbnQ7XG4gICAgbGVmdDogMTRweDtcbiAgICAtLWJhY2tncm91bmQ6IHJnYigyNTIsIDE4MCwgMCkhaW1wb3J0YW50O1xuICAgIGNvbG9yOiAjMDAwXG59XG4vLyAubmV4dE1vZGZpcmUge1xuLy8gICAgIGhlaWdodDogMTAwcHg7XG4vLyB9XG4vLyAubmV4dE1vZGZpcmUgaW9uLWJ1dHRvbntcbi8vICAgICAtLWJhY2tncm91bmQ6ICNjMmMyYzI7XG4vLyAgICAgaGVpZ2h0OiAxMDAlO1xuLy8gfVxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6NzY4cHgpe1xuICAgIC5pbWdQcm9kdWN0e1xuICAgICAgICBoZWlnaHQ6IDcxcHg7XG4gICAgfVxuICAgIC5tZW51IHtcbiAgICAgICAgaGVpZ2h0OiA2N3ZoO1xuICAgICAgICBtYXJnaW4tdG9wOiAtMTklO1xuICAgIH1cbiAgICAubWVudUl0ZW17XG4gICAgICAgIHBhZGRpbmc6IDEycHggMDtcbiAgICB9XG4gICAgLm1lbnVJdGVtIGltZyB7XG4gICAgICAgIGhlaWdodDogNTBweDtcbiAgICAgICAgd2lkdGg6IGF1dG9cbiAgICB9XG4gICAgLmJhY2sgaW9uLWJ1dHRvbntcbiAgICAgICAgaGVpZ2h0OiAzNnB4O1xuICAgIH1cbiAgICAubWVudSAubWFpbk1lbnV7XG4gICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICB9XG4gICAgLnByb2R1Y3RzIGltZ3tcbiAgICAgICAgd2lkdGg6IGF1dG87XG4gICAgICAgIGhlaWdodDogOTBweDtcbiAgICAgICAgXG4gICAgfVxuICAgIC5jb25maXJtT3JDYW5jZWwgaW9uLWJ1dHRvbntcbiAgICAgIGhlaWdodDogNDRweDtcbiAgICB9XG4gICAgLmlmQ2xpY2t7XG4gICAgICAgIGhlaWdodDoxMHZoICFpbXBvcnRhbnQ7XG4gICAgfVxuICAgIC5jb3ZlcjJ7XG4gICAgICAgIGhlaWdodDoyM3ZoO1xuICAgIH1cbiAgICAubmV4dCB7XG4gICAgICAgIGhlaWdodDogMzZweCAhaW1wb3J0YW50O1xuICAgIH1cbiAgICAuYmFjayBpb24tYnV0dG9uICwgLmJhY2tJZlJpZ2h0IGlvbi1idXR0b257XG4gICAgICAgIGhlaWdodDogNDFweDtcbiAgICAgIH1cbiAgICAgIC5uZXh0ICB7XG4gICAgICAgIGJvdHRvbTogMjUlO1xuICAgICAgICBsZWZ0OiA1cHg7XG4gICAgfVxuICB9Il19 */";

/***/ }),

/***/ 8893:
/*!********************************************************!*\
  !*** ./src/app/pages/compo/compo.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<div class=\"header\">\n  <img class=\"imgProduct \" src=\"assets/images/bingo.png\">\n</div>\n\n<ion-content [dir]=\"dir\">\n  <div class=\"\">\n    <div class=\"back\" [ngClass]=\"{'back':dir == 'ltr', 'backIfRight':dir == 'rtl'}\">\n      <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n    </div>\n    <ion-grid style=\"padding: 0\">\n      <ion-row>\n        <ion-col class=\"menu\" [ngClass]=\"{'ifClick':showModfire}\" size=\"3\">\n          <p class=\"mainMenu\"> {{Menu}} </p>\n          <!-- <div  class=\"menuItem\">\n              <img src=\"assets/images/mostSelling.png\">\n              <p>{{bestSelling}}</p>\n            </div> -->\n          <div class=\"menuItem\" (click)=\"gotToDetails('Discount')\">\n            <img src=\"assets/images/discount.png\">\n            <p>{{discount}}</p>\n          </div>\n          <div class=\"menuItem\" routerLink=\"/promtions\">\n            <img src=\"assets/images/promotion.png\">\n            <p>{{promotions}}</p>\n          </div>\n          <div>\n            <div *ngFor=\"let item of categoris\" class=\"menuItem\" (click)=\"ChoseCategori(item)\">\n              <img src=\"{{item.Image}}\">\n              <p>{{item.Name}}</p>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col>\n          <div class=\"products\" [ngClass]=\"{'ifClick':showModfire}\">\n            <ion-grid>\n              <ion-row>\n                <!--  [ngClass]=\"{'colOne':item.status == false}\" -->\n                <ion-col size=\"6\" class=\"rowOne colOne\"\n                 (click)=\"goTocomboDetails(item)\"\n                  *ngFor=\"let item of items ; let i = index\">\n                  <!-- <span *ngIf=\"langId != 1\" class=\"price_name\">{{LE}} {{item.Price}}</span>\n                  <span *ngIf=\"langId == 1\" class=\"price_name\">{{item.Price}} {{LE}}</span> -->\n                  <img src=\"{{item.Image}}\">\n                  <p class=\"price_name\">{{item.Name}}</p>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <div [ngClass]=\"{'cover2':showModfire}\"></div>\n  </div>\n\n\n\n\n  <section class=\"footer\">\n    <div class=\"myOrder\">\n      <h4>{{MyOrder}}</h4>\n    </div>\n    <div class=\"foter\">\n      <p>{{arrOfModLength}}</p>\n      <div class=\"confirmOrCancel\" dir=\"ltr\">\n        <ion-button [disabled]=\"arrOfModLength\" (click)=\"cancelOrder()\">{{Cancel}}</ion-button>\n        <ion-button [disabled]=\"arrOfModLength\" (click)=\"Done()\">{{OrderDone}}</ion-button>\n      </div>\n    </div>\n  </section>\n\n\n\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_compo_compo_module_ts.js.map