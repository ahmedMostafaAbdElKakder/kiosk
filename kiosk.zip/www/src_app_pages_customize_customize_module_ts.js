"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_customize_customize_module_ts"],{

/***/ 8889:
/*!*************************************************************!*\
  !*** ./src/app/pages/customize/customize-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomizePageRoutingModule": () => (/* binding */ CustomizePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _customize_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customize.page */ 7337);




const routes = [
    {
        path: '',
        component: _customize_page__WEBPACK_IMPORTED_MODULE_0__.CustomizePage
    }
];
let CustomizePageRoutingModule = class CustomizePageRoutingModule {
};
CustomizePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CustomizePageRoutingModule);



/***/ }),

/***/ 77:
/*!*****************************************************!*\
  !*** ./src/app/pages/customize/customize.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomizePageModule": () => (/* binding */ CustomizePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _customize_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customize-routing.module */ 8889);
/* harmony import */ var _customize_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customize.page */ 7337);







let CustomizePageModule = class CustomizePageModule {
};
CustomizePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _customize_routing_module__WEBPACK_IMPORTED_MODULE_0__.CustomizePageRoutingModule
        ],
        declarations: [_customize_page__WEBPACK_IMPORTED_MODULE_1__.CustomizePage]
    })
], CustomizePageModule);



/***/ }),

/***/ 7337:
/*!***************************************************!*\
  !*** ./src/app/pages/customize/customize.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomizePage": () => (/* binding */ CustomizePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _customize_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customize.page.html?ngResource */ 2687);
/* harmony import */ var _customize_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customize.page.scss?ngResource */ 583);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/rest.service */ 1881);






let CustomizePage = class CustomizePage {
    constructor(route, rest) {
        this.route = route;
        this.rest = rest;
        this.myArray = [];
    }
    ngOnInit() {
        this.subscription = this.rest.getDataOfDub().subscribe(res => {
            if (res == 'true') {
                console.log("true");
                this.ngOnInit();
            }
        });
        this.langId = localStorage.getItem("lang");
        if (this.langId == '1') {
            this.dir = 'rtl';
            this.Back = "رجوع";
            this.addChange = "أضف الي العربة";
            this.Cancel = "إلغاء";
            this.Customize = "تعديل";
            this.Ingredients = "المكونات";
            this.Modfires = "الأضافات";
            this.LE = "جنيه";
        }
        else {
            this.dir = 'ltr';
            this.Back = "Back";
            this.addChange = "Add To Order";
            this.Cancel = "Cancel";
            this.Customize = "Customize";
            this.Ingredients = 'Ingredients';
            this.Modfires = "Modfires";
            this.LE = "LE";
        }
        this.products = JSON.parse(sessionStorage.getItem('ModfireOfChose'));
        this.ingrdArr = JSON.parse(sessionStorage.getItem('IngrdDub'));
        this.modfiresArr = JSON.parse(sessionStorage.getItem('modfiresArr'));
        this.countOfProduct = sessionStorage.getItem("countOfProduct");
        this.countOfProductAfter = sessionStorage.getItem("countOfProduct");
        this.countOfProductAfter = +this.countOfProductAfter;
        this.myArrOfItems = JSON.parse(sessionStorage.getItem('myArrOfItems'));
        this.countOfProduct = +this.countOfProduct - 1;
        if (this.myArrOfItems) {
            if (this.myArrOfItems.length < this.countOfProductAfter) {
                this.myArrOfItems.push({
                    Prdoucts: [this.products.Prdoucts[0]],
                    ingridtArr: [],
                    modfire: [],
                    id: this.myArrOfItems.length + 3
                });
                this.myArray = this.myArrOfItems;
            }
            else {
                this.myArray = this.myArrOfItems;
            }
        }
        else {
            this.products.id = 1;
            this.myArray.push(this.products);
            for (let i = 0; i < this.countOfProduct; i++) {
                this.myArray.push({
                    Prdoucts: [this.products.Prdoucts[0]],
                    ingridtArr: [],
                    modfire: [],
                    id: i + 2
                });
            }
            sessionStorage.setItem('myArrOfItems', JSON.stringify(this.myArray));
        }
        console.log(this.myArray);
    }
    gotToCustomize(item) {
        console.log(item);
        this.route.navigateByUrl("edit-customiz");
        sessionStorage.setItem('itemISChange', JSON.stringify(item));
    }
    addOrder() {
        let arrOfModfire = JSON.parse(sessionStorage.getItem('arrOfModfire'));
        if (arrOfModfire) {
            for (let i = 0; i < this.myArray.length; i++) {
                this.myArray[i].Prdoucts[0].count = 1;
                arrOfModfire.push(this.myArray[i]);
            }
            sessionStorage.setItem('arrOfModfire', JSON.stringify(arrOfModfire));
        }
        else {
            for (let i = 0; i < this.myArray.length; i++) {
                this.myArray[i].Prdoucts[0].count = 1;
            }
            sessionStorage.setItem('arrOfModfire', JSON.stringify(this.myArray));
        }
        this.rest.sendObsData('true');
        sessionStorage.removeItem('myArrOfItems');
        this.route.navigateByUrl('/main_menu');
        sessionStorage.removeItem('ifModFire');
    }
    goBack() {
        this.route.navigateByUrl('/quantity');
    }
    cancel() {
        this.route.navigateByUrl("/main_menu");
        sessionStorage.clear();
    }
};
CustomizePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: src_app_rest_service__WEBPACK_IMPORTED_MODULE_2__.RestService }
];
CustomizePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-customize',
        template: _customize_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_customize_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CustomizePage);



/***/ }),

/***/ 583:
/*!****************************************************************!*\
  !*** ./src/app/pages/customize/customize.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  text-align: center;\n  background: #fcef50;\n}\n\nion-content {\n  --background:#fff ;\n  --color: black ;\n}\n\nion-button {\n  --background: #E1E1E1;\n  --color: #000;\n  text-transform: none;\n}\n\n.back, .backIfRight {\n  text-transform: none;\n  margin-top: 5px;\n}\n\n.back ion-button, .backIfRight ion-button {\n  --padding-start: 2em;\n  --padding-end: 2em;\n  --border-radius:5px;\n  margin-top: 5%;\n  font-size: 5vw;\n  height: 84px;\n  margin-bottom: 3%;\n}\n\n.back {\n  text-align: right;\n}\n\n.backIfRight {\n  text-align: left;\n}\n\n.product {\n  display: flex;\n  justify-content: space-between;\n}\n\n.product div {\n  width: 50%;\n  display: flex;\n}\n\n.product div img {\n  width: 50%;\n}\n\n.product div p {\n  font-size: 3rem;\n}\n\n.product ion-button {\n  font-size: 3rem;\n  height: 100px;\n  margin-top: 5%;\n  margin-right: 3%;\n  --background: #2d2d2d;\n  color: #fff;\n}\n\n.modfireAndIngrd {\n  display: flex;\n  justify-content: space-around;\n}\n\n.modfireAndIngrd p {\n  font-size: 3rem;\n  margin: 0;\n}\n\n.modfireAndIngrd ul {\n  font-size: 2rem;\n}\n\n.footer {\n  position: absolute;\n  bottom: 1%;\n  width: 100%;\n}\n\n.footer div {\n  display: flex;\n  justify-content: space-around;\n}\n\n.footer ion-button {\n  width: 35%;\n  font-size: 4vw;\n  height: 120px;\n}\n\n@media only screen and (max-width: 768px) {\n  .imgProduct {\n    width: 82px;\n  }\n\n  .back ion-button, .backIfRight ion-button {\n    height: 41px;\n  }\n\n  .product ion-button {\n    font-size: 1rem;\n    height: 30px !important;\n  }\n\n  .product div p {\n    font-size: 1rem;\n  }\n\n  .modfireAndIngrd p {\n    font-size: 1rem;\n  }\n\n  .modfireAndIngrd ul {\n    font-size: 0.8rem;\n  }\n\n  .footer ion-button {\n    height: 40px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbWl6ZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0FBQ0o7O0FBRUU7RUFDRSxrQkFBQTtFQUNBLGVBQUE7QUFDSjs7QUFDRTtFQUNFLHFCQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0FBRUo7O0FBQUU7RUFDRSxvQkFBQTtFQUNBLGVBQUE7QUFHSjs7QUFERTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FBSUo7O0FBRkU7RUFDRSxpQkFBQTtBQUtKOztBQUhFO0VBQ0UsZ0JBQUE7QUFNSjs7QUFIRTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtBQU1KOztBQUpFO0VBQ0UsVUFBQTtFQUNBLGFBQUE7QUFPSjs7QUFMRTtFQUNFLFVBQUE7QUFRSjs7QUFORTtFQUNFLGVBQUE7QUFTSjs7QUFQRTtFQUNFLGVBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0FBVUo7O0FBUkU7RUFDRSxhQUFBO0VBQ0EsNkJBQUE7QUFXSjs7QUFURTtFQUNFLGVBQUE7RUFDQSxTQUFBO0FBWUo7O0FBVkU7RUFDRSxlQUFBO0FBYUo7O0FBVkU7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FBYUo7O0FBWEU7RUFDRSxhQUFBO0VBQ0EsNkJBQUE7QUFjSjs7QUFaRTtFQUNFLFVBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQWVKOztBQVZFO0VBQ0U7SUFDSSxXQUFBO0VBYU47O0VBWEk7SUFDRSxZQUFBO0VBY047O0VBWkk7SUFDRSxlQUFBO0lBQ0osdUJBQUE7RUFlRjs7RUFiSTtJQUNFLGVBQUE7RUFnQk47O0VBZEk7SUFDRSxlQUFBO0VBaUJOOztFQWZJO0lBQ0UsaUJBQUE7RUFrQk47O0VBaEJJO0lBQ0UsWUFBQTtFQW1CTjtBQUNGIiwiZmlsZSI6ImN1c3RvbWl6ZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVye1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kOiAjZmNlZjUwXG4gIH1cbiAgXG4gIGlvbi1jb250ZW50e1xuICAgIC0tYmFja2dyb3VuZDojZmZmIDtcbiAgICAtLWNvbG9yOiBibGFja1xuICB9XG4gIGlvbi1idXR0b24ge1xuICAgIC0tYmFja2dyb3VuZDogI0UxRTFFMTtcbiAgICAtLWNvbG9yOiAjMDAwOyBcbiAgICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgfVxuICAuYmFjayAsLmJhY2tJZlJpZ2h0e1xuICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICAgIG1hcmdpbi10b3A6IDVweDtcbiAgfVxuICAuYmFjayBpb24tYnV0dG9uICwgLmJhY2tJZlJpZ2h0IGlvbi1idXR0b257XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAyZW07XG4gICAgLS1wYWRkaW5nLWVuZDogMmVtO1xuICAgIC0tYm9yZGVyLXJhZGl1czo1cHg7XG4gICAgbWFyZ2luLXRvcDogNSU7XG4gICAgZm9udC1zaXplOiA1dnc7XG4gICAgaGVpZ2h0OiA4NHB4O1xuICAgIG1hcmdpbi1ib3R0b206MyVcbiAgfVxuICAuYmFjayB7XG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIH1cbiAgLmJhY2tJZlJpZ2h0e1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gIH1cblxuICAucHJvZHVjdHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlblxuICB9XG4gIC5wcm9kdWN0IGRpdiB7XG4gICAgd2lkdGg6IDUwJTtcbiAgICBkaXNwbGF5OiBmbGV4XG4gIH1cbiAgLnByb2R1Y3QgZGl2IGltZyB7XG4gICAgd2lkdGg6IDUwJVxuICB9XG4gIC5wcm9kdWN0IGRpdiBwIHtcbiAgICBmb250LXNpemU6IDNyZW1cbiAgfVxuICAucHJvZHVjdCBpb24tYnV0dG9uIHtcbiAgICBmb250LXNpemU6IDNyZW07XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICBtYXJnaW4tcmlnaHQ6IDMlO1xuICAgIC0tYmFja2dyb3VuZDogIzJkMmQyZDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgfVxuICAubW9kZmlyZUFuZEluZ3Jke1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG4gIH1cbiAgLm1vZGZpcmVBbmRJbmdyZCBwIHtcbiAgICBmb250LXNpemU6IDNyZW07XG4gICAgbWFyZ2luOiAwO1xuICB9XG4gIC5tb2RmaXJlQW5kSW5ncmQgdWwge1xuICAgIGZvbnQtc2l6ZTogMnJlbVxuICB9XG5cbiAgLmZvb3RlciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJvdHRvbTogMSU7XG4gICAgd2lkdGg6IDEwMCVcbiAgfVxuICAuZm9vdGVyIGRpdiB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZFxuICB9XG4gIC5mb290ZXIgaW9uLWJ1dHRvbntcbiAgICB3aWR0aDogMzUlO1xuICAgIGZvbnQtc2l6ZTogNHZ3O1xuICAgIGhlaWdodDogMTIwcHg7XG4gICAgXG5cbiAgfVxuXG4gIEBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDo3NjhweCl7XG4gICAgLmltZ1Byb2R1Y3R7XG4gICAgICAgIHdpZHRoOiA4MnB4O1xuICAgICAgfVxuICAgICAgLmJhY2sgaW9uLWJ1dHRvbiAsIC5iYWNrSWZSaWdodCBpb24tYnV0dG9ue1xuICAgICAgICBoZWlnaHQ6IDQxcHg7XG4gICAgICB9XG4gICAgICAucHJvZHVjdCBpb24tYnV0dG9ue1xuICAgICAgICBmb250LXNpemU6IDFyZW07XG4gICAgaGVpZ2h0OiAzMHB4ICFpbXBvcnRhbnQ7XG4gICAgICB9XG4gICAgICAucHJvZHVjdCBkaXYgcCB7XG4gICAgICAgIGZvbnQtc2l6ZTogMXJlbVxuICAgICAgfVxuICAgICAgLm1vZGZpcmVBbmRJbmdyZCBwe1xuICAgICAgICBmb250LXNpemU6IDFyZW1cbiAgICAgIH1cbiAgICAgIC5tb2RmaXJlQW5kSW5ncmQgdWwge1xuICAgICAgICBmb250LXNpemU6IC44cmVtXG4gICAgICB9XG4gICAgICAuZm9vdGVyIGlvbi1idXR0b257XG4gICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgIH1cbiAgfSJdfQ== */";

/***/ }),

/***/ 2687:
/*!****************************************************************!*\
  !*** ./src/app/pages/customize/customize.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"header\">\n  <img class=\"imgProduct \" src=\"assets/images/bingo.png\">\n</div>\n\n<ion-content [dir]=\"dir\">\n\n  <div [ngClass]=\"{'back':dir == 'ltr','backIfRight':dir == 'rtl'}\">\n    <ion-button (click)=\"goBack()\">{{Back}}</ion-button>\n  </div>\n\n\n  <section style=\"    height: 66vh;\n  overflow: scroll;\">\n    <div *ngFor=\"let item of myArray\" style=\"    border-bottom: 1px solid #d2d2d2;\">\n      <div class=\"product\">\n        <div>\n          <img src=\"{{item.Prdoucts[0].Image}}\">\n          <p>{{item.Prdoucts[0].Name}}</p>\n        </div>\n        <ion-button (click)=\"gotToCustomize(item)\">{{Customize}}</ion-button>\n      </div>\n\n      <div class=\"modfireAndIngrd\">\n        <div *ngIf=\"item.ingridtArr != 0\">\n          <p>{{Ingredients}}</p>\n          <ul>\n            <li *ngFor=\"let ingrd of item.ingridtArr\">\n              {{ingrd.count}} {{ingrd.Name}} X {{ingrd.Price}}{{LE}}\n            </li>\n          </ul>\n        </div>\n        <div *ngIf=\"item.modfire != 0\">\n          <p>{{Modfires}}</p>\n          <ul>\n            <li *ngFor=\"let modfire of item.modfire\">\n            {{modfire.count}} {{modfire.Name}} X {{modfire.Price}}{{LE}}\n          </li>\n          </ul>\n        </div>\n      </div>\n    </div>\n  </section>\n\n\n  <div class=\"footer\" dir=\"ltr\">\n      <div>\n        <ion-button (click)=\"cancel()\">{{Cancel}}</ion-button>\n        <ion-button (click)=\"addOrder()\">{{addChange}}</ion-button>\n      </div>\n    </div>\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_customize_customize_module_ts.js.map