"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_phone-number_phone-number_module_ts"],{

/***/ 6468:
/*!*******************************************************************!*\
  !*** ./src/app/pages/phone-number/phone-number-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneNumberPageRoutingModule": () => (/* binding */ PhoneNumberPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _phone_number_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./phone-number.page */ 7743);




const routes = [
    {
        path: '',
        component: _phone_number_page__WEBPACK_IMPORTED_MODULE_0__.PhoneNumberPage
    }
];
let PhoneNumberPageRoutingModule = class PhoneNumberPageRoutingModule {
};
PhoneNumberPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PhoneNumberPageRoutingModule);



/***/ }),

/***/ 6126:
/*!***********************************************************!*\
  !*** ./src/app/pages/phone-number/phone-number.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneNumberPageModule": () => (/* binding */ PhoneNumberPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _phone_number_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./phone-number-routing.module */ 6468);
/* harmony import */ var _phone_number_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./phone-number.page */ 7743);







let PhoneNumberPageModule = class PhoneNumberPageModule {
};
PhoneNumberPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _phone_number_routing_module__WEBPACK_IMPORTED_MODULE_0__.PhoneNumberPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_phone_number_page__WEBPACK_IMPORTED_MODULE_1__.PhoneNumberPage]
    })
], PhoneNumberPageModule);



/***/ }),

/***/ 7743:
/*!*********************************************************!*\
  !*** ./src/app/pages/phone-number/phone-number.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneNumberPage": () => (/* binding */ PhoneNumberPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _phone_number_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./phone-number.page.html?ngResource */ 8014);
/* harmony import */ var _phone_number_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./phone-number.page.scss?ngResource */ 615);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 587);






let PhoneNumberPage = class PhoneNumberPage {
    constructor(router, formBuilder) {
        this.router = router;
        this.formBuilder = formBuilder;
    }
    ngOnInit() {
        this.langId = localStorage.getItem("lang");
        this.register = this.formBuilder.group({
            mobileNumber: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.maxLength(11), _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.pattern('^((\\+91-?)|0)?[0-9]{11}$')]],
        });
        if (this.langId == '1') {
            this.Continue = "متابعة";
            this.CustomerMobile = "رقم العميل";
            this.CustomerMobileplace = "ادخل رقم هاتف العميل";
        }
        else {
            this.Continue = "Continue";
            this.CustomerMobile = "Customer Mobile";
            this.CustomerMobileplace = "Enter Customer Mobile Number";
        }
    }
    next() {
        console.log(this.register.value);
        if (this.register.valid) {
            this.router.navigateByUrl('/home');
            sessionStorage.setItem("mobileNumber", this.register.value.mobileNumber);
        }
    }
};
PhoneNumberPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder }
];
PhoneNumberPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-phone-number',
        template: _phone_number_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_phone_number_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PhoneNumberPage);



/***/ }),

/***/ 615:
/*!**********************************************************************!*\
  !*** ./src/app/pages/phone-number/phone-number.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background:rgb(60, 60, 59);\n  text-align: center;\n}\n\n.container {\n  margin: 0 5%;\n}\n\nion-item {\n  --background: #fff;\n  color: #000;\n  font-size: 3rem;\n  margin-bottom: 14px;\n  border-radius: 6px;\n}\n\nion-button {\n  font-size: 3rem;\n  height: 100px;\n  width: auto;\n  --background: #f7a525;\n  color: #fff;\n  margin-top: 5%;\n}\n\n@media only screen and (max-width: 768px) {\n  .container {\n    margin: 0 20;\n  }\n\n  ion-item {\n    --background: #fff;\n    color: #000;\n    font-size: 1rem;\n    margin-bottom: 14px;\n    border-radius: 6px;\n  }\n\n  ion-button {\n    font-size: 1rem;\n    height: 50px;\n    width: auto;\n    --background: #f7a525;\n    color: #fff;\n    margin-top: 1%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBob25lLW51bWJlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSw0QkFBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBQ0U7RUFDRSxZQUFBO0FBRUo7O0FBQUE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUdKOztBQURBO0VBQ0ksZUFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtBQUlKOztBQURBO0VBQ0k7SUFDSSxZQUFBO0VBSU47O0VBRkU7SUFDSSxrQkFBQTtJQUNBLFdBQUE7SUFDQSxlQUFBO0lBQ0EsbUJBQUE7SUFDQSxrQkFBQTtFQUtOOztFQUhFO0lBQ0ksZUFBQTtJQUNBLFlBQUE7SUFDQSxXQUFBO0lBQ0EscUJBQUE7SUFDQSxXQUFBO0lBQ0EsY0FBQTtFQU1OO0FBQ0YiLCJmaWxlIjoicGhvbmUtbnVtYmVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xuICAgIC0tYmFja2dyb3VuZDpyZ2IoNjAsIDYwLCA1OSk7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB9XG4gIC5jb250YWluZXJ7XG4gICAgbWFyZ2luOiAwIDUlO1xufVxuaW9uLWl0ZW17XG4gICAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGZvbnQtc2l6ZTogM3JlbTtcbiAgICBtYXJnaW4tYm90dG9tOiAxNHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcbn1cbmlvbi1idXR0b257XG4gICAgZm9udC1zaXplOiAzcmVtO1xuICAgIGhlaWdodDogMTAwcHg7XG4gICAgd2lkdGg6IGF1dG87XG4gICAgLS1iYWNrZ3JvdW5kOiAjZjdhNTI1O1xuICAgIGNvbG9yOiNmZmY7XG4gICAgbWFyZ2luLXRvcDogNSU7XG59XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDo3NjhweCl7XG4gICAgLmNvbnRhaW5lcntcbiAgICAgICAgbWFyZ2luOiAwIDIwO1xuICAgIH1cbiAgICBpb24taXRlbXtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xuICAgICAgICBjb2xvcjogIzAwMDtcbiAgICAgICAgZm9udC1zaXplOiAxcmVtO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAxNHB4O1xuICAgICAgICBib3JkZXItcmFkaXVzOiA2cHg7XG4gICAgfVxuICAgIGlvbi1idXR0b257XG4gICAgICAgIGZvbnQtc2l6ZTogMXJlbTtcbiAgICAgICAgaGVpZ2h0OiA1MHB4O1xuICAgICAgICB3aWR0aDogYXV0bztcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZjdhNTI1O1xuICAgICAgICBjb2xvcjojZmZmO1xuICAgICAgICBtYXJnaW4tdG9wOiAxJTtcbiAgICB9XG59Il19 */";

/***/ }),

/***/ 8014:
/*!**********************************************************************!*\
  !*** ./src/app/pages/phone-number/phone-number.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <ion-img class=\"logoImage\" src=\"assets/images/logoFinal02.png\"></ion-img>\n\n  <div class=\"container\">\n\n    <form [formGroup]=\"register\">\n      <ion-item>\n        <ion-label position=\"stacked\">Customer Mobile</ion-label>\n        <ion-input type=\"text\" maxlength=\"11\" formControlName=\"mobileNumber\"\n         placeholder=\"Enter Customer Mobile Number\"></ion-input>\n      </ion-item>\n      <ion-button class=\"btn\" (click)=\"next()\">Continue</ion-button>\n    </form>\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_phone-number_phone-number_module_ts.js.map